<?php
/**
 * Homepage.
 */
defined( 'ABSPATH' ) || exit;
get_header();

$has_core = function_exists( 'sp_query_products' );
$shop     = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );

if ( function_exists( 'sp_render_hero' ) ) {
	sp_render_hero();
}
?>
<section class="sp-values" aria-label="ليش مختارات شهلاء">
	<div class="sp-container">
		<ul>
			<li><?php echo spt_icon( 'silk', 20 ); // phpcs:ignore ?> حرير إيطالي</li>
			<li><?php echo spt_icon( 'one', 20 ); // phpcs:ignore ?> كل تصميم قطعة واحدة</li>
			<li><?php echo spt_icon( 'truck', 20 ); // phpcs:ignore ?> تسليم فوري</li>
			<li><?php echo spt_icon( 'whatsapp', 20 ); // phpcs:ignore ?> اطلبي بالواتساب بضغطة</li>
		</ul>
	</div>
</section>

<?php
if ( function_exists( 'sp_render_drop' ) ) {
	sp_render_drop();
}

if ( $has_core ) :
	$new = sp_query_products( array( 'state' => 'available', 'limit' => 8 ) );
	?>
	<section class="sp-section">
		<div class="sp-container">
			<div class="sp-section__head">
				<div><p class="sp-eyebrow">متوفر الآن</p><h2>وصل حديثاً</h2></div>
				<a class="sp-link" href="<?php echo esc_url( $shop ); ?>">كل القطع</a>
			</div>
			<?php echo $new ? sp_render_product_cards( $new ) : '<p class="sp-empty">بنضيف قطع جديدة قريباً.</p>'; // phpcs:ignore ?>
		</div>
	</section>

	<section class="sp-section sp-section--tight">
		<div class="sp-container">
			<div class="sp-section__head"><div><p class="sp-eyebrow">لقي مقاسك أسرع</p><h2>تسوّقي حسب الطول</h2></div></div>
			<div class="sp-lengths">
				<?php foreach ( sp_length_ranges() as $slug => $r ) : ?>
					<a class="sp-length" href="<?php echo esc_url( add_query_arg( 'sp_len', $slug, $shop ) ); ?>"><?php echo sp_icon( 'ruler', 22 ); // phpcs:ignore ?><strong><?php echo esc_html( $r[0] ); ?></strong></a>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<?php
	$cats = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => array( (int) get_option( 'default_product_cat' ) ), 'orderby' => 'count', 'order' => 'DESC', 'number' => 4 ) );
	if ( $cats && ! is_wp_error( $cats ) ) :
		?>
	<section class="sp-section sp-section--tight">
		<div class="sp-container">
			<div class="sp-section__head"><div><p class="sp-eyebrow">التشكيلات</p><h2>تسوّقي حسب التصنيف</h2></div></div>
			<div class="sp-cats">
				<?php
				foreach ( $cats as $c ) :
					$thumb = (int) get_term_meta( $c->term_id, 'thumbnail_id', true );
					if ( ! $thumb ) {
						$first = sp_query_products( array( 'state' => 'any', 'limit' => 1, 'category' => $c->slug ) );
						$thumb = $first ? get_post_thumbnail_id( $first[0] ) : 0;
					}
					?>
					<a class="sp-cat" href="<?php echo esc_url( get_term_link( $c ) ); ?>">
						<?php echo $thumb ? wp_get_attachment_image( $thumb, 'woocommerce_thumbnail', false, array( 'loading' => 'lazy' ) ) : ''; ?>
						<span><?php echo esc_html( $c->name ); ?><small><?php echo esc_html( sprintf( '%d قطعة', $c->count ) ); ?></small></span>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<?php
	$sold = sp_query_products( array( 'state' => 'sold', 'limit' => 4 ) );
	if ( $sold ) :
		?>
	<section class="sp-section sp-section--sand">
		<div class="sp-container">
			<div class="sp-section__head">
				<div><p class="sp-eyebrow">للإلهام</p><h2>قطع انباعت</h2></div>
				<?php if ( sp_page_url( 'sold' ) ) : ?><a class="sp-link" href="<?php echo esc_url( sp_page_url( 'sold' ) ); ?>">شوفي الكل</a><?php endif; ?>
			</div>
			<p class="sp-lead">عجبتك قطعة انباعت؟ اضغطي <strong>أبغى مثلها</strong> ونحاول نوفر لك قطعة قريبة منها.</p>
			<?php echo sp_render_product_cards( $sold, 'sp-grid--sold' ); // phpcs:ignore ?>
		</div>
	</section>
	<?php endif; ?>

	<?php
	$up   = sp_get_events( 'upcoming', 2 );
	$past = $up ? array() : sp_get_events( 'past', 1 );
	if ( $up || $past ) :
		?>
	<section class="sp-section">
		<div class="sp-container">
			<div class="sp-section__head">
				<div><p class="sp-eyebrow">تعالي زورينا</p><h2>البازارات</h2></div>
				<?php if ( sp_page_url( 'events' ) ) : ?><a class="sp-link" href="<?php echo esc_url( sp_page_url( 'events' ) ); ?>">كل البازارات</a><?php endif; ?>
			</div>
			<div class="sp-events__grid">
				<?php
				foreach ( $up as $id ) {
					echo sp_event_card( $id ); // phpcs:ignore
				}
				foreach ( $past as $id ) {
					echo sp_event_card( $id, true ); // phpcs:ignore
				}
				?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<?php
	$reviews = sp_reviews_html( 8 );
	if ( $reviews ) :
		?>
	<section class="sp-section sp-section--rose">
		<div class="sp-container">
			<div class="sp-section__head">
				<div><p class="sp-eyebrow">من عميلاتنا</p><h2>آراء نعتز فيها</h2></div>
				<?php if ( sp_page_url( 'reviews' ) ) : ?><a class="sp-link" href="<?php echo esc_url( sp_page_url( 'reviews' ) ); ?>">كل الآراء</a><?php endif; ?>
			</div>
			<?php echo str_replace( 'class="sp-reviews"', 'class="sp-reviews sp-reviews--scroll"', $reviews ); // phpcs:ignore ?>
		</div>
	</section>
	<?php endif; ?>
<?php endif; ?>

<section class="sp-section">
	<div class="sp-container">
		<div class="sp-band">
			<div>
				<div class="sp-band__logo"><?php echo sp_theme_logo_svg(); // phpcs:ignore ?></div>
				<p class="sp-eyebrow">لا تفوتك القطع الجديدة</p>
				<h2>كل قطعة وحدة بس… خليك أول من يعرف</h2>
				<p>سجلي رقم الواتساب ونرسل لك أول ما تنزل تشكيلة جديدة، أو تابعينا على إنستقرام.</p>
				<?php echo function_exists( 'sp_subscribe_form' ) ? sp_subscribe_form() : ''; // phpcs:ignore ?>
			</div>
			<?php
			if ( $has_core ) :
				$ig = sp_query_products( array( 'state' => 'any', 'limit' => 6 ) );
				if ( $ig ) :
					?>
				<div class="sp-ig-grid">
					<?php foreach ( $ig as $id ) : ?>
						<a href="<?php echo esc_url( spt_opt( 'instagram', '#' ) ); ?>" target="_blank" rel="noopener" aria-label="إنستقرام مختارات شهلاء"><?php echo get_the_post_thumbnail( $id, 'woocommerce_thumbnail', array( 'loading' => 'lazy', 'alt' => '' ) ); ?></a>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
</section>
<?php
get_footer();
