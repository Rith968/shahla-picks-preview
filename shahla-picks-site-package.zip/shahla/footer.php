<?php
/**
 * Footer + mobile tab bar.
 */
defined( 'ABSPATH' ) || exit;
$shop     = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
$cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '#';
$wish_url = function_exists( 'sp_page_url' ) ? sp_page_url( 'wishlist' ) : '';
$count    = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
$cats     = taxonomy_exists( 'product_cat' ) ? get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => array( (int) get_option( 'default_product_cat' ) ), 'number' => 6 ) ) : array();
?>
</main>

<footer class="sp-footer">
	<div class="sp-container">
		<div class="sp-footer__grid">
			<div>
				<div class="sp-footer__logo"><?php echo sp_theme_logo_svg(); // phpcs:ignore ?></div>
				<p>مخورات من الحرير الإيطالي بتصاميم مطرّزة مختارة، وكل تصميم قطعة واحدة فقط. من <?php echo esc_html( spt_opt( 'pickup_location', 'بوشر، مسقط' ) ); ?>.</p>
				<div class="sp-social">
					<a href="<?php echo esc_url( spt_opt( 'instagram', '#' ) ); ?>" target="_blank" rel="noopener" aria-label="إنستقرام"><?php echo spt_icon( 'insta', 20 ); // phpcs:ignore ?></a>
					<a href="<?php echo esc_url( spt_wa_chat_url() ); ?>" target="_blank" rel="noopener" aria-label="واتساب"><?php echo spt_icon( 'whatsapp', 20 ); // phpcs:ignore ?></a>
				</div>
			</div>
			<div>
				<h3>تسوّقي</h3>
				<ul>
					<li><a href="<?php echo esc_url( $shop ); ?>">كل القطع المتوفرة</a></li>
					<?php if ( ! is_wp_error( $cats ) ) : foreach ( $cats as $c ) : ?>
						<li><a href="<?php echo esc_url( get_term_link( $c ) ); ?>"><?php echo esc_html( $c->name ); ?></a></li>
					<?php endforeach; endif; ?>
				</ul>
			</div>
			<div>
				<h3>مساعدة</h3>
				<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1, 'fallback_cb' => '__return_false' ) ); ?>
			</div>
			<div>
				<h3>اعرفي أول ما تنزل قطع جديدة</h3>
				<p>سجلي رقم الواتساب ونرسل لك الإطلاقات الجديدة قبل الكل.</p>
				<?php echo function_exists( 'sp_subscribe_form' ) ? sp_subscribe_form() : ''; // phpcs:ignore ?>
			</div>
		</div>
		<div class="sp-footer__bottom">
			<span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> مختارات شهلاء · Shahla Picks</span>
			<span>سلطنة عُمان</span>
		</div>
	</div>
</footer>

<nav class="sp-tabbar" aria-label="تنقل سريع">
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="<?php echo is_front_page() ? 'is-current' : ''; ?>"><?php echo spt_icon( 'home' ); // phpcs:ignore ?><span>الرئيسية</span></a>
	<a href="<?php echo esc_url( $shop ); ?>" class="<?php echo function_exists( 'is_shop' ) && ( is_shop() || is_product_taxonomy() ) ? 'is-current' : ''; ?>"><?php echo spt_icon( 'grid' ); // phpcs:ignore ?><span>المتجر</span></a>
	<?php if ( $wish_url ) : ?>
	<a href="<?php echo esc_url( $wish_url ); ?>" class="<?php echo is_page() && get_permalink() === $wish_url ? 'is-current' : ''; ?>"><?php echo spt_icon( 'heart' ); // phpcs:ignore ?><span>المفضلة</span><span class="sp-count" data-sp-wish-count data-count="0">0</span></a>
	<?php endif; ?>
	<a href="<?php echo esc_url( $cart_url ); ?>" class="<?php echo function_exists( 'is_cart' ) && is_cart() ? 'is-current' : ''; ?>"><?php echo spt_icon( 'bag' ); // phpcs:ignore ?><span>السلة</span><span class="sp-cart-count" data-count="<?php echo (int) $count; ?>"><?php echo (int) $count; ?></span></a>
	<a href="<?php echo esc_url( spt_wa_chat_url() ); ?>" class="is-wa" target="_blank" rel="noopener"><?php echo spt_icon( 'whatsapp' ); // phpcs:ignore ?><span>واتساب</span></a>
</nav>

<?php wp_footer(); ?>
</body>
</html>
