<?php
/**
 * Shahla theme setup.
 */
defined( 'ABSPATH' ) || exit;

define( 'SPT_VER', '1.0.0' );
require get_template_directory() . '/inc/logo.php';
require get_template_directory() . '/inc/woo.php';
require get_template_directory() . '/inc/pwa.php';

add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'shahla', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'woocommerce', array(
		'thumbnail_image_width' => 450,
		'single_image_width'    => 900,
		'product_grid'          => array( 'default_rows' => 6, 'min_rows' => 2, 'default_columns' => 4, 'min_columns' => 2, 'max_columns' => 4 ),
	) );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	register_nav_menus( array(
		'primary' => 'القائمة الرئيسية',
		'footer'  => 'روابط الفوتر',
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'shahla-fonts', 'https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap', array(), null );
	wp_enqueue_style( 'shahla', get_stylesheet_uri(), array(), SPT_VER );
	wp_enqueue_script( 'shahla', get_template_directory_uri() . '/assets/js/theme.js', array(), SPT_VER, true );
	if ( function_exists( 'WC' ) ) {
		wp_enqueue_script( 'wc-add-to-cart' );
	}
	wp_dequeue_style( 'wc-blocks-style' );
	wp_dequeue_style( 'wp-block-library-theme' );
}, 20 );

add_action( 'wp_head', function () {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}, 1 );

/* Favicon fallback when no Site Icon is set. */
add_action( 'wp_head', function () {
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" type="image/png" href="' . esc_url( get_template_directory_uri() . '/assets/img/favicon.png' ) . '">' . "\n";
	}
} );

/** Inline icon set for theme UI. */
function spt_icon( $name, $size = 22 ) {
	$p = array(
		'menu'   => '<path d="M4 7h16M4 12h16M4 17h10" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" fill="none"/>',
		'close'  => '<path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" fill="none"/>',
		'search' => '<circle cx="11" cy="11" r="6.5" stroke="currentColor" stroke-width="1.7" fill="none"/><path d="m20 20-4.2-4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
		'home'   => '<path d="M4 10.5 12 4l8 6.5V20H14.5v-5h-5v5H4z" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linejoin="round"/>',
		'grid'   => '<rect x="4" y="4" width="6.5" height="6.5" rx="1.6" stroke="currentColor" stroke-width="1.6" fill="none"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.6" stroke="currentColor" stroke-width="1.6" fill="none"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.6" stroke="currentColor" stroke-width="1.6" fill="none"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.6" stroke="currentColor" stroke-width="1.6" fill="none"/>',
		'insta'  => '<rect x="3.5" y="3.5" width="17" height="17" rx="5" stroke="currentColor" stroke-width="1.6" fill="none"/><circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="1.6" fill="none"/><circle cx="17.3" cy="6.7" r="1.1" fill="currentColor"/>',
		'arrow'  => '<path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="1.7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
		'silk'   => '<path d="M4 18c3-1 4-5 8-5s5 4 8 5M4 12c3-1 4-5 8-5s5 4 8 5" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round"/>',
		'one'    => '<path d="M12 3.5 14.4 9l5.9.5-4.5 3.9 1.4 5.8L12 16.1 6.8 19.2l1.4-5.8L3.7 9.5 9.6 9z" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linejoin="round"/>',
	);
	if ( isset( $p[ $name ] ) ) {
		return '<svg class="sp-ico" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $p[ $name ] . '</svg>';
	}
	return function_exists( 'sp_icon' ) ? sp_icon( $name, $size ) : '';
}

/** Menu fallback before menus are set. */
function spt_menu_fallback() {
	$links = array( home_url( '/' ) => 'الرئيسية' );
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$links[ wc_get_page_permalink( 'shop' ) ] = 'المتجر';
	}
	echo '<ul>';
	foreach ( $links as $url => $label ) {
		echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
	}
	echo '</ul>';
}

function spt_opt( $key, $default = '' ) {
	return function_exists( 'sp_opt' ) ? sp_opt( $key, $default ) : $default;
}

function spt_wa_chat_url() {
	return function_exists( 'sp_wa_url' ) ? sp_wa_url( 'السلام عليكم، عندي استفسار عن مختارات شهلاء' ) : '#';
}

add_filter( 'excerpt_length', function () { return 24; } );
add_filter( 'body_class', function ( $c ) {
	$c[] = 'sp-site';
	return $c;
} );
