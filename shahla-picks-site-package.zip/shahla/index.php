<?php
/**
 * Fallback template (search results, posts, events).
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="sp-container">
	<header class="sp-page-head">
		<h1><?php echo is_search() ? esc_html( 'نتائج البحث عن: ' . get_search_query() ) : esc_html( is_singular() ? get_the_title() : wp_get_document_title() ); ?></h1>
	</header>
	<?php if ( is_singular() ) : ?>
		<?php while ( have_posts() ) : the_post(); ?>
			<article class="sp-entry">
				<?php if ( 'sp_event' === get_post_type() && function_exists( 'sp_event_card' ) ) { echo sp_event_card( get_the_ID(), get_post_meta( get_the_ID(), '_sp_date', true ) < current_time( 'Y-m-d' ) ); } // phpcs:ignore ?>
				<?php the_content(); ?>
			</article>
		<?php endwhile; ?>
	<?php elseif ( have_posts() ) : ?>
		<?php
		$ids = array();
		while ( have_posts() ) {
			the_post();
			if ( 'product' === get_post_type() ) {
				$ids[] = get_the_ID();
			}
		}
		rewind_posts();
		if ( $ids && function_exists( 'sp_render_product_cards' ) ) {
			echo sp_render_product_cards( $ids ); // phpcs:ignore
		}
		while ( have_posts() ) :
			the_post();
			if ( 'product' === get_post_type() ) {
				continue;
			}
			?>
			<article class="sp-entry"><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></article>
		<?php endwhile; ?>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p class="sp-empty">ما لقينا شي. جربي كلمة ثانية أو تصفحي <a href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ) ); ?>">كل القطع</a>.</p>
	<?php endif; ?>
</div>
<?php
get_footer();
