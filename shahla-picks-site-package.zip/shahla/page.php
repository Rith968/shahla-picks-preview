<?php
/**
 * Pages (cart, wishlist, policies…).
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	?>
	<div class="sp-container">
		<header class="sp-page-head"><h1><?php the_title(); ?></h1></header>
		<div class="sp-entry<?php echo ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) ? ' sp-entry--wide' : ''; ?>">
			<?php the_content(); ?>
		</div>
	</div>
	<?php
endwhile;
get_footer();
