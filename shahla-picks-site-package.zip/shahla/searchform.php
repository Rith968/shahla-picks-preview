<?php defined( 'ABSPATH' ) || exit; ?>
<form role="search" method="get" class="sp-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="s-<?php echo esc_attr( wp_unique_id() ); ?>">ابحثي في القطع</label>
	<input type="search" name="s" placeholder="ابحثي بالكود أو القماش… مثال: SP-1042" value="<?php echo esc_attr( get_search_query() ); ?>">
	<?php if ( class_exists( 'WooCommerce' ) ) : ?><input type="hidden" name="post_type" value="product"><?php endif; ?>
	<button type="submit" class="sp-btn sp-btn--primary">بحث</button>
</form>
