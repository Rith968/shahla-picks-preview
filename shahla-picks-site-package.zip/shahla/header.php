<?php
/**
 * Header.
 */
defined( 'ABSPATH' ) || exit;
$cart_count = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
$wish_url   = function_exists( 'sp_page_url' ) ? sp_page_url( 'wishlist' ) : '';
$cart_url   = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '#';
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">تخطي إلى المحتوى</a>

<?php if ( spt_opt( 'announcement' ) ) : ?>
<div class="sp-announce"><?php echo esc_html( spt_opt( 'announcement' ) ); ?></div>
<?php endif; ?>

<header class="sp-header" data-sp-header>
	<div class="sp-container sp-header__row">
		<button type="button" class="sp-icon-btn sp-menu-btn" data-sp-menu aria-controls="sp-drawer" aria-expanded="false" aria-label="فتح القائمة"><?php echo spt_icon( 'menu' ); // phpcs:ignore ?></button>
		<a class="sp-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="مختارات شهلاء — الرئيسية"><?php echo sp_theme_logo_svg(); // phpcs:ignore ?></a>
		<nav class="sp-nav" aria-label="القائمة الرئيسية">
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'depth' => 2, 'fallback_cb' => 'spt_menu_fallback' ) ); ?>
		</nav>
		<div class="sp-header__icons">
			<button type="button" class="sp-icon-btn sp-hide-mobile" data-sp-search-toggle aria-expanded="false" aria-controls="sp-search" aria-label="بحث"><?php echo spt_icon( 'search' ); // phpcs:ignore ?></button>
			<?php if ( $wish_url ) : ?>
			<a class="sp-icon-btn sp-hide-mobile" href="<?php echo esc_url( $wish_url ); ?>" aria-label="المفضلة"><?php echo spt_icon( 'heart' ); // phpcs:ignore ?><span class="sp-count" data-sp-wish-count data-count="0">0</span></a>
			<?php endif; ?>
			<a class="sp-icon-btn" href="<?php echo esc_url( $cart_url ); ?>" aria-label="السلة"><?php echo spt_icon( 'bag' ); // phpcs:ignore ?><span class="sp-cart-count" data-count="<?php echo (int) $cart_count; ?>"><?php echo (int) $cart_count; ?></span></a>
		</div>
	</div>
	<div class="sp-search" id="sp-search" hidden>
		<div class="sp-container"><?php get_search_form(); ?></div>
	</div>
</header>

<div class="sp-drawer" id="sp-drawer" hidden>
	<div class="sp-drawer__backdrop" data-sp-close></div>
	<div class="sp-drawer__panel" role="dialog" aria-modal="true" aria-label="القائمة">
		<div class="sp-drawer__head">
			<a class="sp-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="الرئيسية"><?php echo sp_theme_logo_svg(); // phpcs:ignore ?></a>
			<button type="button" class="sp-icon-btn" data-sp-close aria-label="إغلاق القائمة"><?php echo spt_icon( 'close' ); // phpcs:ignore ?></button>
		</div>
		<?php get_search_form(); ?>
		<nav aria-label="قائمة الجوال">
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'depth' => 2, 'fallback_cb' => 'spt_menu_fallback' ) ); ?>
		</nav>
		<nav aria-label="روابط مساعدة">
			<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1, 'fallback_cb' => '__return_false' ) ); ?>
		</nav>
		<div class="sp-drawer__foot">
			<a class="sp-btn sp-btn--wa sp-btn--block" href="<?php echo esc_url( spt_wa_chat_url() ); ?>" target="_blank" rel="noopener"><?php echo spt_icon( 'whatsapp', 20 ); // phpcs:ignore ?><span>كلمينا بالواتساب</span></a>
			<a class="sp-btn sp-btn--ghost sp-btn--block" href="<?php echo esc_url( spt_opt( 'instagram', '#' ) ); ?>" target="_blank" rel="noopener"><?php echo spt_icon( 'insta', 20 ); // phpcs:ignore ?><span>تابعينا على إنستقرام</span></a>
		</div>
	</div>
</div>

<main id="main" class="sp-main">
