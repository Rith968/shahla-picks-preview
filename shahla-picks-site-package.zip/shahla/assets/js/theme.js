/* Shahla theme UI: drawer, search, sticky header. */
(function () {
	'use strict';
	var drawer = document.getElementById('sp-drawer');
	var opener = document.querySelector('[data-sp-menu]');
	var lastFocus = null;

	function openDrawer() {
		lastFocus = document.activeElement;
		drawer.hidden = false;
		requestAnimationFrame(function () { drawer.classList.add('is-open'); });
		opener.setAttribute('aria-expanded', 'true');
		document.documentElement.style.overflow = 'hidden';
		var f = drawer.querySelector('a, button, input');
		if (f) { setTimeout(function () { f.focus(); }, 200); }
	}
	function closeDrawer() {
		drawer.classList.remove('is-open');
		opener.setAttribute('aria-expanded', 'false');
		document.documentElement.style.overflow = '';
		setTimeout(function () { drawer.hidden = true; }, 300);
		if (lastFocus) { lastFocus.focus(); }
	}
	if (drawer && opener) {
		opener.addEventListener('click', openDrawer);
		drawer.addEventListener('click', function (e) { if (e.target.closest('[data-sp-close]')) { closeDrawer(); } });
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !drawer.hidden) { closeDrawer(); } });
	}

	var st = document.querySelector('[data-sp-search-toggle]');
	var sp = document.getElementById('sp-search');
	if (st && sp) {
		st.addEventListener('click', function () {
			sp.hidden = !sp.hidden;
			st.setAttribute('aria-expanded', sp.hidden ? 'false' : 'true');
			if (!sp.hidden) { var i = sp.querySelector('input[type="search"]'); if (i) { i.focus(); } }
		});
	}

	var header = document.querySelector('[data-sp-header]');
	if (header) {
		var onScroll = function () { header.classList.toggle('is-stuck', window.scrollY > 8); };
		window.addEventListener('scroll', onScroll, { passive: true });
		onScroll();
	}
})();
