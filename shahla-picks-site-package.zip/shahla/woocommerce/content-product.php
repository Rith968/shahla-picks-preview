<?php
/**
 * Product card.
 *
 * @version 9.4.0
 */
defined( 'ABSPATH' ) || exit;

global $product;
if ( empty( $product ) || ! $product->is_visible() && 'outofstock' !== $product->get_stock_status() ) {
	return;
}
$state   = function_exists( 'sp_product_state' ) ? sp_product_state( $product ) : ( $product->is_in_stock() ? 'available' : 'sold' );
$link    = get_permalink( $product->get_id() );
$gallery = $product->get_gallery_image_ids();
$len     = function_exists( 'sp_inch' ) ? sp_inch( $product->get_meta( '_sp_length' ) ) : '';
$video   = (bool) $product->get_meta( '_sp_video_id' );
?>
<li <?php wc_product_class( 'sp-card is-' . $state, $product ); ?>>
	<a class="sp-card__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
		<?php
		echo $product->get_image( 'woocommerce_thumbnail', array( 'class' => 'sp-card__img', 'loading' => 'lazy' ) ); // phpcs:ignore
		if ( $gallery ) {
			echo wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, array( 'class' => 'sp-card__alt', 'loading' => 'lazy', 'alt' => '' ) );
		}
		echo function_exists( 'sp_badges_html' ) ? sp_badges_html( $product ) : ''; // phpcs:ignore
		if ( $video ) {
			echo '<span class="sp-card__video" title="فيها فيديو">' . sp_icon( 'play', 14 ) . '</span>'; // phpcs:ignore
		}
		?>
	</a>
	<button type="button" class="sp-wish" data-sp-wish="<?php echo (int) $product->get_id(); ?>" aria-pressed="false" aria-label="<?php echo esc_attr( 'حفظ ' . $product->get_sku() . ' في المفضلة' ); ?>"><?php echo function_exists( 'sp_icon' ) ? sp_icon( 'heart', 20 ) : ''; // phpcs:ignore ?></button>
	<div class="sp-card__body">
		<h3 class="sp-card__title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $product->get_name() ); ?></a></h3>
		<div class="sp-card__meta">
			<?php if ( $product->get_sku() ) : ?><span class="sp-sku"><?php echo esc_html( $product->get_sku() ); ?></span><?php endif; ?>
			<?php if ( $len ) : ?><span>الطول <?php echo esc_html( $len ); ?></span><?php endif; ?>
		</div>
		<div class="sp-card__foot">
			<span class="price"><?php echo wp_kses_post( wc_price( $product->get_price() ) ); ?></span>
			<?php if ( 'available' === $state ) : ?>
				<a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>" data-quantity="1" data-product_id="<?php echo (int) $product->get_id(); ?>" data-product_sku="<?php echo esc_attr( $product->get_sku() ); ?>" class="button sp-add add_to_cart_button ajax_add_to_cart" aria-label="<?php echo esc_attr( 'إضافة ' . $product->get_sku() . ' للسلة' ); ?>" rel="nofollow"><?php echo function_exists( 'sp_icon' ) ? sp_icon( 'bag', 19 ) : '+'; // phpcs:ignore ?></a>
			<?php elseif ( 'sold' === $state && function_exists( 'sp_wa_url' ) ) : ?>
				<a class="sp-similar" href="<?php echo esc_url( sp_wa_url( sp_product_message( $product, 'similar' ) ) ); ?>" target="_blank" rel="noopener"><?php echo sp_icon( 'whatsapp', 15 ); // phpcs:ignore ?> أبغى مثلها</a>
			<?php endif; ?>
		</div>
	</div>
</li>
