<?php
/**
 * WooCommerce layout for the Shahla theme.
 */
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

/* We style everything ourselves. */
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

/* Wrappers */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
add_action( 'woocommerce_before_main_content', function () { echo '<div class="sp-container">'; }, 10 );
add_action( 'woocommerce_after_main_content', function () { echo '</div>'; }, 10 );

add_filter( 'woocommerce_breadcrumb_defaults', function ( $d ) {
	$d['delimiter'] = ' <span aria-hidden="true">/</span> ';
	$d['home']      = 'الرئيسية';
	return $d;
} );

/* Archive: page head + toolbar with filters. */
add_filter( 'woocommerce_show_page_title', '__return_false' );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
add_action( 'woocommerce_archive_description', function () {
	$title = woocommerce_page_title( false );
	echo '<header class="sp-page-head"><h1>' . esc_html( $title ) . '</h1>';
	if ( is_shop() ) {
		echo '<p>كل القطع المتوفرة الآن — كل تصميم قطعة واحدة فقط.</p>';
	}
	echo '</header>';
}, 5 );
add_action( 'woocommerce_before_shop_loop', function () {
	echo '<div class="sp-toolbar">';
	if ( function_exists( 'sp_shop_filters' ) ) {
		echo sp_shop_filters(); // phpcs:ignore
	}
	echo '<div class="sp-toolbar__row">';
	woocommerce_result_count();
	woocommerce_catalog_ordering();
	echo '</div></div>';
}, 15 );
add_action( 'woocommerce_no_products_found', function () {
	echo '<p class="sp-empty">ما في قطع تطابق اختيارك الآن. جربي فلتر ثاني أو <a href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">اعرضي كل القطع</a>.</p>';
}, 5 );
remove_action( 'woocommerce_no_products_found', 'wc_no_products_found', 10 );

add_filter( 'loop_shop_per_page', function () { return 24; } );
add_filter( 'woocommerce_catalog_orderby', function ( $o ) {
	return array(
		'date'       => 'الأحدث',
		'price'      => 'السعر: من الأقل',
		'price-desc' => 'السعر: من الأعلى',
		'popularity' => 'الأكثر طلباً',
	);
} );
add_filter( 'woocommerce_default_catalog_orderby', function () { return 'date'; } );

/* ---------- Single product layout ---------- */
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
add_action( 'woocommerce_before_single_product_summary', function () { echo '<div class="sp-gallery-col">'; }, 5 );
add_action( 'woocommerce_before_single_product_summary', 'spt_product_video', 25 );
add_action( 'woocommerce_before_single_product_summary', function () { echo '</div>'; }, 30 );

function spt_product_video() {
	if ( ! function_exists( 'sp_product_video_url' ) ) {
		return;
	}
	$url = sp_product_video_url( get_the_ID() );
	if ( ! $url ) {
		return;
	}
	echo '<div class="sp-product-video"><p class="sp-product-video__label">' . sp_icon( 'play', 16 ) . ' شاهدي القطعة بالفيديو</p><video src="' . esc_url( $url ) . '" controls playsinline preload="metadata"></video></div>'; // phpcs:ignore
}

remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );

add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( function_exists( 'sp_badges_html' ) ) {
		echo sp_badges_html( $product ); // phpcs:ignore
	}
}, 3 );
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( $product->get_sku() ) {
		echo '<p class="sp-sku-line">كود القطعة: <b>' . esc_html( $product->get_sku() ) . '</b></p>';
	}
}, 7 );
add_action( 'woocommerce_single_product_summary', 'spt_product_specs', 15 );
add_action( 'woocommerce_single_product_summary', 'spt_product_state_note', 18 );
add_action( 'woocommerce_single_product_summary', 'spt_product_actions', 25 );
add_action( 'woocommerce_single_product_summary', 'spt_product_info', 40 );

function spt_product_specs() {
	global $product;
	if ( ! function_exists( 'sp_product_specs' ) ) {
		return;
	}
	$specs = sp_product_specs( $product );
	unset( $specs['الكود'] );
	if ( ! $specs ) {
		return;
	}
	echo '<table class="sp-specs"><tbody>';
	foreach ( $specs as $k => $v ) {
		echo '<tr><th scope="row">' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
	}
	echo '</tbody></table>';
}

function spt_product_state_note() {
	global $product;
	if ( ! function_exists( 'sp_product_state' ) ) {
		return;
	}
	$st = sp_product_state( $product );
	$notes = array(
		'available' => array( 'one', 'قطعة واحدة فقط من هذا التصميم — اطلبيها قبل لا تروح.' ),
		'reserved'  => array( 'reserved', 'هذه القطعة محجوزة حالياً لطلب بانتظار التأكيد. إذا ما تأكد الطلب ترجع متوفرة.' ),
		'sold'      => array( 'sold', 'انباعت هذه القطعة. تقدرين تطلبين قطعة قريبة منها.' ),
	);
	echo '<p class="sp-state-note sp-state-note--' . esc_attr( $st ) . '">' . spt_icon( 'one', 18 ) . '<span>' . esc_html( $notes[ $st ][1] ) . '</span></p>'; // phpcs:ignore
}

function spt_product_actions() {
	global $product;
	echo '<div class="sp-actions">';
	if ( function_exists( 'sp_whatsapp_button' ) ) {
		echo sp_whatsapp_button( $product, 'sp-btn--block' ); // phpcs:ignore
	}
	if ( $product->is_in_stock() ) {
		woocommerce_template_single_add_to_cart();
	}
	echo '</div>';
	echo '<div class="sp-mini-actions">';
	echo '<button type="button" data-sp-wish="' . (int) $product->get_id() . '" aria-pressed="false">' . sp_icon( 'heart', 18 ) . '<span>المفضلة</span></button>'; // phpcs:ignore
	echo '<button type="button" data-sp-share data-url="' . esc_url( get_permalink() ) . '" data-title="' . esc_attr( $product->get_name() . ' — ' . $product->get_sku() ) . '">' . sp_icon( 'share', 18 ) . '<span>شاركيها</span></button>'; // phpcs:ignore
	echo '</div>';
}

function spt_product_info() {
	$pickup = function_exists( 'sp_opt' ) && 'yes' === sp_opt( 'pickup_enabled' ) ? sp_opt( 'pickup_location' ) : '';
	$size   = function_exists( 'sp_page_url' ) ? sp_page_url( 'size' ) : '';
	echo '<ul class="sp-info">';
	echo '<li>' . sp_icon( 'truck', 18 ) . '<span>التوصيل داخل السلطنة، والرسوم تظهر لك عند الطلب.</span></li>'; // phpcs:ignore
	if ( $pickup ) {
		echo '<li>' . sp_icon( 'pin', 18 ) . '<span>استلام متاح من ' . esc_html( $pickup ) . '.</span></li>'; // phpcs:ignore
	}
	if ( $size ) {
		echo '<li>' . sp_icon( 'ruler', 18 ) . '<span>مو متأكدة من المقاس؟ <a href="' . esc_url( $size ) . '">دليل المقاسات</a></span></li>'; // phpcs:ignore
	}
	echo '<li>' . sp_icon( 'whatsapp', 18 ) . '<span>أي سؤال؟ <a href="' . esc_url( spt_wa_chat_url() ) . '" target="_blank" rel="noopener">كلمينا بالواتساب</a></span></li>'; // phpcs:ignore
	echo '</ul>';
}

/* Tabs: description only, renamed. */
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	unset( $tabs['reviews'], $tabs['additional_information'] );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['title'] = 'التفاصيل';
	}
	return $tabs;
}, 98 );
add_filter( 'woocommerce_product_description_heading', '__return_empty_string' );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
add_filter( 'woocommerce_output_related_products_args', function ( $a ) {
	$a['posts_per_page'] = 4;
	$a['columns']        = 4;
	return $a;
} );
add_filter( 'woocommerce_product_related_products_heading', function () { return 'قطع ممكن تعجبك'; } );
/* Related: only pieces still available. */
add_filter( 'woocommerce_related_products', function ( $ids ) {
	return array_values( array_filter( $ids, function ( $id ) {
		$p = wc_get_product( $id );
		return $p && $p->is_in_stock();
	} ) );
} );

/* Cart: show code + length under the name. */
add_filter( 'woocommerce_cart_item_name', function ( $name, $item ) {
	$p = $item['data'];
	if ( ! $p || ! function_exists( 'sp_product_specs' ) ) {
		return $name;
	}
	$s    = sp_product_specs( $p );
	$bits = array_filter( array( $s['الكود'] ?? '', isset( $s['الطول'] ) ? 'الطول ' . $s['الطول'] : '' ) );
	return $name . ( $bits ? '<span class="sp-cart-meta">' . esc_html( implode( ' · ', $bits ) ) . '</span>' : '' );
}, 10, 2 );

/* Single product mobile buy bar. */
add_action( 'wp_footer', function () {
	if ( ! is_product() || ! function_exists( 'sp_whatsapp_button' ) ) {
		return;
	}
	$product = wc_get_product( get_the_ID() );
	if ( ! $product ) {
		return;
	}
	echo '<div class="sp-buybar" data-sp-buybar><div class="sp-buybar__info"><b>' . esc_html( $product->get_sku() ) . '</b><span>' . wp_kses_post( wc_price( $product->get_price() ) ) . '</span></div>';
	echo sp_whatsapp_button( $product ); // phpcs:ignore
	if ( $product->is_in_stock() ) {
		echo '<a href="' . esc_url( $product->add_to_cart_url() ) . '" data-quantity="1" data-product_id="' . (int) $product->get_id() . '" class="button sp-add add_to_cart_button ajax_add_to_cart" aria-label="أضيفي للسلة" rel="nofollow">' . sp_icon( 'bag', 20 ) . '</a>'; // phpcs:ignore
	}
	echo '</div>';
}, 5 );
