<?php
/**
 * Installable web app: manifest + a minimal service worker.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	add_rewrite_rule( '^sp-manifest\.webmanifest$', 'index.php?sp_pwa=manifest', 'top' );
	add_rewrite_rule( '^sp-sw\.js$', 'index.php?sp_pwa=sw', 'top' );
} );
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'sp_pwa';
	return $v;
} );

function spt_pwa_url( $what ) {
	return get_option( 'permalink_structure' ) ? home_url( 'manifest' === $what ? '/sp-manifest.webmanifest' : '/sp-sw.js' ) : add_query_arg( 'sp_pwa', $what, home_url( '/' ) );
}

add_action( 'template_redirect', function () {
	$what = get_query_var( 'sp_pwa' );
	if ( ! $what ) {
		return;
	}
	$img = get_template_directory_uri() . '/assets/img/';
	if ( 'manifest' === $what ) {
		header( 'Content-Type: application/manifest+json; charset=utf-8' );
		echo wp_json_encode( array(
			'name'             => 'مختارات شهلاء',
			'short_name'       => 'شهلاء',
			'description'      => 'مخورات حرير إيطالي — قطعة واحدة من كل تصميم',
			'lang'             => 'ar',
			'dir'              => 'rtl',
			'start_url'        => home_url( '/?source=pwa' ),
			'scope'            => home_url( '/' ),
			'display'          => 'standalone',
			'background_color' => '#faf6f2',
			'theme_color'      => '#663634',
			'icons'            => array(
				array( 'src' => $img . 'icon-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable' ),
				array( 'src' => $img . 'icon-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable' ),
			),
		), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		exit;
	}
	if ( 'sw' === $what ) {
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Service-Worker-Allowed: /' );
		// Network-first for pages (cart/stock must be fresh); cache-first for theme assets.
		?>
const C = 'shahla-v<?php echo esc_js( SPT_VER ); ?>';
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== C).map(x => caches.delete(x)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {
	const r = e.request;
	if (r.method !== 'GET' || new URL(r.url).origin !== location.origin) return;
	const u = new URL(r.url);
	if (u.pathname.includes('/wp-admin') || u.pathname.includes('/wp-json') || u.search.includes('wc-ajax') || u.pathname.includes('/cart') || u.pathname.includes('/checkout')) return;
	if (/\.(css|js|woff2?|png|jpg|jpeg|webp|svg)$/.test(u.pathname)) {
		e.respondWith(caches.open(C).then(c => c.match(r).then(m => m || fetch(r).then(res => { if (res.ok) c.put(r, res.clone()); return res; }))));
	}
});
		<?php
		exit;
	}
} );

add_action( 'wp_head', function () {
	echo '<link rel="manifest" href="' . esc_url( spt_pwa_url( 'manifest' ) ) . '">' . "\n";
	echo '<meta name="theme-color" content="#663634">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( get_template_directory_uri() . '/assets/img/icon-180.png' ) . '">' . "\n";
	echo '<meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="شهلاء">' . "\n";
}, 2 );

add_action( 'wp_footer', function () {
	// Not inside WordPress Playground (it runs on its own service worker).
	if ( false !== strpos( home_url(), 'playground.wordpress.net' ) || false !== strpos( home_url(), 'scope:' ) ) {
		return;
	}
	echo "<script>if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register(" . wp_json_encode( spt_pwa_url( 'sw' ) ) . ").catch(function(){});});}</script>\n";
}, 99 );
