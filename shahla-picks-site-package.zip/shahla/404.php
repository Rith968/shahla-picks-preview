<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="sp-container sp-404">
	<div class="sp-logo"><?php echo sp_theme_logo_svg(); // phpcs:ignore ?></div>
	<h1>الصفحة مو موجودة</h1>
	<p>يمكن القطعة انباعت أو الرابط تغيّر.</p>
	<a class="sp-btn sp-btn--primary" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ) ); ?>">تصفحي القطع المتوفرة</a>
</div>
<?php
get_footer();
