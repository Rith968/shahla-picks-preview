<?php
/**
 * Plugin Name:       Shahla Core — مختارات شهلاء
 * Description:       خصائص متجر مختارات شهلاء: الطلب عبر واتساب، حجز القطع تلقائياً، البانرات بالفيديو، البازارات، آراء العميلات، بطاقات QR، الإطلاقات المجدولة، المفضلة، تتبع الطلب، والمشتركات.
 * Version:           1.0.0
 * Author:            Alharith
 * Text Domain:       shahla-core
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 */

defined( 'ABSPATH' ) || exit;

define( 'SP_CORE_VER', '1.0.0' );
define( 'SP_CORE_FILE', __FILE__ );
define( 'SP_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'SP_CORE_URL', plugin_dir_url( __FILE__ ) );

foreach ( array( 'helpers', 'settings', 'product', 'reservations', 'whatsapp', 'checkout', 'banners', 'events', 'reviews', 'drops', 'subscribers', 'qr', 'pages', 'admin', 'importer' ) as $sp_file ) {
	require_once SP_CORE_DIR . 'inc/' . $sp_file . '.php';
}

register_activation_hook( __FILE__, 'sp_core_activate' );
function sp_core_activate() {
	sp_subscribers_install();
	if ( ! wp_next_scheduled( 'sp_release_expired' ) ) {
		wp_schedule_event( time() + 300, 'sp_quarter_hour', 'sp_release_expired' );
	}
	sp_register_banner_cpt();
	sp_register_event_cpt();
	sp_register_review_cpt();
	flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'sp_release_expired' );
} );

add_filter( 'cron_schedules', function ( $s ) {
	$s['sp_quarter_hour'] = array( 'interval' => 900, 'display' => 'كل ربع ساعة' );
	return $s;
} );

/** Front-end assets shared by theme + plugin features. */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_script( 'sp-front', SP_CORE_URL . 'assets/js/sp-front.js', array(), SP_CORE_VER, true );
	wp_localize_script( 'sp-front', 'SP', array(
		'ajax'     => admin_url( 'admin-ajax.php' ),
		'rest'     => esc_url_raw( rest_url( 'sp/v1/' ) ),
		'nonce'    => wp_create_nonce( 'sp_front' ),
		'fees'     => sp_fees(),
		'currency' => html_entity_decode( get_woocommerce_currency_symbol() ),
		'decimals' => 3,
		'wa'       => sp_wa_number(),
		'i18n'     => array(
			'added'      => 'أُضيفت للمفضلة',
			'removed'    => 'أُزيلت من المفضلة',
			'empty'      => 'ما في قطع في المفضلة بعد. اضغطي على القلب في أي قطعة لحفظها هنا.',
			'sending'    => 'جاري تجهيز طلبك…',
			'error'      => 'صار خطأ، حاولي مرة ثانية أو تواصلي معنا بالواتساب.',
			'feeAsk'     => 'تُحدَّد عبر الواتساب',
			'free'       => 'مجاناً',
			'copied'     => 'تم نسخ الرابط',
		),
	) );
} );
