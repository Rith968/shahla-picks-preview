<?php
/**
 * Shared helpers.
 */
defined( 'ABSPATH' ) || exit;

function sp_settings_defaults() {
	return array(
		'whatsapp'        => '',
		'hold_hours'      => 24,
		'announcement'    => 'حرير إيطالي · قطعة واحدة من كل تصميم · تسليم فوري',
		'pickup_enabled'  => 'yes',
		'pickup_location' => 'بوشر، مسقط',
		'fees'            => array(),
		'online_payment'  => 'no',
		'instagram'       => 'https://www.instagram.com/shahlapicks/',
		'hero_title'      => 'مخورات حرير إيطالي',
		'hero_text'       => 'تصاميم مطرّزة مختارة بعناية، وكل تصميم قطعة واحدة فقط.',
		'msg_intro'       => 'السلام عليكم، حابة أطلب من مختارات شهلاء:',
		'new_days'        => 21,
	);
}

function sp_opt( $key, $default = null ) {
	static $cache = null;
	if ( null === $cache ) {
		$cache = wp_parse_args( (array) get_option( 'sp_settings', array() ), sp_settings_defaults() );
	}
	if ( isset( $cache[ $key ] ) && '' !== $cache[ $key ] ) {
		return $cache[ $key ];
	}
	return null !== $default ? $default : ( sp_settings_defaults()[ $key ] ?? '' );
}

/** Oman's 11 governorates. */
function sp_governorates() {
	return array(
		'muscat'         => 'مسقط',
		'dhofar'         => 'ظفار',
		'musandam'       => 'مسندم',
		'buraimi'        => 'البريمي',
		'dakhiliyah'     => 'الداخلية',
		'north_batinah'  => 'شمال الباطنة',
		'south_batinah'  => 'جنوب الباطنة',
		'south_sharqiyah'=> 'جنوب الشرقية',
		'north_sharqiyah'=> 'شمال الشرقية',
		'dhahirah'       => 'الظاهرة',
		'wusta'          => 'الوسطى',
	);
}

/** Delivery fee per governorate; '' means "agreed on WhatsApp". */
function sp_fees() {
	$fees = (array) sp_opt( 'fees', array() );
	$out  = array();
	foreach ( sp_governorates() as $k => $label ) {
		$out[ $k ] = ( isset( $fees[ $k ] ) && '' !== $fees[ $k ] ) ? (float) $fees[ $k ] : '';
	}
	return $out;
}

function sp_wa_number() {
	$n = preg_replace( '/\D+/', '', (string) sp_opt( 'whatsapp', '' ) );
	if ( 8 === strlen( $n ) ) {
		$n = '968' . $n;
	}
	return $n;
}

function sp_wa_url( $text, $to = null ) {
	$to = null === $to ? sp_wa_number() : preg_replace( '/\D+/', '', (string) $to );
	return 'https://wa.me/' . $to . '?text=' . rawurlencode( $text );
}

/** Plain-text money for WhatsApp messages: "12 ر.ع." */
function sp_money( $amount ) {
	$html = wc_price( $amount );
	$txt  = html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' );
	return trim( preg_replace( '/[\x{200E}\x{200F}\x{00A0}]+/u', ' ', $txt ) );
}

function sp_inch( $v ) {
	if ( '' === $v || null === $v ) {
		return '';
	}
	$v = (float) $v;
	return ( floor( $v ) == $v ? (int) $v : rtrim( rtrim( number_format( $v, 1, '.', '' ), '0' ), '.' ) ) . ' إنش';
}

/** Product specs as label => value (only filled ones). */
function sp_product_specs( $product ) {
	$product = wc_get_product( $product );
	if ( ! $product ) {
		return array();
	}
	$specs = array(
		'الكود'  => $product->get_sku(),
		'الطول'  => sp_inch( $product->get_meta( '_sp_length' ) ),
		'العرض'  => sp_inch( $product->get_meta( '_sp_width' ) ),
		'القماش' => $product->get_meta( '_sp_fabric' ),
	);
	return array_filter( $specs, function ( $v ) { return '' !== (string) $v; } );
}

/** available | reserved | sold */
function sp_product_state( $product ) {
	$product = wc_get_product( $product );
	if ( ! $product ) {
		return 'sold';
	}
	if ( $product->is_in_stock() ) {
		return 'available';
	}
	$until = (int) $product->get_meta( '_sp_reserved_until' );
	return ( $until && $until > time() ) ? 'reserved' : 'sold';
}

function sp_is_new( $product ) {
	$product = wc_get_product( $product );
	if ( ! $product || ! $product->get_date_created() ) {
		return false;
	}
	return ( time() - $product->get_date_created()->getTimestamp() ) < DAY_IN_SECONDS * (int) sp_opt( 'new_days', 21 );
}

/** Badges for a product card / page: array of [class, label]. */
function sp_product_badges( $product ) {
	$state  = sp_product_state( $product );
	$badges = array();
	if ( 'sold' === $state ) {
		$badges[] = array( 'sold', 'تم البيع' );
	} elseif ( 'reserved' === $state ) {
		$badges[] = array( 'reserved', 'محجوزة' );
	} else {
		if ( sp_is_new( $product ) ) {
			$badges[] = array( 'new', 'جديد' );
		}
		$badges[] = array( 'one', 'قطعة واحدة' );
	}
	return $badges;
}

function sp_badges_html( $product ) {
	$out = '';
	foreach ( sp_product_badges( $product ) as $b ) {
		$out .= '<span class="sp-badge sp-badge--' . esc_attr( $b[0] ) . '">' . esc_html( $b[1] ) . '</span>';
	}
	return $out ? '<div class="sp-badges">' . $out . '</div>' : '';
}

/** Simple inline icons used by plugin markup. */
function sp_icon( $name, $size = 20 ) {
	$paths = array(
		'whatsapp' => '<path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.79-1.47-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.07 2.88 1.21 3.07.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.09 1.75-.72 2-1.41.25-.69.25-1.29.17-1.41-.07-.12-.27-.2-.57-.35M12.05 21.5h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88 2.64 0 5.12 1.03 6.99 2.9a9.82 9.82 0 0 1 2.89 6.99c0 5.45-4.44 9.88-9.88 9.88M20.46 3.49A11.82 11.82 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.88 11.88 0 0 0 5.68 1.45h.01c6.55 0 11.89-5.34 11.89-11.89 0-3.18-1.24-6.16-3.48-8.41" fill="currentColor"/>',
		'heart'    => '<path d="M12 20.5s-7.5-4.6-9.4-9.3C1.2 7.7 3.4 4 7 4c2 0 3.4 1.1 5 3 1.6-1.9 3-3 5-3 3.6 0 5.8 3.7 4.4 7.2-1.9 4.7-9.4 9.3-9.4 9.3z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
		'share'    => '<path d="M15 8a3 3 0 1 0-2.9-3.8L8.6 6.3a3 3 0 1 0 0 5.4l3.5 2.1A3 3 0 1 0 13 12.1L9.5 10a3 3 0 0 0 0-.9l3.6-2.1A3 3 0 0 0 15 8z" fill="none" stroke="currentColor" stroke-width="1.6" transform="translate(1 2)"/>',
		'bag'      => '<path d="M5 8h14l-1.2 12.1a1 1 0 0 1-1 .9H7.2a1 1 0 0 1-1-.9L5 8z M9 8V6.5a3 3 0 0 1 6 0V8" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
		'clock'    => '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
		'pin'      => '<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="9.5" r="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/>',
		'truck'    => '<path d="M2 6h11v10H2zM13 10h4l4 3v3h-8z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><circle cx="6" cy="17.5" r="1.8" fill="#fff" stroke="currentColor" stroke-width="1.6"/><circle cx="17" cy="17.5" r="1.8" fill="#fff" stroke="currentColor" stroke-width="1.6"/>',
		'ruler'    => '<path d="M3 16.5 16.5 3 21 7.5 7.5 21z M7 12.5l1.8 1.8 M10 9.5l1.8 1.8 M13 6.5l1.8 1.8" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
		'star'     => '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z" fill="currentColor"/>',
		'sound'    => '<path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor"/><path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
		'mute'     => '<path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor"/><path d="m16 9 5 6m0-6-5 6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
		'check'    => '<path d="m5 12.5 4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
		'play'     => '<path d="M8 5v14l11-7z" fill="currentColor"/>',
		'gift'     => '<path d="M4 11h16v9H4zM3 7h18v4H3zM12 7v13M12 7c-1.5-3-5-3.5-5-1.2C7 7 9.5 7 12 7zm0 0c1.5-3 5-3.5 5-1.2C17 7 14.5 7 12 7z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	return '<svg class="sp-ico sp-ico--' . esc_attr( $name ) . '" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
}

/** Render a list of products as cards using the theme's card template. */
function sp_render_product_cards( $ids, $class = '' ) {
	if ( empty( $ids ) ) {
		return '';
	}
	ob_start();
	echo '<ul class="products sp-grid ' . esc_attr( $class ) . '">';
	foreach ( $ids as $id ) {
		$GLOBALS['post'] = get_post( $id ); // phpcs:ignore
		setup_postdata( $GLOBALS['post'] );
		$GLOBALS['product'] = wc_get_product( $id ); // phpcs:ignore
		wc_get_template_part( 'content', 'product' );
	}
	echo '</ul>';
	wp_reset_postdata();
	return ob_get_clean();
}

/** IDs of products currently on sale (not sold, reserved allowed). */
function sp_query_products( $args = array() ) {
	$args = wp_parse_args( $args, array(
		'state'    => 'available', // available | sold | any
		'limit'    => 8,
		'orderby'  => 'date',
		'order'    => 'DESC',
		'category' => '',
		'exclude'  => array(),
	) );
	$q = array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => (int) $args['limit'],
		'orderby'        => $args['orderby'],
		'order'          => $args['order'],
		'fields'         => 'ids',
		'post__not_in'   => (array) $args['exclude'],
		'no_found_rows'  => true,
	);
	if ( 'available' === $args['state'] ) {
		$q['meta_query'] = array( array( 'key' => '_stock_status', 'value' => 'outofstock', 'compare' => '!=' ) );
	} elseif ( 'sold' === $args['state'] ) {
		$q['meta_query'] = array(
			'relation' => 'AND',
			array( 'key' => '_stock_status', 'value' => 'outofstock' ),
			array(
				'relation' => 'OR',
				array( 'key' => '_sp_reserved_until', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_sp_reserved_until', 'value' => time(), 'type' => 'NUMERIC', 'compare' => '<' ),
			),
		);
	}
	if ( $args['category'] ) {
		$q['tax_query'] = array( array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => $args['category'] ) );
	}
	return get_posts( $q );
}

/* "12 ر.ع." instead of "12.000 ر.ع." */
add_filter( 'woocommerce_price_trim_zeros', '__return_true' );
