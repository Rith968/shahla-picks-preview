<?php
/**
 * Scheduled drops: products scheduled for a future date show a countdown on the homepage.
 */
defined( 'ABSPATH' ) || exit;

/** Next drop: [timestamp, count] or null. */
function sp_next_drop() {
	$ids = get_posts( array(
		'post_type' => 'product', 'post_status' => 'future', 'posts_per_page' => 50, 'fields' => 'ids',
		'orderby' => 'date', 'order' => 'ASC',
	) );
	if ( ! $ids ) {
		return null;
	}
	$first = get_post_time( 'U', true, $ids[0] );
	$count = 0;
	foreach ( $ids as $id ) {
		if ( abs( get_post_time( 'U', true, $id ) - $first ) <= HOUR_IN_SECONDS ) {
			$count++;
		}
	}
	return array( (int) $first, $count );
}

function sp_render_drop() {
	$d = sp_next_drop();
	if ( ! $d ) {
		return;
	}
	list( $ts, $count ) = $d;
	?>
	<section class="sp-drop" data-sp-drop="<?php echo esc_attr( $ts ); ?>">
		<div class="sp-container sp-drop__inner">
			<div>
				<p class="sp-eyebrow">إطلاق جديد</p>
				<h2 class="sp-drop__title"><?php echo esc_html( sprintf( '%d قطعة جديدة تنزل %s', $count, wp_date( 'l، j F — g:i a', $ts ) ) ); ?></h2>
				<p class="sp-drop__note">كل قطعة وحدة بس، فاللي تسبق تاخذ.</p>
			</div>
			<div class="sp-countdown" role="timer" aria-live="off">
				<div><span data-u="d">00</span><small>يوم</small></div>
				<div><span data-u="h">00</span><small>ساعة</small></div>
				<div><span data-u="m">00</span><small>دقيقة</small></div>
				<div><span data-u="s">00</span><small>ثانية</small></div>
			</div>
		</div>
	</section>
	<?php
}

/* Admin hint on the product screen. */
add_action( 'post_submitbox_misc_actions', function ( $post ) {
	if ( 'product' === $post->post_type ) {
		echo '<div class="misc-pub-section sp-hint">لإطلاق القطعة في وقت محدد: اضغطي "تعديل" بجانب <strong>النشر فوراً</strong> واختاري الموعد. يظهر عدّاد تنازلي في الصفحة الرئيسية.</div>';
	}
} );
