<?php
/**
 * WhatsApp ordering: product button (direct), cart → recorded order → WhatsApp.
 */
defined( 'ABSPATH' ) || exit;

/** Message for a single piece. $type: order | similar | notify */
function sp_product_message( $product, $type = 'order' ) {
	$product = wc_get_product( $product );
	if ( ! $product ) {
		return '';
	}
	$sku  = $product->get_sku();
	$link = get_permalink( $product->get_id() );
	if ( 'similar' === $type ) {
		return "السلام عليكم، أعجبتني هذه القطعة ({$sku}) وانباعت، أبغى قطعة مشابهة لها. هل يتوفر شي قريب منها؟\n{$link}";
	}
	if ( 'notify' === $type ) {
		return "السلام عليكم، القطعة {$sku} محجوزة حالياً. أبغى أكون أول من يعرف إذا رجعت متوفرة.\n{$link}";
	}
	$lines   = array( sp_opt( 'msg_intro' ), '' );
	$lines[] = $product->get_name();
	foreach ( sp_product_specs( $product ) as $label => $value ) {
		$lines[] = $label . ': ' . $value;
	}
	$lines[] = 'السعر: ' . sp_money( $product->get_price() );
	$lines[] = '';
	$lines[] = $link;
	return implode( "\n", $lines );
}

/** Primary WhatsApp action for a product, depending on its state. */
function sp_whatsapp_button( $product, $class = '' ) {
	$product = wc_get_product( $product );
	if ( ! $product ) {
		return '';
	}
	$state = sp_product_state( $product );
	$map   = array(
		'available' => array( 'order', 'اطلبي عبر واتساب' ),
		'reserved'  => array( 'notify', 'أبلغيني إذا توفرت' ),
		'sold'      => array( 'similar', 'أبغى مثلها' ),
	);
	list( $type, $label ) = $map[ $state ];
	return sprintf(
		'<a class="sp-btn sp-btn--wa %s" href="%s" target="_blank" rel="noopener" data-sp-wa="%s">%s<span>%s</span></a>',
		esc_attr( $class ),
		esc_url( sp_wa_url( sp_product_message( $product, $type ) ) ),
		esc_attr( $type ),
		sp_icon( 'whatsapp', 20 ),
		esc_html( $label )
	);
}

/* ---------- Cart panel ---------- */
function sp_cart_whatsapp_panel() {
	if ( ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}
	$govs   = sp_governorates();
	$pickup = 'yes' === sp_opt( 'pickup_enabled' );
	?>
	<section class="sp-wa-panel" id="sp-wa-panel" aria-labelledby="sp-wa-title">
		<h2 id="sp-wa-title" class="sp-wa-panel__title"><?php echo sp_icon( 'whatsapp', 22 ); // phpcs:ignore ?> أرسلي طلبك عبر واتساب</h2>
		<p class="sp-wa-panel__lead">املئي بياناتك وبنجهز لك رسالة فيها كل القطع، وعليك بس تضغطين <strong>إرسال</strong>. القطع تنحجز لك <?php echo esc_html( (int) sp_opt( 'hold_hours' ) ); ?> ساعة لين نأكد الطلب.</p>
		<form class="sp-wa-form" data-sp-wa-form novalidate>
			<div class="sp-field">
				<label for="sp-name">الاسم</label>
				<input id="sp-name" name="name" type="text" autocomplete="name" required>
			</div>
			<div class="sp-field">
				<label for="sp-phone">رقم الجوال</label>
				<input id="sp-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" dir="ltr" placeholder="9XXXXXXX" required>
			</div>
			<fieldset class="sp-field sp-method">
				<legend>طريقة الاستلام</legend>
				<label class="sp-radio"><input type="radio" name="method" value="delivery" checked> <span><?php echo sp_icon( 'truck', 18 ); // phpcs:ignore ?> توصيل</span></label>
				<?php if ( $pickup ) : ?>
				<label class="sp-radio"><input type="radio" name="method" value="pickup"> <span><?php echo sp_icon( 'pin', 18 ); // phpcs:ignore ?> استلام من <?php echo esc_html( sp_opt( 'pickup_location' ) ); ?></span></label>
				<?php endif; ?>
			</fieldset>
			<div class="sp-field-row" data-sp-delivery>
				<div class="sp-field">
					<label for="sp-gov">المحافظة</label>
					<select id="sp-gov" name="gov">
						<?php foreach ( $govs as $k => $label ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="sp-field">
					<label for="sp-area">الولاية / المنطقة</label>
					<input id="sp-area" name="area" type="text" autocomplete="address-level2">
				</div>
			</div>
			<details class="sp-gift">
				<summary><?php echo sp_icon( 'gift', 18 ); // phpcs:ignore ?> الطلب هدية؟</summary>
				<div class="sp-field">
					<label for="sp-gift-note">نص بطاقة الإهداء (اختياري)</label>
					<textarea id="sp-gift-note" name="gift_note" rows="2"></textarea>
					<input type="hidden" name="gift" value="0">
				</div>
			</details>
			<div class="sp-field">
				<label for="sp-notes">ملاحظات (اختياري)</label>
				<textarea id="sp-notes" name="notes" rows="2"></textarea>
			</div>
			<dl class="sp-wa-summary" data-sp-summary>
				<div><dt>المجموع</dt><dd data-sp-subtotal data-value="<?php echo esc_attr( WC()->cart->get_total( 'edit' ) ); ?>"><?php echo wp_kses_post( wc_price( WC()->cart->get_total( 'edit' ) ) ); ?></dd></div>
				<div><dt>التوصيل</dt><dd data-sp-fee>—</dd></div>
				<div class="sp-wa-summary__total"><dt>الإجمالي</dt><dd data-sp-total>—</dd></div>
			</dl>
			<p class="sp-form-error" role="alert" hidden></p>
			<button type="submit" class="sp-btn sp-btn--wa sp-btn--block"><?php echo sp_icon( 'whatsapp', 22 ); // phpcs:ignore ?><span>إرسال الطلب عبر واتساب</span></button>
			<p class="sp-wa-panel__note">لن يُطلب منك أي دفع الآن. نتواصل معك في الواتساب لتأكيد الطلب والتوصيل.</p>
		</form>
		<div class="sp-wa-done" data-sp-wa-done hidden>
			<div class="sp-wa-done__icon"><?php echo sp_icon( 'check', 34 ); // phpcs:ignore ?></div>
			<h3>تم تجهيز طلبك <span data-sp-order-no></span></h3>
			<p>إذا ما انفتح الواتساب تلقائياً اضغطي الزر، وبعدها اضغطي <strong>إرسال</strong>.</p>
			<a class="sp-btn sp-btn--wa sp-btn--block" data-sp-wa-link href="#" target="_blank" rel="noopener"><?php echo sp_icon( 'whatsapp', 22 ); // phpcs:ignore ?><span>فتح الواتساب</span></a>
		</div>
	</section>
	<?php
}

/* ---------- AJAX: create the order and return the WhatsApp link ---------- */
add_action( 'wp_ajax_sp_wa_order', 'sp_ajax_wa_order' );
add_action( 'wp_ajax_nopriv_sp_wa_order', 'sp_ajax_wa_order' );

function sp_ajax_wa_order() {
	check_ajax_referer( 'sp_front', 'nonce' );
	$cart = WC()->cart;
	if ( ! $cart || $cart->is_empty() ) {
		wp_send_json_error( array( 'message' => 'السلة فاضية.' ) );
	}
	$name   = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
	$phone  = preg_replace( '/[^\d+]/', '', wp_unslash( $_POST['phone'] ?? '' ) );
	$method = 'pickup' === ( $_POST['method'] ?? '' ) && 'yes' === sp_opt( 'pickup_enabled' ) ? 'pickup' : 'delivery';
	$govs   = sp_governorates();
	$gov    = sanitize_key( $_POST['gov'] ?? '' );
	$gov    = isset( $govs[ $gov ] ) ? $gov : 'muscat';
	$area   = sanitize_text_field( wp_unslash( $_POST['area'] ?? '' ) );
	$gift   = sanitize_textarea_field( wp_unslash( $_POST['gift_note'] ?? '' ) );
	$isgift = ! empty( $_POST['gift'] ) && '0' !== $_POST['gift'];
	$notes  = sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) );

	if ( mb_strlen( $name ) < 2 ) {
		wp_send_json_error( array( 'message' => 'اكتبي اسمك لو سمحتي.', 'field' => 'name' ) );
	}
	if ( strlen( preg_replace( '/\D/', '', $phone ) ) < 8 ) {
		wp_send_json_error( array( 'message' => 'رقم الجوال غير صحيح.', 'field' => 'phone' ) );
	}

	// Every piece must still be available.
	foreach ( $cart->get_cart() as $key => $ci ) {
		$p = $ci['data'];
		if ( ! $p || ! $p->is_in_stock() ) {
			$cart->remove_cart_item( $key );
			wp_send_json_error( array( 'message' => 'للأسف القطعة ' . ( $p ? $p->get_sku() : '' ) . ' انحجزت أو انباعت قبل لحظات، وشلناها من السلة.', 'reload' => true ) );
		}
	}

	try {
		$order = wc_create_order( array( 'customer_id' => get_current_user_id(), 'created_via' => 'sp_whatsapp' ) );
		foreach ( $cart->get_cart() as $ci ) {
			$order->add_product( $ci['data'], max( 1, (int) $ci['quantity'] ) );
		}
		$fees = sp_fees();
		$fee  = 'delivery' === $method ? $fees[ $gov ] : 0;
		if ( 'delivery' === $method && '' !== $fee && $fee > 0 ) {
			$item = new WC_Order_Item_Fee();
			$item->set_name( 'التوصيل (' . $govs[ $gov ] . ')' );
			$item->set_amount( $fee );
			$item->set_total( $fee );
			$item->set_tax_status( 'none' );
			$order->add_item( $item );
		}
		$order->set_billing_first_name( $name );
		$order->set_billing_phone( $phone );
		$order->set_billing_country( 'OM' );
		$order->set_billing_state( $govs[ $gov ] );
		$order->set_billing_city( $area );
		$order->set_billing_address_1( 'delivery' === $method ? trim( $govs[ $gov ] . ' - ' . $area, ' -' ) : 'استلام: ' . sp_opt( 'pickup_location' ) );
		$note = $notes;
		if ( $isgift || $gift ) {
			$note .= ( $note ? "\n" : '' ) . 'هدية' . ( $gift ? ': ' . $gift : '' );
		}
		$order->set_customer_note( $note );
		$order->update_meta_data( '_sp_method', $method );
		$order->update_meta_data( '_sp_gov', $gov );
		$order->calculate_totals( false );
		foreach ( $cart->get_applied_coupons() as $code ) {
			$order->apply_coupon( $code );
		}
		$expires = time() + HOUR_IN_SECONDS * (int) sp_opt( 'hold_hours' );
		$order->update_meta_data( '_sp_expires', $expires );
		$order->set_status( 'sp-awaiting', 'طلب جديد عبر الواتساب — القطع محجوزة لين التأكيد.' );
		$order->save();
		wc_reduce_stock_levels( $order->get_id() );
		// Flag the order so WooCommerce restores the pieces if it gets cancelled.
		$order->get_data_store()->set_stock_reduced( $order->get_id(), true );
		sp_reserve_order_items( wc_get_order( $order->get_id() ), $expires );
	} catch ( Exception $e ) {
		wp_send_json_error( array( 'message' => 'تعذر إنشاء الطلب: ' . $e->getMessage() ) );
	}

	$order = wc_get_order( $order->get_id() );
	$text  = sp_order_message( $order, array( 'fee_known' => '' !== $fee, 'gov' => $govs[ $gov ], 'area' => $area, 'method' => $method, 'gift' => $isgift || $gift, 'gift_note' => $gift, 'notes' => $notes ) );
	$cart->empty_cart();
	wp_send_json_success( array(
		'url'      => sp_wa_url( $text ),
		'order'    => '#' . $order->get_order_number(),
		'text'     => $text,
	) );
}

/** Build the order message sent to the shop's WhatsApp. */
function sp_order_message( $order, $ctx ) {
	$l   = array( sp_opt( 'msg_intro' ), 'رقم الطلب: #' . $order->get_order_number(), '' );
	$i   = 0;
	foreach ( $order->get_items() as $item ) {
		$p = $item->get_product();
		$i++;
		$specs = $p ? sp_product_specs( $p ) : array();
		$sku   = $specs['الكود'] ?? '';
		unset( $specs['الكود'] );
		$l[] = $i . ') ' . trim( $sku . ' — ' . $item->get_name(), ' —' );
		$bits = array();
		foreach ( $specs as $k => $v ) {
			$bits[] = $k . ' ' . $v;
		}
		$bits[] = sp_money( $item->get_total() );
		$l[]    = '   ' . implode( ' · ', $bits );
	}
	$l[] = '';
	$l[] = 'المجموع: ' . sp_money( $order->get_subtotal() );
	if ( $order->get_discount_total() > 0 ) {
		$l[] = 'الخصم (' . implode( ', ', $order->get_coupon_codes() ) . '): -' . sp_money( $order->get_discount_total() );
	}
	if ( 'pickup' === $ctx['method'] ) {
		$l[] = 'الاستلام: من ' . sp_opt( 'pickup_location' );
	} else {
		$l[] = 'التوصيل (' . $ctx['gov'] . '): ' . ( $ctx['fee_known'] ? ( $order->get_total_fees() > 0 ? sp_money( $order->get_total_fees() ) : 'مجاناً' ) : 'يُحدد عبر الواتساب' );
	}
	$l[] = 'الإجمالي: ' . sp_money( $order->get_total() ) . ( 'delivery' === $ctx['method'] && ! $ctx['fee_known'] ? ' + التوصيل' : '' );
	$l[] = '';
	$l[] = 'الاسم: ' . $order->get_billing_first_name();
	$l[] = 'الجوال: ' . $order->get_billing_phone();
	if ( 'delivery' === $ctx['method'] ) {
		$l[] = 'العنوان: ' . trim( $ctx['gov'] . ' - ' . $ctx['area'], ' -' );
	}
	if ( $ctx['gift'] ) {
		$l[] = 'هدية: نعم' . ( $ctx['gift_note'] ? ' — نص البطاقة: ' . $ctx['gift_note'] : '' );
	}
	if ( $ctx['notes'] ) {
		$l[] = 'ملاحظات: ' . $ctx['notes'];
	}
	$track = sp_page_url( 'track' );
	if ( $track ) {
		$l[] = '';
		$l[] = 'تتبع الطلب: ' . $track;
	}
	return implode( "\n", $l );
}
