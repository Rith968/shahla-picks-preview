<?php
/**
 * Printable QR tags for bazaars: scan → product page → order on WhatsApp.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_submenu_page( 'shahla', 'بطاقات QR للبازار', 'بطاقات QR', 'manage_woocommerce', 'sp-qr', 'sp_qr_page' );
}, 20 );

function sp_qr_page() {
	$ids = array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_GET['ids'] ?? '' ) ) ) ) ); // phpcs:ignore
	if ( ! $ids ) {
		$ids_all = sp_query_products( array( 'state' => 'available', 'limit' => 200 ) );
		echo '<div class="wrap sp-admin"><h1>بطاقات QR للبازار</h1>';
		echo '<p>اختاري القطع اللي بتاخذينها للبازار واطبعي لها بطاقات. الزبونة تمسح الكود بجوالها وتشوف التفاصيل وتطلب بالواتساب حتى بعد البازار.</p>';
		echo '<form method="get"><input type="hidden" name="page" value="sp-qr">';
		echo '<p><label><input type="checkbox" data-sp-check-all checked> تحديد الكل</label></p><div class="sp-qr-pick">';
		foreach ( $ids_all as $id ) {
			$p = wc_get_product( $id );
			echo '<label class="sp-qr-item"><input type="checkbox" name="pick[]" value="' . (int) $id . '" checked>' . $p->get_image( array( 60, 75 ) ) . '<span><strong>' . esc_html( $p->get_sku() ) . '</strong><br>' . esc_html( sp_money( $p->get_price() ) ) . '</span></label>';
		}
		echo '</div><p><button class="button button-primary" type="submit" data-sp-qr-go>عرض البطاقات للطباعة</button></p></form></div>';
		?>
		<script>
		document.addEventListener('DOMContentLoaded',function(){
			var all=document.querySelector('[data-sp-check-all]');
			if(all){all.addEventListener('change',function(){document.querySelectorAll('input[name="pick[]"]').forEach(function(c){c.checked=all.checked;});});}
			var f=document.querySelector('[data-sp-qr-go]');
			if(f){f.closest('form').addEventListener('submit',function(e){e.preventDefault();var ids=[].map.call(document.querySelectorAll('input[name="pick[]"]:checked'),function(c){return c.value;});if(!ids.length)return;location.href='<?php echo esc_js( admin_url( 'admin.php?page=sp-qr&ids=' ) ); ?>'+ids.join(',');});}
		});
		</script>
		<?php
		return;
	}
	$logo = function_exists( 'sp_theme_logo_svg' ) ? sp_theme_logo_svg() : '<strong>Shahla Picks</strong>';
	echo '<div class="wrap sp-admin sp-qr-print-wrap"><h1 class="sp-noprint">بطاقات QR</h1><p class="sp-noprint"><button class="button button-primary" onclick="window.print()">طباعة</button> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=sp-qr' ) ) . '">رجوع</a></p><div class="sp-tags">';
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p ) {
			continue;
		}
		$len = sp_inch( $p->get_meta( '_sp_length' ) );
		echo '<div class="sp-tag"><div class="sp-tag__logo">' . $logo . '</div>'; // phpcs:ignore
		echo '<div class="sp-tag__qr" data-qr="' . esc_url( get_permalink( $id ) ) . '"></div>';
		echo '<div class="sp-tag__code">' . esc_html( $p->get_sku() ) . '</div>';
		echo '<div class="sp-tag__meta">' . esc_html( trim( ( $len ? 'الطول ' . $len . ' · ' : '' ) . sp_money( $p->get_price() ) ) ) . '</div>';
		echo '<div class="sp-tag__hint">امسحي الكود واطلبي بالواتساب</div></div>';
	}
	echo '</div></div>';
	wp_enqueue_script( 'sp-qrcode', SP_CORE_URL . 'assets/js/qrcode.js', array(), '1.4.4', true );
	wp_add_inline_script( 'sp-qrcode', 'document.querySelectorAll(".sp-tag__qr").forEach(function(el){var q=qrcode(0,"M");q.addData(el.dataset.qr);q.make();el.innerHTML=q.createSvgTag({cellSize:4,margin:0,scalable:true});});' );
}
