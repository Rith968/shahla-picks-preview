<?php
/**
 * Cart & checkout: no e-mails, WhatsApp panel in the cart, and an online-payment
 * checkout that is ready for a gateway (governorate + delivery fee).
 */
defined( 'ABSPATH' ) || exit;

/* 1) No e-mails at all (the shop works through WhatsApp + the mobile app). */
add_filter( 'woocommerce_email_classes', function ( $emails ) {
	foreach ( $emails as $email ) {
		if ( is_object( $email ) ) {
			$email->enabled = 'no';
		}
	}
	return $emails;
}, 999 );

/* 2) Cart: WhatsApp panel, and the checkout button only when online payment is on. */
add_action( 'woocommerce_cart_collaterals', 'sp_cart_whatsapp_panel', 5 );
add_action( 'wp', function () {
	if ( 'yes' !== sp_opt( 'online_payment' ) ) {
		// The WhatsApp panel already shows the totals.
		remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cart_totals', 10 );
		remove_action( 'woocommerce_proceed_to_checkout', 'woocommerce_button_proceed_to_checkout', 20 );
		add_action( 'woocommerce_proceed_to_checkout', function () {
			echo '<a href="#sp-wa-panel" class="sp-btn sp-btn--wa sp-btn--block sp-jump">' . sp_icon( 'whatsapp', 20 ) . '<span>أكملي الطلب عبر واتساب</span></a>'; // phpcs:ignore
		}, 20 );
	} else {
		remove_action( 'woocommerce_proceed_to_checkout', 'woocommerce_button_proceed_to_checkout', 20 );
		add_action( 'woocommerce_proceed_to_checkout', function () {
			echo '<a href="' . esc_url( wc_get_checkout_url() ) . '" class="sp-btn sp-btn--primary sp-btn--block">ادفعي الآن إلكترونياً</a>';
			echo '<a href="#sp-wa-panel" class="sp-btn sp-btn--ghost sp-btn--block sp-jump">' . sp_icon( 'whatsapp', 20 ) . '<span>أو اطلبي عبر واتساب</span></a>'; // phpcs:ignore
		}, 20 );
	}
} );

/* Checkout page is reachable only when online payment is enabled. */
add_action( 'template_redirect', function () {
	if ( function_exists( 'is_checkout' ) && is_checkout() && ! is_wc_endpoint_url() && 'yes' !== sp_opt( 'online_payment' ) ) {
		wp_safe_redirect( wc_get_cart_url() );
		exit;
	}
} );

/* 3) Checkout fields for Oman (used once a gateway is installed). */
add_filter( 'woocommerce_checkout_fields', function ( $f ) {
	$b = &$f['billing'];
	unset( $b['billing_company'], $b['billing_address_2'], $b['billing_postcode'], $b['billing_last_name'], $b['billing_state'] );
	$b['billing_first_name']['label']    = 'الاسم';
	$b['billing_first_name']['class']    = array( 'form-row-wide' );
	$b['billing_phone']['label']         = 'رقم الجوال';
	$b['billing_phone']['priority']      = 20;
	$b['billing_email']['required']      = false;
	$b['billing_email']['label']         = 'البريد الإلكتروني (اختياري)';
	$b['billing_email']['priority']      = 25;
	$b['billing_sp_method'] = array(
		'type' => 'select', 'label' => 'طريقة الاستلام', 'required' => true, 'priority' => 30, 'class' => array( 'form-row-wide', 'update_totals_on_change' ),
		'options' => array_filter( array( 'delivery' => 'توصيل', 'pickup' => 'yes' === sp_opt( 'pickup_enabled' ) ? 'استلام من ' . sp_opt( 'pickup_location' ) : '' ) ),
	);
	$b['billing_sp_gov'] = array(
		'type' => 'select', 'label' => 'المحافظة', 'required' => true, 'priority' => 40, 'class' => array( 'form-row-first', 'update_totals_on_change' ),
		'options' => sp_governorates(),
	);
	$b['billing_city']['label']     = 'الولاية / المنطقة';
	$b['billing_city']['class']     = array( 'form-row-last' );
	$b['billing_city']['priority']  = 50;
	$b['billing_address_1']['label']       = 'العنوان (اختياري)';
	$b['billing_address_1']['required']    = false;
	$b['billing_address_1']['placeholder'] = 'الحي، رقم البيت، علامة مميزة';
	$b['billing_address_1']['priority']    = 60;
	$b['billing_country']['priority']      = 99;
	return $f;
} );

add_filter( 'woocommerce_checkout_get_value', function ( $value, $input ) {
	if ( 'billing_country' === $input ) {
		return 'OM';
	}
	return $value;
}, 10, 2 );

/* Delivery fee from the governorate chosen at checkout. */
add_action( 'woocommerce_checkout_update_order_review', function ( $post_data ) {
	parse_str( $post_data, $d );
	WC()->session->set( 'sp_gov', sanitize_key( $d['billing_sp_gov'] ?? 'muscat' ) );
	WC()->session->set( 'sp_method', 'pickup' === ( $d['billing_sp_method'] ?? '' ) ? 'pickup' : 'delivery' );
} );

add_action( 'woocommerce_cart_calculate_fees', function ( $cart ) {
	if ( ! is_checkout() || ! WC()->session ) {
		return;
	}
	$method = WC()->session->get( 'sp_method', 'delivery' );
	$gov    = WC()->session->get( 'sp_gov', 'muscat' );
	$fees   = sp_fees();
	if ( 'delivery' === $method && isset( $fees[ $gov ] ) && '' !== $fees[ $gov ] && $fees[ $gov ] > 0 ) {
		$cart->add_fee( 'التوصيل (' . sp_governorates()[ $gov ] . ')', $fees[ $gov ], false );
	}
} );

add_action( 'woocommerce_checkout_create_order', function ( $order, $data ) {
	$order->update_meta_data( '_sp_method', $data['billing_sp_method'] ?? 'delivery' );
	$order->update_meta_data( '_sp_gov', $data['billing_sp_gov'] ?? '' );
	$govs = sp_governorates();
	if ( ! empty( $data['billing_sp_gov'] ) && isset( $govs[ $data['billing_sp_gov'] ] ) ) {
		$order->set_billing_state( $govs[ $data['billing_sp_gov'] ] );
	}
}, 10, 2 );

/* 4) Header cart count fragment. */
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fr ) {
	$n = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	$fr['span.sp-cart-count'] = '<span class="sp-cart-count" data-count="' . (int) $n . '">' . (int) $n . '</span>';
	return $fr;
} );

/* Friendlier add-to-cart texts. */
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	return $p->is_in_stock() ? 'أضيفي للسلة' : 'غير متوفرة';
}, 10, 2 );
add_filter( 'woocommerce_product_single_add_to_cart_text', function () {
	return 'أضيفي للسلة';
} );

/* A piece already in the cart can't be added twice (it's one of a kind). */
add_filter( 'woocommerce_cart_item_quantity', function ( $html, $key, $item ) {
	return '<span class="sp-qty-one">قطعة واحدة</span>';
}, 10, 3 );
