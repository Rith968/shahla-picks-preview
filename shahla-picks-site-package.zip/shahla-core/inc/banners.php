<?php
/**
 * Promotional banners (video or image) that rotate in the homepage hero.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', 'sp_register_banner_cpt' );
function sp_register_banner_cpt() {
	register_post_type( 'sp_banner', array(
		'labels'       => array(
			'name' => 'البانرات', 'singular_name' => 'بانر', 'add_new' => 'إضافة بانر', 'add_new_item' => 'إضافة بانر جديد',
			'edit_item' => 'تعديل البانر', 'all_items' => 'البانرات', 'menu_name' => 'البانرات', 'not_found' => 'لا توجد بانرات بعد',
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => 'shahla',
		'supports'     => array( 'title', 'page-attributes' ),
		'menu_icon'    => 'dashicons-format-video',
	) );
}

function sp_banner_fields() {
	return array(
		'_sp_video_mobile'  => array( 'فيديو الجوال (عمودي)', 'media', 'video', 'الريلز من إنستقرام مناسبة تماماً. يفضل MP4 بحجم أقل من 8 ميغا.' ),
		'_sp_video_desktop' => array( 'فيديو الكمبيوتر (اختياري)', 'media', 'video', 'إذا ما رفعتي فيديو للكمبيوتر يُستخدم فيديو الجوال داخل إطار أنيق.' ),
		'_sp_image'         => array( 'صورة / غلاف الفيديو', 'media', 'image', 'تظهر لين يحمّل الفيديو، أو كبانر صورة إذا ما في فيديو.' ),
		'_sp_eyebrow'       => array( 'سطر صغير فوق العنوان', 'text', '', 'مثال: تشكيلة العيد' ),
		'_sp_text'          => array( 'النص', 'textarea', '', '' ),
		'_sp_btn_text'      => array( 'نص الزر', 'text', '', 'مثال: تسوّقي الآن' ),
		'_sp_btn_url'       => array( 'رابط الزر', 'url', '', 'اتركيه فاضي ليفتح المتجر.' ),
		'_sp_start'         => array( 'يبدأ الظهور', 'datetime-local', '', 'اختياري' ),
		'_sp_end'           => array( 'ينتهي الظهور', 'datetime-local', '', 'اختياري — مثلاً نهاية العيد' ),
		'_sp_duration'      => array( 'مدة عرض الصورة (ثواني)', 'number', '', 'للبانر الصورة فقط. الفيديو يتبدل عند انتهائه.' ),
	);
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'sp_banner_box', 'محتوى البانر', 'sp_banner_box', 'sp_banner', 'normal', 'high' );
} );

function sp_banner_box( $post ) {
	wp_nonce_field( 'sp_banner_save', 'sp_banner_nonce' );
	echo '<p class="description">العنوان الكبير هو عنوان البانر فوق. الترتيب يتحكم فيه حقل "الترتيب" في صندوق خصائص الصفحة.</p>';
	echo '<table class="form-table sp-meta-table">';
	foreach ( sp_banner_fields() as $key => $f ) {
		sp_meta_field_row( $post->ID, $key, $f );
	}
	echo '</table>';
}

/** Generic meta field row renderer (banners, events, reviews). */
function sp_meta_field_row( $post_id, $key, $f ) {
	list( $label, $type, $media, $help ) = array_pad( $f, 4, '' );
	$val = get_post_meta( $post_id, $key, true );
	echo '<tr><th><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
	if ( 'media' === $type ) {
		$name = $val ? basename( (string) get_attached_file( (int) $val ) ) : '';
		echo '<div class="sp-media-field"><input type="hidden" class="sp-media-id" name="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '">';
		if ( 'image' === $media && $val ) {
			echo wp_get_attachment_image( (int) $val, 'thumbnail', false, array( 'class' => 'sp-media-thumb' ) );
		}
		echo '<button type="button" class="button sp-media-pick" data-type="' . esc_attr( $media ) . '" data-title="' . esc_attr( $label ) . '">' . ( 'video' === $media ? 'اختيار فيديو' : 'اختيار صورة' ) . '</button> ';
		echo '<button type="button" class="button-link sp-media-clear"' . ( $val ? '' : ' hidden' ) . '>إزالة</button> ';
		echo '<span class="sp-media-name">' . esc_html( $name ) . '</span></div>';
	} elseif ( 'textarea' === $type ) {
		echo '<textarea class="large-text" rows="2" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $val ) . '</textarea>';
	} else {
		echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '"' . ( 'url' === $type ? ' dir="ltr"' : '' ) . '>';
	}
	if ( $help ) {
		echo '<p class="description">' . esc_html( $help ) . '</p>';
	}
	echo '</td></tr>';
}

function sp_save_meta_fields( $post_id, $fields ) {
	foreach ( $fields as $key => $f ) {
		if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore
			continue;
		}
		$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore
		switch ( $f[1] ) {
			case 'media':
			case 'number':
				$v = '' === $raw ? '' : absint( $raw );
				break;
			case 'url':
				$v = esc_url_raw( $raw );
				break;
			case 'textarea':
				$v = sanitize_textarea_field( $raw );
				break;
			default:
				$v = sanitize_text_field( $raw );
		}
		'' === $v ? delete_post_meta( $post_id, $key ) : update_post_meta( $post_id, $key, $v );
	}
}

add_action( 'save_post_sp_banner', function ( $post_id ) {
	if ( ! isset( $_POST['sp_banner_nonce'] ) || ! wp_verify_nonce( $_POST['sp_banner_nonce'], 'sp_banner_save' ) || ! current_user_can( 'edit_post', $post_id ) ) { // phpcs:ignore
		return;
	}
	sp_save_meta_fields( $post_id, sp_banner_fields() );
} );

/* Admin list: preview + status */
add_filter( 'manage_sp_banner_posts_columns', function ( $c ) {
	return array( 'cb' => $c['cb'], 'sp_prev' => 'معاينة', 'title' => 'العنوان', 'sp_status' => 'الحالة', 'sp_order' => 'الترتيب' );
} );
add_action( 'manage_sp_banner_posts_custom_column', function ( $col, $id ) {
	if ( 'sp_prev' === $col ) {
		$img = (int) get_post_meta( $id, '_sp_image', true );
		echo $img ? wp_get_attachment_image( $img, array( 60, 60 ) ) : ( get_post_meta( $id, '_sp_video_mobile', true ) ? '<span class="dashicons dashicons-format-video"></span>' : '—' ); // phpcs:ignore
	}
	if ( 'sp_status' === $col ) {
		$s = sp_banner_status( $id );
		$l = array( 'live' => 'ظاهر الآن', 'scheduled' => 'مجدول', 'ended' => 'انتهى', 'draft' => 'مسودة' );
		echo '<span class="sp-state sp-state--' . esc_attr( $s ) . '">' . esc_html( $l[ $s ] ) . '</span>';
	}
	if ( 'sp_order' === $col ) {
		echo (int) get_post_field( 'menu_order', $id );
	}
}, 10, 2 );

add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() && $q->is_main_query() && 'sp_banner' === $q->get( 'post_type' ) && ! $q->get( 'orderby' ) ) {
		$q->set( 'orderby', array( 'menu_order' => 'ASC', 'date' => 'DESC' ) );
	}
} );

function sp_banner_status( $id ) {
	if ( 'publish' !== get_post_status( $id ) ) {
		return 'draft';
	}
	$now   = current_time( 'timestamp' );
	$start = get_post_meta( $id, '_sp_start', true );
	$end   = get_post_meta( $id, '_sp_end', true );
	if ( $start && strtotime( $start ) > $now ) {
		return 'scheduled';
	}
	if ( $end && strtotime( $end ) < $now ) {
		return 'ended';
	}
	return 'live';
}

function sp_get_active_banners() {
	$ids = get_posts( array(
		'post_type' => 'sp_banner', 'post_status' => 'publish', 'posts_per_page' => 12, 'fields' => 'ids',
		'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
	) );
	return array_values( array_filter( $ids, function ( $id ) { return 'live' === sp_banner_status( $id ); } ) );
}

/** Homepage hero: rotating banners, or a static brand hero. */
function sp_render_hero() {
	$ids  = sp_get_active_banners();
	$shop = wc_get_page_permalink( 'shop' );
	if ( ! $ids ) {
		?>
		<section class="sp-hero sp-hero--static">
			<div class="sp-hero__content">
				<p class="sp-eyebrow">مختارات شهلاء</p>
				<h1 class="sp-hero__title"><?php echo esc_html( sp_opt( 'hero_title' ) ); ?></h1>
				<p class="sp-hero__text"><?php echo esc_html( sp_opt( 'hero_text' ) ); ?></p>
				<a class="sp-btn sp-btn--primary" href="<?php echo esc_url( $shop ); ?>">تسوّقي القطع المتوفرة</a>
			</div>
		</section>
		<?php
		return;
	}
	?>
	<section class="sp-hero" data-sp-hero aria-roledescription="carousel" aria-label="عروض مختارات شهلاء">
		<div class="sp-hero__track">
		<?php
		foreach ( $ids as $i => $id ) :
			$vm  = (int) get_post_meta( $id, '_sp_video_mobile', true );
			$vd  = (int) get_post_meta( $id, '_sp_video_desktop', true );
			$img = (int) get_post_meta( $id, '_sp_image', true );
			$dur = (int) get_post_meta( $id, '_sp_duration', true ) ?: 6;
			$btn = get_post_meta( $id, '_sp_btn_text', true );
			$url = get_post_meta( $id, '_sp_btn_url', true ) ?: $shop;
			$eye = get_post_meta( $id, '_sp_eyebrow', true );
			$txt = get_post_meta( $id, '_sp_text', true );
			$poster = $img ? wp_get_attachment_image_url( $img, 'large' ) : '';
			$tag    = 0 === $i ? 'h1' : 'h2';
			?>
			<article class="sp-hero__slide<?php echo 0 === $i ? ' is-active' : ''; ?>" data-duration="<?php echo esc_attr( $dur ); ?>" aria-roledescription="slide" aria-label="<?php echo esc_attr( ( $i + 1 ) . ' / ' . count( $ids ) ); ?>"<?php echo 0 === $i ? '' : ' aria-hidden="true"'; ?>>
				<div class="sp-hero__media<?php echo $vd ? ' has-desktop' : ''; ?>">
					<?php if ( $vm || $vd ) : ?>
						<video class="sp-hero__video" muted playsinline preload="<?php echo 0 === $i ? 'auto' : 'none'; ?>"
							<?php echo $poster ? 'poster="' . esc_url( $poster ) . '"' : ''; ?>
							data-src-mobile="<?php echo esc_url( $vm ? wp_get_attachment_url( $vm ) : wp_get_attachment_url( $vd ) ); ?>"
							data-src-desktop="<?php echo esc_url( $vd ? wp_get_attachment_url( $vd ) : wp_get_attachment_url( $vm ) ); ?>"></video>
					<?php elseif ( $img ) : ?>
						<?php echo wp_get_attachment_image( $img, 'large', false, array( 'class' => 'sp-hero__img', 'loading' => 0 === $i ? 'eager' : 'lazy' ) ); ?>
					<?php endif; ?>
				</div>
				<div class="sp-hero__content">
					<?php if ( $eye ) : ?><p class="sp-eyebrow"><?php echo esc_html( $eye ); ?></p><?php endif; ?>
					<<?php echo $tag; // phpcs:ignore ?> class="sp-hero__title"><?php echo esc_html( get_the_title( $id ) ); ?></<?php echo $tag; // phpcs:ignore ?>>
					<?php if ( $txt ) : ?><p class="sp-hero__text"><?php echo esc_html( $txt ); ?></p><?php endif; ?>
					<?php if ( $btn ) : ?><a class="sp-btn sp-btn--primary" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $btn ); ?></a><?php endif; ?>
				</div>
			</article>
		<?php endforeach; ?>
		</div>
		<?php if ( count( $ids ) > 1 ) : ?>
		<div class="sp-hero__dots" role="tablist" aria-label="اختيار البانر">
			<?php foreach ( $ids as $i => $id ) : ?>
				<button type="button" role="tab" class="sp-hero__dot<?php echo 0 === $i ? ' is-active' : ''; ?>" aria-selected="<?php echo 0 === $i ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr( 'بانر ' . ( $i + 1 ) ); ?>" data-go="<?php echo (int) $i; ?>"><span></span></button>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
		<button type="button" class="sp-hero__sound" data-sp-sound aria-pressed="false" aria-label="تشغيل الصوت"><?php echo sp_icon( 'mute', 20 ) . sp_icon( 'sound', 20 ); // phpcs:ignore ?></button>
	</section>
	<?php
}
