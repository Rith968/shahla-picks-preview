<?php
/**
 * Settings page: "متجر شهلاء ← الإعدادات".
 */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_menu_page( 'متجر شهلاء', 'متجر شهلاء', 'manage_woocommerce', 'shahla', 'sp_settings_page', 'dashicons-heart', 3 );
	add_submenu_page( 'shahla', 'الإعدادات', 'الإعدادات', 'manage_woocommerce', 'shahla', 'sp_settings_page' );
}, 9 );

add_action( 'admin_init', function () {
	register_setting( 'sp_settings_group', 'sp_settings', array( 'sanitize_callback' => 'sp_sanitize_settings' ) );
} );

function sp_sanitize_settings( $in ) {
	$d   = sp_settings_defaults();
	$out = array();
	$out['whatsapp']        = preg_replace( '/[^\d+]/', '', $in['whatsapp'] ?? '' );
	$out['hold_hours']      = max( 1, min( 168, (int) ( $in['hold_hours'] ?? $d['hold_hours'] ) ) );
	$out['announcement']    = sanitize_text_field( $in['announcement'] ?? '' );
	$out['pickup_enabled']  = ! empty( $in['pickup_enabled'] ) ? 'yes' : 'no';
	$out['pickup_location'] = sanitize_text_field( $in['pickup_location'] ?? '' );
	$out['online_payment']  = ! empty( $in['online_payment'] ) ? 'yes' : 'no';
	$out['instagram']       = esc_url_raw( $in['instagram'] ?? '' );
	$out['hero_title']      = sanitize_text_field( $in['hero_title'] ?? '' );
	$out['hero_text']       = sanitize_text_field( $in['hero_text'] ?? '' );
	$out['msg_intro']       = sanitize_text_field( $in['msg_intro'] ?? '' );
	$out['new_days']        = max( 1, (int) ( $in['new_days'] ?? 21 ) );
	$out['fees']            = array();
	foreach ( sp_governorates() as $k => $label ) {
		$v                 = isset( $in['fees'][ $k ] ) ? trim( (string) $in['fees'][ $k ] ) : '';
		$out['fees'][ $k ] = '' === $v ? '' : (string) max( 0, (float) $v );
	}
	return $out;
}

function sp_settings_page() {
	$s = wp_parse_args( (array) get_option( 'sp_settings', array() ), sp_settings_defaults() );
	?>
	<div class="wrap sp-admin">
		<h1>إعدادات المتجر</h1>
		<p class="description">هذه الإعدادات تتحكم في الطلب عبر الواتساب، الحجز، التوصيل، والنصوص الظاهرة في الموقع.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'sp_settings_group' ); ?>

			<h2>الواتساب والحجز</h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="sp-wa">رقم الواتساب</label></th>
					<td><input id="sp-wa" type="text" class="regular-text" dir="ltr" name="sp_settings[whatsapp]" value="<?php echo esc_attr( $s['whatsapp'] ); ?>" placeholder="968XXXXXXXX">
					<p class="description">بالصيغة الدولية بدون + أو أصفار، مثال: 968XXXXXXXX. كل طلبات الموقع تُرسل لهذا الرقم.</p></td>
				</tr>
				<tr>
					<th><label for="sp-hold">مدة حجز القطعة</label></th>
					<td><input id="sp-hold" type="number" min="1" max="168" name="sp_settings[hold_hours]" value="<?php echo esc_attr( $s['hold_hours'] ); ?>"> ساعة
					<p class="description">عند إرسال طلب من السلة تُحجز القطع. إذا لم تؤكدي الطلب خلال هذه المدة يُلغى تلقائياً وترجع القطع للبيع.</p></td>
				</tr>
				<tr>
					<th><label for="sp-intro">بداية رسالة الطلب</label></th>
					<td><input id="sp-intro" type="text" class="large-text" name="sp_settings[msg_intro]" value="<?php echo esc_attr( $s['msg_intro'] ); ?>"></td>
				</tr>
			</table>

			<h2>التوصيل والاستلام</h2>
			<table class="form-table" role="presentation">
				<tr>
					<th>الاستلام من المحل</th>
					<td><label><input type="checkbox" name="sp_settings[pickup_enabled]" value="1" <?php checked( 'yes', $s['pickup_enabled'] ); ?>> متاح</label>
					<input type="text" class="regular-text" name="sp_settings[pickup_location]" value="<?php echo esc_attr( $s['pickup_location'] ); ?>" placeholder="مكان الاستلام"></td>
				</tr>
				<tr>
					<th>رسوم التوصيل حسب المحافظة</th>
					<td>
						<div class="sp-fees">
						<?php foreach ( sp_governorates() as $k => $label ) : ?>
							<label class="sp-fee"><span><?php echo esc_html( $label ); ?></span>
							<input type="number" step="0.1" min="0" name="sp_settings[fees][<?php echo esc_attr( $k ); ?>]" value="<?php echo esc_attr( $s['fees'][ $k ] ?? '' ); ?>" placeholder="—"> ر.ع.</label>
						<?php endforeach; ?>
						</div>
						<p class="description">اتركي الخانة فاضية إذا كانت الرسوم تُتفق عليها في الواتساب. اكتبي 0 للتوصيل المجاني.</p>
					</td>
				</tr>
			</table>

			<h2>نصوص الموقع</h2>
			<table class="form-table" role="presentation">
				<tr><th><label for="sp-ann">الشريط العلوي</label></th><td><input id="sp-ann" type="text" class="large-text" name="sp_settings[announcement]" value="<?php echo esc_attr( $s['announcement'] ); ?>"></td></tr>
				<tr><th><label for="sp-ht">عنوان الواجهة (عند عدم وجود بانرات)</label></th><td><input id="sp-ht" type="text" class="large-text" name="sp_settings[hero_title]" value="<?php echo esc_attr( $s['hero_title'] ); ?>"></td></tr>
				<tr><th><label for="sp-hx">نص الواجهة</label></th><td><input id="sp-hx" type="text" class="large-text" name="sp_settings[hero_text]" value="<?php echo esc_attr( $s['hero_text'] ); ?>"></td></tr>
				<tr><th><label for="sp-ig">رابط إنستقرام</label></th><td><input id="sp-ig" type="url" class="regular-text" dir="ltr" name="sp_settings[instagram]" value="<?php echo esc_attr( $s['instagram'] ); ?>"></td></tr>
				<tr><th><label for="sp-nd">شارة "جديد" تظهر لمدة</label></th><td><input id="sp-nd" type="number" min="1" name="sp_settings[new_days]" value="<?php echo esc_attr( $s['new_days'] ); ?>"> يوم</td></tr>
			</table>

			<h2>الدفع الإلكتروني</h2>
			<table class="form-table" role="presentation">
				<tr>
					<th>زر "ادفعي الآن"</th>
					<td><label><input type="checkbox" name="sp_settings[online_payment]" value="1" <?php checked( 'yes', $s['online_payment'] ); ?>> إظهار خيار الدفع الإلكتروني في السلة</label>
					<p class="description">فعّليه بعد تركيب بوابة الدفع (ثواني، AmwalPay، أو Tap) من ووكومرس ← الإعدادات ← المدفوعات. يبقى الطلب عبر الواتساب متاحاً دائماً.</p></td>
				</tr>
			</table>
			<?php submit_button( 'حفظ الإعدادات' ); ?>
		</form>
	</div>
	<?php
}
