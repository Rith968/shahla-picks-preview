<?php
/**
 * Product fields (length/width/fabric/video), auto code, one-piece defaults,
 * admin list helpers, and storefront filtering.
 */
defined( 'ABSPATH' ) || exit;

/* ---------- Admin: fields in the product "General" tab ---------- */
add_action( 'woocommerce_product_options_general_product_data', function () {
	global $post;
	$product = wc_get_product( $post->ID );
	echo '<div class="options_group sp-specs-group">';
	woocommerce_wp_text_input( array(
		'id' => '_sp_length', 'label' => 'الطول (إنش)', 'type' => 'number',
		'custom_attributes' => array( 'step' => '0.5', 'min' => '0' ),
		'value' => $product ? $product->get_meta( '_sp_length' ) : '',
		'desc_tip' => true, 'description' => 'طول المخور من الكتف إلى آخر القطعة.',
	) );
	woocommerce_wp_text_input( array(
		'id' => '_sp_width', 'label' => 'العرض (إنش)', 'type' => 'number',
		'custom_attributes' => array( 'step' => '0.5', 'min' => '0' ),
		'value' => $product ? $product->get_meta( '_sp_width' ) : '',
	) );
	woocommerce_wp_text_input( array(
		'id' => '_sp_fabric', 'label' => 'القماش',
		'value' => $product ? $product->get_meta( '_sp_fabric' ) : '',
		'custom_attributes' => array( 'list' => 'sp-fabrics' ),
		'placeholder' => 'حرير إيطالي',
	) );
	echo '<datalist id="sp-fabrics">';
	foreach ( sp_known_fabrics() as $f ) {
		echo '<option value="' . esc_attr( $f ) . '"></option>';
	}
	echo '</datalist>';
	$vid = $product ? (int) $product->get_meta( '_sp_video_id' ) : 0;
	?>
	<p class="form-field sp-video-field">
		<label>فيديو القطعة</label>
		<input type="hidden" name="_sp_video_id" value="<?php echo esc_attr( $vid ?: '' ); ?>" class="sp-media-id">
		<button type="button" class="button sp-media-pick" data-type="video" data-title="اختاري فيديو القطعة">اختيار فيديو</button>
		<button type="button" class="button-link sp-media-clear" <?php echo $vid ? '' : 'hidden'; ?>>إزالة</button>
		<span class="sp-media-name"><?php echo $vid ? esc_html( basename( get_attached_file( $vid ) ) ) : ''; ?></span>
	</p>
	<?php
	echo '</div>';
} );

function sp_known_fabrics() {
	global $wpdb;
	$rows = $wpdb->get_col( "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_sp_fabric' AND meta_value <> '' LIMIT 40" );
	return array_unique( array_merge( array( 'حرير إيطالي', 'حرير إيطالي ناعم', 'حرير مخلوط', 'قطن' ), (array) $rows ) );
}

add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( array( '_sp_length', '_sp_width' ) as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$v = wc_clean( wp_unslash( $_POST[ $k ] ) ); // phpcs:ignore
			'' === $v ? $product->delete_meta_data( $k ) : $product->update_meta_data( $k, (float) $v );
		}
	}
	if ( isset( $_POST['_sp_fabric'] ) ) { // phpcs:ignore
		$product->update_meta_data( '_sp_fabric', sanitize_text_field( wp_unslash( $_POST['_sp_fabric'] ) ) ); // phpcs:ignore
	}
	if ( isset( $_POST['_sp_video_id'] ) ) { // phpcs:ignore
		$vid = absint( $_POST['_sp_video_id'] ); // phpcs:ignore
		$vid ? $product->update_meta_data( '_sp_video_id', $vid ) : $product->delete_meta_data( '_sp_video_id' );
	}
	sp_apply_one_piece_defaults( $product );
}, 20 );

/** One-of-a-kind defaults: stock managed, qty 1, one per order, auto code. */
function sp_apply_one_piece_defaults( $product ) {
	$is_new = ! $product->get_id() || 'auto-draft' === get_post_status( $product->get_id() ) || ! $product->get_date_created();
	if ( $is_new && ! $product->get_manage_stock() ) {
		$product->set_manage_stock( true );
		if ( null === $product->get_stock_quantity() ) {
			$product->set_stock_quantity( 1 );
		}
	}
	$product->set_sold_individually( true );
	if ( ! $product->get_sku() ) {
		$product->set_sku( sp_next_sku() );
	}
}

function sp_next_sku() {
	$n = (int) get_option( 'sp_sku_counter', 1000 );
	do {
		$n++;
		$sku = sprintf( 'SP-%04d', $n );
	} while ( wc_get_product_id_by_sku( $sku ) );
	update_option( 'sp_sku_counter', $n, false );
	return $sku;
}

/* Products created from the WooCommerce mobile app / REST. */
add_action( 'woocommerce_rest_insert_product_object', function ( $product, $request, $creating ) {
	if ( $creating ) {
		sp_apply_one_piece_defaults( $product );
		$product->save();
	}
}, 10, 3 );

/* Safety net: any product saved without a code gets one. */
add_action( 'woocommerce_new_product', function ( $id ) {
	$p = wc_get_product( $id );
	if ( $p && ! $p->get_sku() ) {
		$p->set_sku( sp_next_sku() );
		$p->save();
	}
} );

/* ---------- Admin: list columns + quick "sold" toggle ---------- */
add_filter( 'manage_edit-product_columns', function ( $cols ) {
	$new = array();
	foreach ( $cols as $k => $v ) {
		$new[ $k ] = $v;
		if ( 'name' === $k ) {
			$new['sp_length'] = 'الطول';
			$new['sp_state']  = 'الحالة';
		}
	}
	unset( $new['product_tag'], $new['featured'] );
	return $new;
}, 20 );

add_action( 'manage_product_posts_custom_column', function ( $col, $id ) {
	if ( 'sp_length' === $col ) {
		echo esc_html( sp_inch( get_post_meta( $id, '_sp_length', true ) ) ?: '—' );
	}
	if ( 'sp_state' === $col ) {
		$st     = sp_product_state( $id );
		$labels = array( 'available' => 'متوفرة', 'reserved' => 'محجوزة', 'sold' => 'مباعة' );
		echo '<span class="sp-state sp-state--' . esc_attr( $st ) . '">' . esc_html( $labels[ $st ] ) . '</span>';
	}
}, 10, 2 );

add_filter( 'post_row_actions', function ( $actions, $post ) {
	if ( 'product' !== $post->post_type || ! current_user_can( 'edit_product', $post->ID ) ) {
		return $actions;
	}
	$st  = sp_product_state( $post->ID );
	$to  = 'available' === $st ? 'sold' : 'available';
	$url = wp_nonce_url( admin_url( 'admin-post.php?action=sp_toggle_sold&id=' . $post->ID . '&to=' . $to ), 'sp_toggle_' . $post->ID );
	$actions['sp_toggle'] = '<a href="' . esc_url( $url ) . '">' . ( 'sold' === $to ? 'تعليم كمباعة' : 'إرجاعها متوفرة' ) . '</a>';
	$actions['sp_qr']     = '<a href="' . esc_url( admin_url( 'admin.php?page=sp-qr&ids=' . $post->ID ) ) . '">بطاقة QR</a>';
	return $actions;
}, 10, 2 );

add_action( 'admin_post_sp_toggle_sold', function () {
	$id = absint( $_GET['id'] ?? 0 ); // phpcs:ignore
	check_admin_referer( 'sp_toggle_' . $id );
	if ( ! current_user_can( 'edit_product', $id ) ) {
		wp_die( 'غير مسموح' );
	}
	$p = wc_get_product( $id );
	if ( $p ) {
		$p->set_manage_stock( true );
		if ( 'sold' === ( $_GET['to'] ?? '' ) ) { // phpcs:ignore
			$p->set_stock_quantity( 0 );
		} else {
			$p->set_stock_quantity( 1 );
			$p->delete_meta_data( '_sp_reserved_until' );
		}
		$p->save();
	}
	wp_safe_redirect( wp_get_referer() ?: admin_url( 'edit.php?post_type=product' ) );
	exit;
} );

/* ---------- Storefront: hide sold pieces from shop + filters ---------- */
add_action( 'woocommerce_product_query', function ( $q ) {
	if ( is_admin() ) {
		return;
	}
	$mq   = (array) $q->get( 'meta_query' );
	$mq[] = array(
		'relation' => 'OR',
		array( 'key' => '_stock_status', 'value' => 'outofstock', 'compare' => '!=' ),
		array( 'key' => '_sp_reserved_until', 'value' => time(), 'type' => 'NUMERIC', 'compare' => '>' ),
	);
	$len = sp_length_ranges();
	$sel = sanitize_key( $_GET['sp_len'] ?? '' ); // phpcs:ignore
	if ( isset( $len[ $sel ] ) ) {
		$mq[] = array( 'key' => '_sp_length', 'value' => array( $len[ $sel ][1], $len[ $sel ][2] ), 'type' => 'DECIMAL(5,1)', 'compare' => 'BETWEEN' );
	}
	$pr  = sp_price_ranges();
	$sel = sanitize_key( $_GET['sp_price'] ?? '' ); // phpcs:ignore
	if ( isset( $pr[ $sel ] ) ) {
		$mq[] = array( 'key' => '_price', 'value' => array( $pr[ $sel ][1], $pr[ $sel ][2] ), 'type' => 'DECIMAL(10,3)', 'compare' => 'BETWEEN' );
	}
	$q->set( 'meta_query', $mq );
} );

function sp_length_ranges() {
	return array(
		'short' => array( 'حتى 55 إنش', 0, 55 ),
		'mid'   => array( '55.5 – 57 إنش', 55.5, 57 ),
		'long'  => array( '57.5 إنش وأكثر', 57.5, 99 ),
	);
}

function sp_price_ranges() {
	return array(
		'u15'  => array( 'حتى 15 ر.ع.', 0, 15 ),
		'm25'  => array( '16 – 25 ر.ع.', 15.001, 25 ),
		'o25'  => array( 'أكثر من 25 ر.ع.', 25.001, 9999 ),
	);
}

/** Render the shop filter chips (used by theme above the grid). */
function sp_shop_filters() {
	$base = remove_query_arg( array( 'sp_len', 'sp_price', 'paged' ) );
	$cur  = array( 'sp_len' => sanitize_key( $_GET['sp_len'] ?? '' ), 'sp_price' => sanitize_key( $_GET['sp_price'] ?? '' ) ); // phpcs:ignore
	$out  = '<div class="sp-filters" data-sp-filters><div class="sp-filters__inner">';
	foreach ( array( 'sp_len' => array( 'الطول', sp_length_ranges() ), 'sp_price' => array( 'السعر', sp_price_ranges() ) ) as $key => $group ) {
		$out .= '<div class="sp-filters__group" role="group" aria-label="' . esc_attr( $group[0] ) . '"><span class="sp-filters__label">' . esc_html( $group[0] ) . '</span>';
		foreach ( $group[1] as $slug => $r ) {
			$active = $cur[ $key ] === $slug;
			$url    = $active ? remove_query_arg( $key ) : add_query_arg( $key, $slug, remove_query_arg( 'paged' ) );
			$out   .= '<a class="sp-chip' . ( $active ? ' is-active' : '' ) . '" href="' . esc_url( $url ) . '"' . ( $active ? ' aria-current="true"' : '' ) . '>' . esc_html( $r[0] ) . '</a>';
		}
		$out .= '</div>';
	}
	if ( $cur['sp_len'] || $cur['sp_price'] ) {
		$out .= '<a class="sp-filters__clear" href="' . esc_url( $base ) . '">مسح الفلاتر</a>';
	}
	$out .= '</div></div>';
	return $out;
}

/** Product video (attachment URL) or ''. */
function sp_product_video_url( $product ) {
	$product = wc_get_product( $product );
	$id      = $product ? (int) $product->get_meta( '_sp_video_id' ) : 0;
	return $id ? wp_get_attachment_url( $id ) : '';
}

/* Hide WooCommerce's own stock text; our badges/notices replace it. */
add_filter( 'woocommerce_get_stock_html', '__return_empty_string' );

/* Image sizes we don't need. */
add_filter( 'intermediate_image_sizes_advanced', function ( $sizes ) {
	unset( $sizes['1536x1536'], $sizes['2048x2048'], $sizes['medium_large'] );
	return $sizes;
} );

/* Admin media picker script (products, banners, events). */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	$screen = get_current_screen();
	if ( $screen && in_array( $screen->post_type, array( 'product', 'sp_banner', 'sp_event', 'sp_review' ), true ) ) {
		wp_enqueue_media();
	}
	wp_enqueue_script( 'sp-admin', SP_CORE_URL . 'assets/js/sp-admin.js', array( 'jquery' ), SP_CORE_VER, true );
	wp_enqueue_style( 'sp-admin', SP_CORE_URL . 'assets/css/sp-admin.css', array(), SP_CORE_VER );
} );
