<?php
/**
 * "استيراد من إنستقرام": turn an Instagram export (JSON made by the browser
 * snippet shown on this page) into one-of-a-kind products. Safe to re-run:
 * posts already imported are skipped, so it also syncs new posts.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_submenu_page( 'shahla', 'استيراد من إنستقرام', 'استيراد من إنستقرام', 'manage_options', 'sp-import', 'sp_import_page' );
}, 40 );

function sp_import_file() {
	return trailingslashit( wp_upload_dir()['basedir'] ) . 'sp-import/instagram.json';
}

function sp_ig_snippet() {
	return <<<'JS'
(async () => {
  const H = {'X-IG-App-ID': '936619743392459', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRFToken': (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || ''};
  const codes = new Set();
  for (let i = 0; i < 20; i++) {
    document.querySelectorAll('a[href*="/p/"], a[href*="/reel/"]').forEach(a => { const m = a.getAttribute('href').match(/\/(p|reel)\/([^/?]+)/); if (m) codes.add(m[2]); });
    window.scrollTo(0, document.body.scrollHeight); await new Promise(r => setTimeout(r, 1200));
  }
  const id = sc => { const al = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'; let n = 0n; for (const c of sc.slice(0, 11)) n = n * 64n + BigInt(al.indexOf(c)); return n.toString(); };
  const img = m => { const c = ((m.image_versions2 || {}).candidates || []).filter(x => x.width <= 1080).sort((a, b) => b.width - a.width); return (c[0] || {}).url; };
  const vid = m => { const v = (m.video_versions || []).slice().sort((a, b) => a.width - b.width); return ((v.filter(x => x.width >= 540)[0]) || v[v.length - 1] || {}).url; };
  const posts = [];
  for (const code of codes) {
    try {
      const it = (await fetch('/api/v1/media/' + id(code) + '/info/', {headers: H, credentials: 'include'}).then(r => r.json())).items[0];
      const items = it.media_type === 8 ? it.carousel_media : [it];
      posts.push({code, ts: it.taken_at, type: it.media_type, caption: (it.caption && it.caption.text) || '',
        media: items.map(m => m.media_type === 2 ? {kind: 'video', url: vid(m), cover: img(m)} : {kind: 'image', url: img(m)})});
    } catch (e) { console.warn('skip', code, e); }
    await new Promise(r => setTimeout(r, 400));
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify({posts})], {type: 'application/json'}));
  a.download = 'shahla-instagram.json'; a.click();
  console.log('Exported', posts.length, 'posts');
})();
JS;
}

function sp_import_page() {
	$msg = '';
	if ( isset( $_POST['sp_import_upload'] ) && check_admin_referer( 'sp_import_upload' ) && ! empty( $_FILES['sp_json']['tmp_name'] ) ) { // phpcs:ignore
		$raw  = file_get_contents( $_FILES['sp_json']['tmp_name'] ); // phpcs:ignore
		$data = json_decode( $raw, true );
		if ( empty( $data['posts'] ) ) {
			$msg = '<div class="notice notice-error"><p>الملف غير صالح.</p></div>';
		} else {
			wp_mkdir_p( dirname( sp_import_file() ) );
			file_put_contents( sp_import_file(), wp_json_encode( $data ) );
			$msg = '<div class="notice notice-success"><p>تم رفع ' . count( $data['posts'] ) . ' منشور. اضغطي "ابدئي الاستيراد".</p></div>';
		}
	}
	$has = file_exists( sp_import_file() );
	?>
	<div class="wrap sp-admin">
		<h1>استيراد من إنستقرام</h1>
		<?php echo $msg; // phpcs:ignore ?>
		<p>يحوّل منشورات الحساب إلى قطع في المتجر: السعر والطول والعرض والقماش تُقرأ من الوصف، والصور والفيديو تُنزّل تلقائياً، والمنشورات المعلّمة SOLD تصير "مباعة". المنشورات اللي ما فيها سعر (بازارات، إعلانات) تُتجاهل. تقدرين تعيدين الاستيراد أي وقت لإضافة المنشورات الجديدة فقط.</p>
		<h2>1) صدّري المنشورات</h2>
		<ol>
			<li>افتحي صفحة الحساب في إنستقرام على الكمبيوتر (وأنت مسجلة دخول).</li>
			<li>افتحي أدوات المطور (F12) ← Console، والصقي الكود التالي واضغطي Enter.</li>
			<li>انتظري دقيقة لين ينزل ملف <code>shahla-instagram.json</code>.</li>
		</ol>
		<textarea class="large-text code" rows="6" readonly dir="ltr" onclick="this.select()"><?php echo esc_textarea( sp_ig_snippet() ); ?></textarea>
		<h2>2) ارفعي الملف</h2>
		<form method="post" enctype="multipart/form-data">
			<?php wp_nonce_field( 'sp_import_upload' ); ?>
			<input type="file" name="sp_json" accept="application/json,.json" required>
			<button class="button" name="sp_import_upload" value="1">رفع</button>
		</form>
		<h2>3) الاستيراد</h2>
		<p><button class="button button-primary" id="sp-import-go" <?php disabled( ! $has ); ?>>ابدئي الاستيراد</button> <span id="sp-import-status"></span></p>
		<pre id="sp-import-log" style="max-height:300px;overflow:auto;background:#fff;border:1px solid #ddd;padding:10px;white-space:pre-wrap"></pre>
	</div>
	<script>
	document.getElementById('sp-import-go').addEventListener('click', async function () {
		const btn = this, st = document.getElementById('sp-import-status'), log = document.getElementById('sp-import-log');
		btn.disabled = true;
		let offset = 0, total = 1;
		while (offset < total) {
			st.textContent = 'جاري الاستيراد… ' + offset + ' / ' + total;
			const fd = new FormData();
			fd.append('action', 'sp_import_batch'); fd.append('offset', offset); fd.append('_wpnonce', <?php echo wp_json_encode( wp_create_nonce( 'sp_import_batch' ) ); ?>);
			const r = await fetch(ajaxurl, {method: 'POST', body: fd, credentials: 'same-origin'}).then(r => r.json()).catch(() => null);
			if (!r || !r.success) { st.textContent = 'توقف بسبب خطأ — اضغطي مرة ثانية للمتابعة.'; log.textContent += (r && r.data ? r.data : 'خطأ في الاتصال') + '\n'; btn.disabled = false; return; }
			total = r.data.total; offset = r.data.next;
			log.textContent += r.data.log.join('\n') + '\n';
			log.scrollTop = log.scrollHeight;
		}
		st.textContent = 'تم ✔';
	});
	</script>
	<?php
}

/** Clean bidi marks, Arabic digits. */
function sp_ig_clean( $s ) {
	$s = preg_replace( '/[\x{200E}\x{200F}\x{202A}-\x{202E}\x{2066}-\x{2069}\t]/u', '', (string) $s );
	return trim( strtr( $s, array( '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9', '٫' => '.' ) ) );
}

/** Caption → price, length, width, fabric, sold, extra lines. */
function sp_ig_parse( $caption ) {
	$c   = sp_ig_clean( $caption );
	$get = function ( $patterns ) use ( $c ) {
		foreach ( $patterns as $p ) {
			if ( preg_match( $p, $c, $m ) ) {
				return trim( $m[1] );
			}
		}
		return '';
	};
	$fab = $get( array( '/القماش\s*:\s*([^\n]+)/u' ) );
	if ( ! $fab ) {
		$en = strtolower( $get( array( '/Fabric\s*:\s*([^\n(]+)/i' ) ) );
		if ( $en ) {
			$fab = false !== strpos( $en, 'cotton' ) ? 'قطن' : ( false !== strpos( $en, 'crystal' ) ? 'حرير إيطالي مع فصوص' : ( false !== strpos( $en, 'mix' ) ? 'حرير مخلوط' : ( false !== strpos( $en, 'soft' ) ? 'حرير إيطالي ناعم' : 'حرير إيطالي' ) ) );
		}
	}
	$fab   = preg_replace( '/^[\s.،]+|[\s.،]+$/u', '', str_replace( 'ايطالي', 'إيطالي', (string) $fab ) );
	$extra = array();
	foreach ( preg_split( '/\n+/', $c ) as $line ) {
		$line = trim( preg_replace( array( '/#\S+/u', '/@\S+/u' ), '', $line ), " .\t" );
		if ( mb_strlen( $line ) > 2 && ! preg_match( '/❌|SOLD|السعر|الطول|العرض|القماش|Price|Length|Width|Fabric|ريال|OMR|متوفر|Only one|available|تسليم فوري|ready|جاهز/iu', $line ) ) {
			$extra[] = $line;
		}
	}
	return array(
		'price'  => $get( array( '/السعر\s*:\s*([\d.]+)/u', '/([\d.]+)\s*ريال/u', '/Price\s*:\s*([\d.]+)/i', '/([\d.]+)\s*OMR/i' ) ),
		'length' => $get( array( '/الطول\s*:\s*([\d.]+)/u', '/Length\s*:\s*([\d.]+)/i' ) ),
		'width'  => $get( array( '/العرض\s*:\s*([\d.]+)/u', '/Width\s*:\s*([\d.]+)/i' ) ),
		'fabric' => $fab ? $fab : 'حرير إيطالي',
		'sold'   => (bool) preg_match( '/SOLD/i', $c ),
		'extra'  => $extra,
	);
}

/** Products to create: priced posts, oldest first, with video-only twins merged in. */
function sp_ig_plan( $posts ) {
	usort( $posts, function ( $a, $b ) { return $a['ts'] <=> $b['ts']; } );
	$is_video_only = function ( $p ) {
		foreach ( $p['media'] as $m ) {
			if ( 'image' === $m['kind'] ) {
				return false;
			}
		}
		return true;
	};
	$out  = array();
	$used = array();
	foreach ( $posts as $i => $p ) {
		if ( isset( $used[ $i ] ) ) {
			continue;
		}
		$s = sp_ig_parse( $p['caption'] );
		if ( ! $s['price'] ) {
			continue;
		}
		// An image post and a reel of the same piece posted within a few days.
		foreach ( array( $i - 1, $i + 1 ) as $j ) {
			if ( ! isset( $posts[ $j ] ) || isset( $used[ $j ] ) || abs( $posts[ $j ]['ts'] - $p['ts'] ) > 4 * DAY_IN_SECONDS ) {
				continue;
			}
			$t = sp_ig_parse( $posts[ $j ]['caption'] );
			if ( $t['price'] === $s['price'] && $is_video_only( $posts[ $j ] ) !== $is_video_only( $p ) ) {
				$keep = $is_video_only( $p ) ? $posts[ $j ] : $p;
				$twin = $is_video_only( $p ) ? $p : $posts[ $j ];
				$keep['media'] = array_merge( $keep['media'], $twin['media'] );
				$keep['caption'] = $s['sold'] || $t['sold'] ? "SOLD\n" . $keep['caption'] : $keep['caption'];
				$used[ $j ] = true;
				$p = $keep;
				break;
			}
		}
		$used[ $i ] = true;
		$out[]      = $p;
	}
	return $out;
}

function sp_ig_sideload_url( $url, $post_id, $title ) {
	if ( ! $url ) {
		return 0;
	}
	$tmp = download_url( $url, 120 );
	if ( is_wp_error( $tmp ) ) {
		return 0;
	}
	$ext  = false !== strpos( $url, '.mp4' ) ? 'mp4' : 'jpg';
	$name = sanitize_file_name( strtolower( $title ) ) . '-' . wp_generate_password( 6, false ) . '.' . $ext;
	$id   = media_handle_sideload( array( 'name' => $name, 'tmp_name' => $tmp ), $post_id, $title );
	if ( is_wp_error( $id ) ) {
		@unlink( $tmp ); // phpcs:ignore
		return 0;
	}
	return (int) $id;
}

function sp_ig_category( $name, $slug ) {
	$t = get_term_by( 'slug', $slug, 'product_cat' );
	if ( $t ) {
		return (int) $t->term_id;
	}
	$r = wp_insert_term( $name, 'product_cat', array( 'slug' => $slug ) );
	return is_wp_error( $r ) ? 0 : (int) $r['term_id'];
}

/** Create one product from a planned post. Returns a log line. */
function sp_ig_create_product( $p ) {
	if ( get_posts( array( 'post_type' => 'product', 'post_status' => 'any', 'meta_key' => '_sp_ig_code', 'meta_value' => $p['code'], 'fields' => 'ids' ) ) ) {
		return $p['code'] . ': موجودة مسبقاً';
	}
	$s     = sp_ig_parse( $p['caption'] );
	$title = 'مخور ' . $s['fabric'];
	$desc  = '<p>مخور من ' . esc_html( $s['fabric'] ) . ' بتطريز مختار، وهو قطعة واحدة فقط من هذا التصميم.</p>' . ( $s['extra'] ? '<p>' . implode( '<br>', array_map( 'esc_html', $s['extra'] ) ) . '</p>' : '' );
	$date  = wp_date( 'Y-m-d H:i:s', (int) $p['ts'] );
	$sku   = sp_next_sku();
	$prod  = new WC_Product_Simple();
	$prod->set_name( $title );
	$prod->set_status( 'publish' );
	$prod->set_description( $desc );
	$prod->set_regular_price( $s['price'] );
	$prod->set_manage_stock( true );
	$prod->set_stock_quantity( $s['sold'] ? 0 : 1 );
	$prod->set_sold_individually( true );
	$prod->set_date_created( $date );
	$prod->set_sku( $sku );
	$prod->set_slug( strtolower( $sku ) );
	$cats = array();
	if ( false !== mb_strpos( $s['fabric'], 'مخلوط' ) ) {
		$cats[] = sp_ig_category( 'مخورات حرير مخلوط', 'mixed-silk' );
	} elseif ( false !== mb_strpos( $s['fabric'], 'قطن' ) ) {
		$cats[] = sp_ig_category( 'مخورات قطن', 'cotton' );
	} else {
		$cats[] = sp_ig_category( 'مخورات حرير إيطالي', 'italian-silk' );
	}
	if ( false !== mb_strpos( $s['fabric'], 'فصوص' ) ) {
		$cats[] = sp_ig_category( 'مخورات بالفصوص', 'crystals' );
	}
	$prod->set_category_ids( array_filter( $cats ) );
	foreach ( array( '_sp_length' => $s['length'], '_sp_width' => $s['width'] ) as $k => $v ) {
		if ( $v ) {
			$prod->update_meta_data( $k, (float) $v );
		}
	}
	$prod->update_meta_data( '_sp_fabric', $s['fabric'] );
	$prod->update_meta_data( '_sp_ig_code', $p['code'] );
	$pid = $prod->save();
	wp_update_post( array( 'ID' => $pid, 'post_date' => $date, 'post_date_gmt' => get_gmt_from_date( $date ) ) );

	$imgs  = array();
	$video = 0;
	foreach ( $p['media'] as $m ) {
		if ( 'image' === $m['kind'] ) {
			$id = sp_ig_sideload_url( $m['url'], $pid, $title . ' ' . $sku );
			if ( $id ) {
				$imgs[] = $id;
			}
		} elseif ( ! $video ) {
			if ( ! $s['sold'] ) {
				$video = sp_ig_sideload_url( $m['url'], $pid, 'فيديو ' . $sku );
			}
			if ( ! $imgs && ! empty( $m['cover'] ) ) {
				$c = sp_ig_sideload_url( $m['cover'], $pid, $title . ' ' . $sku );
				if ( $c ) {
					$imgs[] = $c;
				}
			}
		}
	}
	$prod = wc_get_product( $pid );
	if ( $imgs ) {
		$prod->set_image_id( array_shift( $imgs ) );
		$prod->set_gallery_image_ids( $imgs );
	}
	if ( $video ) {
		$prod->update_meta_data( '_sp_video_id', $video );
	}
	$prod->save();
	return $sku . ' ← ' . $p['code'] . ' (' . $s['price'] . ' ر.ع.' . ( $s['sold'] ? '، مباعة' : '' ) . ')';
}

add_action( 'wp_ajax_sp_import_batch', function () {
	check_ajax_referer( 'sp_import_batch' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'غير مسموح' );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	@set_time_limit( 300 ); // phpcs:ignore
	$data   = json_decode( (string) @file_get_contents( sp_import_file() ), true ); // phpcs:ignore
	$plan   = sp_ig_plan( (array) ( $data['posts'] ?? array() ) );
	$offset = absint( $_POST['offset'] ?? 0 ); // phpcs:ignore
	$log    = array();
	foreach ( array_slice( $plan, $offset, 2 ) as $p ) {
		try {
			$log[] = sp_ig_create_product( $p );
		} catch ( Throwable $e ) {
			$log[] = $p['code'] . ': ' . $e->getMessage();
		}
	}
	wp_send_json_success( array( 'total' => count( $plan ), 'next' => $offset + 2, 'log' => $log ) );
} );
