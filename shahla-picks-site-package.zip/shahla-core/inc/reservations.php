<?php
/**
 * "Awaiting confirmation" order status, piece reservation and auto-release.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	register_post_status( 'wc-sp-awaiting', array(
		'label'                     => 'بانتظار التأكيد',
		'public'                    => false,
		'exclude_from_search'       => false,
		'show_in_admin_all_list'    => true,
		'show_in_admin_status_list' => true,
		/* translators: %s: count */
		'label_count'               => _n_noop( 'بانتظار التأكيد <span class="count">(%s)</span>', 'بانتظار التأكيد <span class="count">(%s)</span>' ),
	) );
} );

add_filter( 'wc_order_statuses', function ( $st ) {
	$new = array();
	foreach ( $st as $k => $v ) {
		if ( 'wc-processing' === $k ) {
			$new['wc-sp-awaiting'] = 'بانتظار التأكيد';
		}
		$new[ $k ] = $v;
	}
	return $new;
} );

/* Count awaiting orders as "needs attention" in the admin menu bubble. */
add_filter( 'woocommerce_menu_order_count', function ( $count ) {
	return (int) $count + sp_awaiting_count();
} );

function sp_awaiting_count() {
	$ids = wc_get_orders( array( 'status' => 'sp-awaiting', 'limit' => -1, 'return' => 'ids' ) );
	return count( $ids );
}

/** Mark the order's pieces as reserved until $until. */
function sp_reserve_order_items( $order, $until ) {
	foreach ( $order->get_items() as $item ) {
		$p = $item->get_product();
		if ( $p ) {
			$p->update_meta_data( '_sp_reserved_until', (int) $until );
			$p->save_meta_data();
		}
	}
}

function sp_unreserve_order_items( $order ) {
	foreach ( $order->get_items() as $item ) {
		$p = $item->get_product();
		if ( $p && $p->get_meta( '_sp_reserved_until' ) ) {
			$p->delete_meta_data( '_sp_reserved_until' );
			$p->save_meta_data();
		}
	}
}

/* Leaving "awaiting": confirmed → sold, cancelled → WooCommerce restocks. */
add_action( 'woocommerce_order_status_changed', function ( $id, $from, $to, $order ) {
	if ( 'sp-awaiting' === $from && 'sp-awaiting' !== $to ) {
		sp_unreserve_order_items( $order );
	}
}, 10, 4 );

/* Auto-release expired reservations. */
add_action( 'sp_release_expired', 'sp_release_expired' );
function sp_release_expired() {
	$orders = wc_get_orders( array( 'status' => 'sp-awaiting', 'limit' => -1 ) );
	foreach ( $orders as $order ) {
		$exp = (int) $order->get_meta( '_sp_expires' );
		if ( $exp && $exp < time() ) {
			$order->update_status( 'cancelled', 'انتهت مدة الحجز بدون تأكيد، ورجعت القطع للبيع تلقائياً.' );
		}
	}
}

/* Make sure the cron exists even if the plugin was copied in without activation. */
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'sp_release_expired' ) ) {
		wp_schedule_event( time() + 300, 'sp_quarter_hour', 'sp_release_expired' );
	}
} );

/* One-click confirm / cancel buttons in the orders list. */
add_filter( 'woocommerce_admin_order_actions', function ( $actions, $order ) {
	if ( $order->has_status( 'sp-awaiting' ) ) {
		$base = admin_url( 'admin-ajax.php?action=woocommerce_mark_order_status&order_id=' . $order->get_id() );
		$actions = array(
			'processing' => array( 'url' => wp_nonce_url( $base . '&status=processing', 'woocommerce-mark-order-status' ), 'name' => 'تأكيد الطلب', 'action' => 'processing' ),
			'cancel'     => array( 'url' => wp_nonce_url( $base . '&status=cancelled', 'woocommerce-mark-order-status' ), 'name' => 'إلغاء وإرجاع القطع', 'action' => 'sp-cancel' ),
		) + $actions;
	}
	return $actions;
}, 10, 2 );

/* WhatsApp the customer straight from the order screen. */
add_action( 'woocommerce_admin_order_data_after_billing_address', function ( $order ) {
	$phone = preg_replace( '/\D+/', '', $order->get_billing_phone() );
	if ( ! $phone ) {
		return;
	}
	if ( 8 === strlen( $phone ) ) {
		$phone = '968' . $phone;
	}
	$msg = sprintf( 'مرحبا %s، بخصوص طلبك رقم #%s من مختارات شهلاء', $order->get_billing_first_name(), $order->get_order_number() );
	echo '<p><a class="button sp-wa-admin" target="_blank" rel="noopener" href="' . esc_url( sp_wa_url( $msg, $phone ) ) . '">مراسلة العميلة بالواتساب</a></p>';
	$method = $order->get_meta( '_sp_method' );
	if ( $method ) {
		echo '<p><strong>طريقة الاستلام:</strong> ' . esc_html( 'pickup' === $method ? 'استلام' : 'توصيل' ) . '</p>';
	}
	$exp = (int) $order->get_meta( '_sp_expires' );
	if ( $exp && $order->has_status( 'sp-awaiting' ) ) {
		echo '<p><strong>الحجز ينتهي:</strong> ' . esc_html( wp_date( 'j F Y، g:i a', $exp ) ) . '</p>';
	}
} );
