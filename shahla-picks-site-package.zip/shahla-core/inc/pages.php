<?php
/**
 * Page shortcodes: sold archive, wishlist, order tracking, size guide table.
 */
defined( 'ABSPATH' ) || exit;

/** URL of one of our pages: track | wishlist | sold | events | reviews | size */
function sp_page_url( $key ) {
	$pages = (array) get_option( 'sp_pages', array() );
	return ! empty( $pages[ $key ] ) ? get_permalink( (int) $pages[ $key ] ) : '';
}

/* Sold archive ("قطع انباعت") */
add_shortcode( 'sp_sold', function ( $atts ) {
	$a   = shortcode_atts( array( 'limit' => 60 ), $atts );
	$ids = sp_query_products( array( 'state' => 'sold', 'limit' => (int) $a['limit'] ) );
	if ( ! $ids ) {
		return '<p class="sp-empty">ما في قطع مباعة لعرضها حالياً.</p>';
	}
	return '<p class="sp-lead">هذه قطع انباعت ونعرضها للإلهام. إذا عجبتك وحدة اضغطي <strong>أبغى مثلها</strong> ونحاول نوفر لك قطعة قريبة منها.</p>' . sp_render_product_cards( $ids, 'sp-grid--sold' );
} );

/* Wishlist (stored in the browser; cards fetched over REST). */
add_shortcode( 'sp_wishlist', function () {
	return '<div class="sp-wishlist" data-sp-wishlist><p class="sp-empty" data-sp-wishlist-empty hidden></p><div data-sp-wishlist-grid><div class="sp-skeleton"></div></div></div>';
} );

add_action( 'rest_api_init', function () {
	register_rest_route( 'sp/v1', '/cards', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'args'                => array( 'ids' => array( 'sanitize_callback' => 'sanitize_text_field' ) ),
		'callback'            => function ( $req ) {
			$ids = array_slice( array_filter( array_map( 'absint', explode( ',', (string) $req['ids'] ) ) ), 0, 60 );
			$ids = array_values( array_filter( $ids, function ( $id ) { return 'product' === get_post_type( $id ) && 'publish' === get_post_status( $id ); } ) );
			return array( 'ids' => $ids, 'html' => sp_render_product_cards( $ids ) );
		},
	) );
} );

/* Order tracking */
add_shortcode( 'sp_track_order', function () {
	$no    = isset( $_GET['order'] ) ? absint( ltrim( wp_unslash( $_GET['order'] ), '#' ) ) : 0; // phpcs:ignore
	$phone = isset( $_GET['phone'] ) ? preg_replace( '/\D+/', '', wp_unslash( $_GET['phone'] ) ) : ''; // phpcs:ignore
	ob_start();
	?>
	<form class="sp-track" method="get">
		<div class="sp-field"><label for="sp-t-order">رقم الطلب</label><input id="sp-t-order" name="order" inputmode="numeric" dir="ltr" value="<?php echo $no ? esc_attr( $no ) : ''; ?>" required></div>
		<div class="sp-field"><label for="sp-t-phone">آخر 4 أرقام من جوالك</label><input id="sp-t-phone" name="phone" inputmode="numeric" dir="ltr" maxlength="12" value="<?php echo esc_attr( $phone ); ?>" required></div>
		<button class="sp-btn sp-btn--primary" type="submit">عرض حالة الطلب</button>
	</form>
	<?php
	if ( $no && $phone ) {
		$order = wc_get_order( $no );
		$ok    = $order && strlen( $phone ) >= 4 && substr( preg_replace( '/\D+/', '', $order->get_billing_phone() ), -4 ) === substr( $phone, -4 );
		if ( ! $ok ) {
			echo '<p class="sp-notice sp-notice--warn">ما لقينا طلب بهذه البيانات. تأكدي من الرقم أو راسلينا بالواتساب.</p>';
		} else {
			$map = array(
				'sp-awaiting' => array( 'بانتظار التأكيد', 'وصلنا طلبك وبنأكده معك في الواتساب. القطع محجوزة لك.' ),
				'processing'  => array( 'تم التأكيد', 'طلبك مؤكد وقيد التجهيز.' ),
				'completed'   => array( 'تم التسليم', 'تم تسليم طلبك. نتمنى تعجبك القطع!' ),
				'cancelled'   => array( 'ملغي', 'الطلب ملغي. إذا تبين تطلبين من جديد راسلينا.' ),
				'on-hold'     => array( 'معلّق', 'الطلب معلّق، بنتواصل معك.' ),
				'pending'     => array( 'بانتظار الدفع', 'الطلب بانتظار إتمام الدفع.' ),
			);
			$st  = $order->get_status();
			$lab = $map[ $st ] ?? array( wc_get_order_status_name( $st ), '' );
			echo '<div class="sp-track__result sp-track__result--' . esc_attr( $st ) . '"><p class="sp-eyebrow">طلب #' . esc_html( $order->get_order_number() ) . '</p><h3>' . esc_html( $lab[0] ) . '</h3><p>' . esc_html( $lab[1] ) . '</p><ul>';
			foreach ( $order->get_items() as $item ) {
				$p = $item->get_product();
				echo '<li>' . esc_html( ( $p ? $p->get_sku() . ' — ' : '' ) . $item->get_name() ) . ' <span>' . wp_kses_post( wc_price( $item->get_total() ) ) . '</span></li>';
			}
			echo '</ul><p class="sp-track__total">الإجمالي: ' . wp_kses_post( $order->get_formatted_order_total() ) . '</p>';
			echo '<a class="sp-btn sp-btn--wa" target="_blank" rel="noopener" href="' . esc_url( sp_wa_url( 'السلام عليكم، أستفسر عن طلبي رقم #' . $order->get_order_number() ) ) . '">' . sp_icon( 'whatsapp', 20 ) . '<span>استفسار عن الطلب</span></a></div>'; // phpcs:ignore
		}
	}
	return ob_get_clean();
} );

/* Size guide conversion table (inches → cm). */
add_shortcode( 'sp_size_table', function () {
	$out = '<div class="sp-table-wrap"><table class="sp-size-table"><thead><tr><th>الطول بالإنش</th><th>بالسنتيمتر</th></tr></thead><tbody>';
	for ( $i = 52; $i <= 62; $i++ ) {
		$out .= '<tr><td>' . $i . '</td><td>' . number_format( $i * 2.54, 1 ) . '</td></tr>';
	}
	return $out . '</tbody></table></div>';
} );
