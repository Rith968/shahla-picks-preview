<?php
/**
 * Phone subscribers for "new pieces" alerts (exported for a WhatsApp broadcast list).
 */
defined( 'ABSPATH' ) || exit;

function sp_subscribers_table() {
	global $wpdb;
	return $wpdb->prefix . 'sp_subscribers';
}

function sp_subscribers_install() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$t = sp_subscribers_table();
	dbDelta( "CREATE TABLE {$t} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		phone varchar(32) NOT NULL,
		name varchar(120) NOT NULL DEFAULT '',
		created datetime NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY phone (phone)
	) {$wpdb->get_charset_collate()};" );
	update_option( 'sp_subscribers_db', 1 );
}

add_action( 'plugins_loaded', function () {
	if ( ! get_option( 'sp_subscribers_db' ) ) {
		sp_subscribers_install();
	}
} );

function sp_subscribe_form() {
	ob_start();
	?>
	<form class="sp-subscribe" data-sp-subscribe novalidate>
		<label for="sp-sub-phone" class="screen-reader-text">رقم الجوال</label>
		<input id="sp-sub-phone" name="phone" type="tel" inputmode="tel" dir="ltr" placeholder="9XXXXXXX" aria-label="رقم الواتساب" required>
		<button type="submit" class="sp-btn sp-btn--primary">نبهيني</button>
		<p class="sp-subscribe__msg" role="status" hidden></p>
	</form>
	<?php
	return ob_get_clean();
}
add_shortcode( 'sp_subscribe', 'sp_subscribe_form' );

add_action( 'wp_ajax_sp_subscribe', 'sp_ajax_subscribe' );
add_action( 'wp_ajax_nopriv_sp_subscribe', 'sp_ajax_subscribe' );
function sp_ajax_subscribe() {
	check_ajax_referer( 'sp_front', 'nonce' );
	$phone = preg_replace( '/\D+/', '', wp_unslash( $_POST['phone'] ?? '' ) );
	if ( strlen( $phone ) < 8 ) {
		wp_send_json_error( array( 'message' => 'اكتبي رقم صحيح.' ) );
	}
	if ( 8 === strlen( $phone ) ) {
		$phone = '968' . $phone;
	}
	global $wpdb;
	$wpdb->query( $wpdb->prepare( 'INSERT IGNORE INTO ' . sp_subscribers_table() . ' (phone, created) VALUES (%s, %s)', $phone, current_time( 'mysql' ) ) ); // phpcs:ignore
	wp_send_json_success( array( 'message' => 'تم! بنرسل لك أول ما تنزل قطع جديدة.' ) );
}

add_action( 'admin_menu', function () {
	add_submenu_page( 'shahla', 'المشتركات', 'المشتركات', 'manage_woocommerce', 'sp-subscribers', 'sp_subscribers_page' );
}, 30 );

function sp_subscribers_page() {
	global $wpdb;
	$t = sp_subscribers_table();
	if ( isset( $_GET['del'] ) && check_admin_referer( 'sp_sub_del' ) ) { // phpcs:ignore
		$wpdb->delete( $t, array( 'id' => absint( $_GET['del'] ) ) ); // phpcs:ignore
	}
	$rows = $wpdb->get_results( "SELECT * FROM {$t} ORDER BY created DESC LIMIT 2000" ); // phpcs:ignore
	echo '<div class="wrap sp-admin"><h1>المشتركات في تنبيهات القطع الجديدة</h1>';
	echo '<p>هذه الأرقام سجلت من الموقع. صدّريها وأضيفيها لقائمة بث في واتساب بزنس عشان ترسلين لهم الإطلاقات الجديدة.</p>';
	echo '<p><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=sp_sub_export' ), 'sp_sub_export' ) ) . '">تصدير CSV</a> <span class="description">العدد: ' . count( $rows ) . '</span></p>';
	echo '<table class="widefat striped"><thead><tr><th>الرقم</th><th>التاريخ</th><th></th></tr></thead><tbody>';
	if ( ! $rows ) {
		echo '<tr><td colspan="3">لا يوجد مشتركات بعد.</td></tr>';
	}
	foreach ( $rows as $r ) {
		echo '<tr><td dir="ltr" style="text-align:right">+' . esc_html( $r->phone ) . '</td><td>' . esc_html( mysql2date( 'j F Y', $r->created ) ) . '</td><td><a href="' . esc_url( wp_nonce_url( admin_url( 'admin.php?page=sp-subscribers&del=' . $r->id ), 'sp_sub_del' ) ) . '">حذف</a></td></tr>';
	}
	echo '</tbody></table></div>';
}

add_action( 'admin_post_sp_sub_export', function () {
	check_admin_referer( 'sp_sub_export' );
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( 'غير مسموح' );
	}
	global $wpdb;
	$rows = $wpdb->get_results( 'SELECT phone, created FROM ' . sp_subscribers_table() . ' ORDER BY created DESC', ARRAY_A ); // phpcs:ignore
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=shahla-subscribers.csv' );
	$fh = fopen( 'php://output', 'w' );
	fwrite( $fh, "\xEF\xBB\xBF" );
	fputcsv( $fh, array( 'phone', 'date' ) );
	foreach ( $rows as $r ) {
		fputcsv( $fh, array( '+' . $r['phone'], $r['created'] ) );
	}
	exit;
} );
