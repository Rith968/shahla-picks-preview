<?php
/**
 * Customer reviews (text and/or screenshot).
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', 'sp_register_review_cpt' );
function sp_register_review_cpt() {
	register_post_type( 'sp_review', array(
		'labels'       => array(
			'name' => 'آراء العميلات', 'singular_name' => 'رأي', 'add_new' => 'إضافة رأي', 'add_new_item' => 'إضافة رأي عميلة',
			'edit_item' => 'تعديل الرأي', 'all_items' => 'آراء العميلات', 'menu_name' => 'آراء العميلات', 'not_found' => 'لا توجد آراء بعد',
			'featured_image' => 'صورة الرأي (لقطة شاشة)', 'set_featured_image' => 'اختيار صورة', 'remove_featured_image' => 'إزالة الصورة',
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => 'shahla',
		'supports'     => array( 'title', 'editor', 'thumbnail' ),
	) );
}

add_filter( 'enter_title_here', function ( $t, $post ) {
	return 'sp_review' === $post->post_type ? 'اسم العميلة (أو الحرف الأول)' : $t;
}, 10, 2 );

function sp_review_fields() {
	return array(
		'_sp_rating' => array( 'التقييم من 5', 'number', '', 'اختياري' ),
		'_sp_city'   => array( 'المدينة', 'text', '', 'اختياري، مثال: البريمي' ),
	);
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'sp_review_box', 'تفاصيل الرأي', function ( $post ) {
		wp_nonce_field( 'sp_review_save', 'sp_review_nonce' );
		echo '<table class="form-table sp-meta-table">';
		foreach ( sp_review_fields() as $k => $f ) {
			sp_meta_field_row( $post->ID, $k, $f );
		}
		echo '</table>';
	}, 'sp_review', 'normal', 'high' );
} );

add_action( 'save_post_sp_review', function ( $post_id ) {
	if ( ! isset( $_POST['sp_review_nonce'] ) || ! wp_verify_nonce( $_POST['sp_review_nonce'], 'sp_review_save' ) || ! current_user_can( 'edit_post', $post_id ) ) { // phpcs:ignore
		return;
	}
	sp_save_meta_fields( $post_id, sp_review_fields() );
} );

function sp_reviews_html( $limit = 12 ) {
	$ids = get_posts( array( 'post_type' => 'sp_review', 'post_status' => 'publish', 'posts_per_page' => $limit, 'fields' => 'ids' ) );
	if ( ! $ids ) {
		return '';
	}
	$out = '<div class="sp-reviews">';
	foreach ( $ids as $id ) {
		$rating = (int) get_post_meta( $id, '_sp_rating', true );
		$city   = get_post_meta( $id, '_sp_city', true );
		$text   = trim( wp_strip_all_tags( get_post_field( 'post_content', $id ) ) );
		$out   .= '<figure class="sp-review' . ( has_post_thumbnail( $id ) ? ' has-shot' : '' ) . '">';
		if ( has_post_thumbnail( $id ) ) {
			$out .= '<div class="sp-review__shot">' . get_the_post_thumbnail( $id, 'medium', array( 'loading' => 'lazy' ) ) . '</div>';
		}
		if ( $rating ) {
			$out .= '<div class="sp-review__stars" aria-label="' . esc_attr( $rating . ' من 5' ) . '">' . str_repeat( sp_icon( 'star', 15 ), min( 5, $rating ) ) . '</div>';
		}
		if ( $text ) {
			$out .= '<blockquote class="sp-review__text">' . esc_html( $text ) . '</blockquote>';
		}
		$out .= '<figcaption class="sp-review__who">' . esc_html( get_the_title( $id ) ) . ( $city ? ' · ' . esc_html( $city ) : '' ) . '</figcaption></figure>';
	}
	return $out . '</div>';
}

add_shortcode( 'sp_reviews', function ( $atts ) {
	$a    = shortcode_atts( array( 'limit' => 30 ), $atts );
	$html = sp_reviews_html( (int) $a['limit'] );
	return $html ?: '<p class="sp-empty">بنضيف آراء عميلاتنا هنا قريباً.</p>';
} );
