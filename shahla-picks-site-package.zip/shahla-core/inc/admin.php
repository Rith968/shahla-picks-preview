<?php
/**
 * A simpler dashboard for the shop owner.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'wp_dashboard_setup', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	wp_add_dashboard_widget( 'sp_dashboard', 'لوحة مختارات شهلاء', 'sp_dashboard_widget' );
	// Move ours to the top, drop the noise.
	global $wp_meta_boxes;
	$normal = $wp_meta_boxes['dashboard']['normal']['core'] ?? array();
	$ours   = array( 'sp_dashboard' => $normal['sp_dashboard'] ?? null );
	unset( $normal['sp_dashboard'] );
	$wp_meta_boxes['dashboard']['normal']['core'] = array_filter( $ours ) + $normal; // phpcs:ignore
	foreach ( array( 'dashboard_primary', 'dashboard_quick_press', 'dashboard_site_health', 'dashboard_activity', 'dashboard_right_now', 'woocommerce_dashboard_recent_reviews', 'wc_admin_dashboard_setup' ) as $box ) {
		remove_meta_box( $box, 'dashboard', 'normal' );
		remove_meta_box( $box, 'dashboard', 'side' );
	}
}, 99 );
remove_action( 'welcome_panel', 'wp_welcome_panel' );

function sp_dashboard_widget() {
	$available = count( sp_query_products( array( 'state' => 'available', 'limit' => -1 ) ) );
	$sold      = count( sp_query_products( array( 'state' => 'sold', 'limit' => -1 ) ) );
	$awaiting  = sp_awaiting_count();
	global $wpdb;
	$subs = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . sp_subscribers_table() ); // phpcs:ignore
	$orders_url = admin_url( 'admin.php?page=wc-orders&status=wc-sp-awaiting' );
	if ( ! class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) || ! \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
		$orders_url = admin_url( 'edit.php?post_status=wc-sp-awaiting&post_type=shop_order' );
	}
	?>
	<div class="sp-dash">
		<?php if ( ! sp_wa_number() ) : ?>
			<div class="sp-dash__warn">⚠ لم يُضف رقم الواتساب بعد. <a href="<?php echo esc_url( admin_url( 'admin.php?page=shahla' ) ); ?>">أضيفيه من الإعدادات</a> عشان توصلك الطلبات.</div>
		<?php endif; ?>
		<div class="sp-dash__stats">
			<a href="<?php echo esc_url( $orders_url ); ?>" class="sp-dash__stat<?php echo $awaiting ? ' is-hot' : ''; ?>"><strong><?php echo (int) $awaiting; ?></strong><span>طلبات بانتظار التأكيد</span></a>
			<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=product' ) ); ?>" class="sp-dash__stat"><strong><?php echo (int) $available; ?></strong><span>قطع متوفرة</span></a>
			<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=product&stock_status=outofstock' ) ); ?>" class="sp-dash__stat"><strong><?php echo (int) $sold; ?></strong><span>قطع مباعة</span></a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=sp-subscribers' ) ); ?>" class="sp-dash__stat"><strong><?php echo (int) $subs; ?></strong><span>مشتركات بالتنبيهات</span></a>
		</div>
		<div class="sp-dash__actions">
			<a class="button button-primary button-hero" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=product' ) ); ?>">+ إضافة قطعة جديدة</a>
			<a class="button" href="<?php echo esc_url( admin_url( 'edit-tags.php?taxonomy=product_cat&post_type=product' ) ); ?>">التصنيفات</a>
			<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=sp_banner' ) ); ?>">البانرات</a>
			<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=sp_event' ) ); ?>">البازارات</a>
			<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=sp_review' ) ); ?>">آراء العميلات</a>
			<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=sp-qr' ) ); ?>">بطاقات QR</a>
			<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=shop_coupon' ) ); ?>">أكواد الخصم</a>
			<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=shahla' ) ); ?>">الإعدادات</a>
		</div>
		<details class="sp-dash__help"><summary>كيف أضيف قطعة؟</summary>
			<ol>
				<li>اضغطي <strong>إضافة قطعة جديدة</strong> واكتبي الاسم والسعر.</li>
				<li>من <strong>صورة المنتج</strong> و<strong>معرض المنتج</strong> ارفعي الصور، ومن خانة <strong>فيديو القطعة</strong> ارفعي الفيديو.</li>
				<li>اكتبي الطول والعرض والقماش، واختاري التصنيف من اليسار. الكود يتولد تلقائياً.</li>
				<li>اضغطي <strong>نشر</strong> — أو حددي موعد لإطلاقها لاحقاً.</li>
			</ol>
			<p>تقدرين تسوين كل هذا من جوالك عن طريق تطبيق <strong>WooCommerce</strong>.</p>
		</details>
	</div>
	<?php
}

/* Fewer menus for the shop manager account. */
add_action( 'admin_menu', function () {
	if ( current_user_can( 'manage_options' ) ) {
		return;
	}
	foreach ( array( 'edit.php', 'edit-comments.php', 'tools.php' ) as $slug ) {
		remove_menu_page( $slug );
	}
	remove_submenu_page( 'woocommerce', 'wc-addons' );
	remove_submenu_page( 'woocommerce', 'wc-admin&path=/extensions' );
	remove_menu_page( 'woocommerce-marketing' );
	foreach ( array( 'edit-tags.php?taxonomy=product_tag&amp;post_type=product', 'edit-tags.php?taxonomy=product_brand&amp;post_type=product', 'product_attributes', 'product-reviews' ) as $sub ) {
		remove_submenu_page( 'edit.php?post_type=product', $sub );
	}
	global $menu;
	foreach ( (array) $menu as $item ) {
		// WooPayments promo ("المدفوعات") — gateways are set up from WooCommerce → Settings → Payments.
		if ( isset( $item[2] ) && false !== stripos( $item[2], 'payments' ) ) {
			remove_menu_page( $item[2] );
		}
	}
}, 999 );

/* Fewer product tabs for the shop manager: just what a one-off piece needs. */
add_filter( 'woocommerce_product_data_tabs', function ( $tabs ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		unset( $tabs['shipping'], $tabs['linked_product'], $tabs['attribute'], $tabs['advanced'] );
	}
	return $tabs;
}, 99 );

/* Branded login screen. */
add_action( 'login_enqueue_scripts', function () {
	$logo = function_exists( 'sp_theme_logo_data_uri' ) ? sp_theme_logo_data_uri( '#663634' ) : '';
	echo '<style>body.login{background:#FAF6F2}.login h1 a{' . ( $logo ? 'background-image:url(' . esc_attr( $logo ) . ');background-size:contain;width:260px;height:90px;' : '' ) . '}.login form{border:1px solid #E7DAD4;border-radius:14px;box-shadow:none}.wp-core-ui .button-primary{background:#663634;border-color:#663634}.login #backtoblog a,.login #nav a{color:#663634}</style>';
} );
add_filter( 'login_headerurl', function () { return home_url( '/' ); } );
add_filter( 'login_headertext', function () { return 'مختارات شهلاء'; } );

add_filter( 'admin_footer_text', function () {
	return 'مختارات شهلاء · لوحة التحكم';
} );
