<?php
/**
 * Bazaars & pop-up events.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', 'sp_register_event_cpt' );
function sp_register_event_cpt() {
	register_post_type( 'sp_event', array(
		'labels'       => array(
			'name' => 'البازارات', 'singular_name' => 'بازار', 'add_new' => 'إضافة بازار', 'add_new_item' => 'إضافة بازار / فعالية',
			'edit_item' => 'تعديل البازار', 'all_items' => 'البازارات', 'menu_name' => 'البازارات', 'not_found' => 'لا توجد بازارات بعد',
		),
		'public'       => true,
		'show_in_menu' => 'shahla',
		'has_archive'  => false,
		'rewrite'      => array( 'slug' => 'bazaar' ),
		'supports'     => array( 'title', 'editor', 'thumbnail' ),
		'show_in_rest' => true,
	) );
}

function sp_event_fields() {
	return array(
		'_sp_date'      => array( 'التاريخ', 'date', '', '' ),
		'_sp_time_from' => array( 'من الساعة', 'time', '', '' ),
		'_sp_time_to'   => array( 'إلى الساعة', 'time', '', '' ),
		'_sp_place'     => array( 'المكان', 'text', '', 'مثال: ذا جيت، العذيبة' ),
		'_sp_map'       => array( 'رابط الموقع على الخريطة', 'url', '', 'اختياري' ),
	);
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'sp_event_box', 'تفاصيل البازار', function ( $post ) {
		wp_nonce_field( 'sp_event_save', 'sp_event_nonce' );
		echo '<table class="form-table sp-meta-table">';
		foreach ( sp_event_fields() as $k => $f ) {
			sp_meta_field_row( $post->ID, $k, $f );
		}
		echo '</table>';
	}, 'sp_event', 'normal', 'high' );
} );

add_action( 'save_post_sp_event', function ( $post_id ) {
	if ( ! isset( $_POST['sp_event_nonce'] ) || ! wp_verify_nonce( $_POST['sp_event_nonce'], 'sp_event_save' ) || ! current_user_can( 'edit_post', $post_id ) ) { // phpcs:ignore
		return;
	}
	sp_save_meta_fields( $post_id, sp_event_fields() );
} );

add_filter( 'manage_sp_event_posts_columns', function ( $c ) {
	return array( 'cb' => $c['cb'], 'title' => 'البازار', 'sp_when' => 'الموعد', 'sp_place' => 'المكان' );
} );
add_action( 'manage_sp_event_posts_custom_column', function ( $col, $id ) {
	if ( 'sp_when' === $col ) {
		echo esc_html( sp_event_when( $id ) );
	}
	if ( 'sp_place' === $col ) {
		echo esc_html( get_post_meta( $id, '_sp_place', true ) );
	}
}, 10, 2 );

function sp_event_ts( $date, $time = '12:00' ) {
	try {
		$dt = new DateTime( $date . ' ' . ( $time ? $time : '12:00' ), wp_timezone() );
		return $dt->getTimestamp();
	} catch ( Exception $e ) {
		return 0;
	}
}

function sp_event_when( $id ) {
	$d = get_post_meta( $id, '_sp_date', true );
	if ( ! $d ) {
		return '';
	}
	$out  = wp_date( 'l j F Y', sp_event_ts( $d ) );
	$from = get_post_meta( $id, '_sp_time_from', true );
	$to   = get_post_meta( $id, '_sp_time_to', true );
	if ( $from ) {
		$out .= '، ' . wp_date( 'g:i a', sp_event_ts( $d, $from ) ) . ( $to ? ' – ' . wp_date( 'g:i a', sp_event_ts( $d, $to ) ) : '' );
	}
	return $out;
}

function sp_get_events( $when = 'upcoming', $limit = 6 ) {
	$today = current_time( 'Y-m-d' );
	return get_posts( array(
		'post_type' => 'sp_event', 'post_status' => 'publish', 'posts_per_page' => $limit, 'fields' => 'ids',
		'meta_key' => '_sp_date', 'orderby' => 'meta_value', 'order' => 'upcoming' === $when ? 'ASC' : 'DESC',
		'meta_query' => array( array( 'key' => '_sp_date', 'value' => $today, 'compare' => 'upcoming' === $when ? '>=' : '<', 'type' => 'DATE' ) ),
	) );
}

function sp_event_card( $id, $past = false ) {
	$place = get_post_meta( $id, '_sp_place', true );
	$map   = get_post_meta( $id, '_sp_map', true );
	$d     = get_post_meta( $id, '_sp_date', true );
	ob_start();
	?>
	<article class="sp-event<?php echo $past ? ' is-past' : ''; ?>">
		<?php if ( has_post_thumbnail( $id ) ) : ?>
			<div class="sp-event__media"><?php echo get_the_post_thumbnail( $id, 'large', array( 'loading' => 'lazy' ) ); ?></div>
		<?php endif; ?>
		<div class="sp-event__body">
			<?php if ( $d ) : ?>
			<div class="sp-event__date" aria-hidden="true"><span><?php echo esc_html( wp_date( 'j', sp_event_ts( $d ) ) ); ?></span><small><?php echo esc_html( wp_date( 'F', sp_event_ts( $d ) ) ); ?></small></div>
			<?php endif; ?>
			<div>
				<p class="sp-eyebrow"><?php echo $past ? 'شاركنا في' : 'موعدنا القادم'; ?></p>
				<h3 class="sp-event__title"><?php echo esc_html( get_the_title( $id ) ); ?></h3>
				<p class="sp-event__meta"><?php echo sp_icon( 'clock', 16 ); // phpcs:ignore ?> <?php echo esc_html( sp_event_when( $id ) ); ?></p>
				<?php if ( $place ) : ?><p class="sp-event__meta"><?php echo sp_icon( 'pin', 16 ); // phpcs:ignore ?> <?php echo esc_html( $place ); ?></p><?php endif; ?>
				<?php if ( ! $past && $map ) : ?><a class="sp-link" href="<?php echo esc_url( $map ); ?>" target="_blank" rel="noopener">افتحي الموقع على الخريطة</a><?php endif; ?>
			</div>
		</div>
	</article>
	<?php
	return ob_get_clean();
}

add_shortcode( 'sp_events', function () {
	$up   = sp_get_events( 'upcoming', 20 );
	$past = sp_get_events( 'past', 12 );
	$out  = '<div class="sp-events">';
	$out .= '<h2 class="sp-h2">البازارات القادمة</h2>';
	if ( $up ) {
		$out .= '<div class="sp-events__grid">';
		foreach ( $up as $id ) {
			$out .= sp_event_card( $id );
		}
		$out .= '</div>';
	} else {
		$out .= '<p class="sp-empty">ما في بازار معلن حالياً. تابعينا على <a href="' . esc_url( sp_opt( 'instagram' ) ) . '" target="_blank" rel="noopener">إنستقرام</a> عشان تعرفين موعدنا الجاي.</p>';
	}
	if ( $past ) {
		$out .= '<h2 class="sp-h2">شاركنا سابقاً في</h2><div class="sp-events__grid">';
		foreach ( $past as $id ) {
			$out .= sp_event_card( $id, true );
		}
		$out .= '</div>';
	}
	return $out . '</div>';
} );
