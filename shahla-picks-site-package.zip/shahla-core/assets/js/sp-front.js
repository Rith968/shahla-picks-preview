/* Shahla Core — storefront behaviour (no dependencies). */
(function () {
	'use strict';
	var S = window.SP || {};
	var $ = function (s, c) { return (c || document).querySelector(s); };
	var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

	function post(action, data) {
		var fd = new FormData();
		fd.append('action', action);
		fd.append('nonce', S.nonce);
		Object.keys(data || {}).forEach(function (k) { fd.append(k, data[k]); });
		return fetch(S.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
	}

	function money(v) {
		var n = Math.round(Number(v) * 1000) / 1000;
		var s = (n % 1 === 0) ? String(n) : n.toFixed(3).replace(/0+$/, '').replace(/\.$/, '');
		return s + ' ' + (S.currency || '');
	}

	function toast(msg) {
		var t = $('.sp-toast');
		if (!t) { t = document.createElement('div'); t.className = 'sp-toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
		t.textContent = msg;
		t.classList.add('is-on');
		clearTimeout(t._h);
		t._h = setTimeout(function () { t.classList.remove('is-on'); }, 2200);
	}

	/* ---------------- Hero banners ---------------- */
	function initHero(root) {
		var slides = $$('.sp-hero__slide', root);
		var dots = $$('.sp-hero__dot', root);
		var soundBtn = $('[data-sp-sound]', root);
		var mq = window.matchMedia('(max-width: 768px)');
		var cur = 0, timer = null, muted = true;
		var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

		function srcFor(v) { return mq.matches ? v.dataset.srcMobile : v.dataset.srcDesktop; }
		function load(v) {
			var want = srcFor(v);
			if (want && v.getAttribute('src') !== want) { v.src = want; v.load(); }
		}
		function play(i) {
			clearTimeout(timer);
			slides.forEach(function (s, k) {
				var on = k === i;
				s.classList.toggle('is-active', on);
				s.setAttribute('aria-hidden', on ? 'false' : 'true');
				var v = $('video', s);
				if (v && !on) { v.pause(); }
			});
			dots.forEach(function (d, k) { d.classList.toggle('is-active', k === i); d.setAttribute('aria-selected', k === i ? 'true' : 'false'); });
			cur = i;
			var s = slides[i];
			var v = $('video', s);
			if (soundBtn) { soundBtn.hidden = !v; }
			if (v) {
				load(v);
				v.muted = muted;
				v.currentTime = 0;
				var p = v.play();
				if (p && p.catch) { p.catch(function () { /* autoplay blocked: poster stays */ }); }
				if (slides.length > 1) {
					v.onended = function () { next(); };
					// Safety: very long videos still rotate.
					timer = setTimeout(next, 45000);
				} else { v.loop = true; }
			} else if (slides.length > 1 && !reduce) {
				timer = setTimeout(next, (parseInt(s.dataset.duration, 10) || 6) * 1000);
			}
			// Warm up the next video.
			var n = slides[(i + 1) % slides.length];
			var nv = n && $('video', n);
			if (nv && nv !== v) { nv.preload = 'metadata'; load(nv); }
		}
		function next() { play((cur + 1) % slides.length); }
		function prev() { play((cur - 1 + slides.length) % slides.length); }

		dots.forEach(function (d) { d.addEventListener('click', function () { play(parseInt(d.dataset.go, 10)); }); });
		if (soundBtn) {
			soundBtn.addEventListener('click', function () {
				muted = !muted;
				soundBtn.setAttribute('aria-pressed', muted ? 'false' : 'true');
				soundBtn.setAttribute('aria-label', muted ? 'تشغيل الصوت' : 'كتم الصوت');
				root.classList.toggle('has-sound', !muted);
				var v = $('video', slides[cur]);
				if (v) { v.muted = muted; if (v.paused) { v.play(); } }
			});
		}
		// Swipe (RTL: swipe left = previous visual = next logical).
		var x0 = null;
		root.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
		root.addEventListener('touchend', function (e) {
			if (x0 === null) { return; }
			var dx = e.changedTouches[0].clientX - x0;
			if (Math.abs(dx) > 50 && slides.length > 1) { (dx > 0 ? next : prev)(); }
			x0 = null;
		});
		// Pause when off-screen or tab hidden.
		if ('IntersectionObserver' in window) {
			new IntersectionObserver(function (es) {
				var v = $('video', slides[cur]);
				if (!v) { return; }
				if (es[0].isIntersecting) { v.play().catch(function () {}); } else { v.pause(); }
			}, { threshold: 0.2 }).observe(root);
		}
		document.addEventListener('visibilitychange', function () {
			var v = $('video', slides[cur]);
			if (v) { if (document.hidden) { v.pause(); } else { v.play().catch(function () {}); } }
		});
		mq.addEventListener && mq.addEventListener('change', function () { play(cur); });
		play(0);
	}

	/* ---------------- Drop countdown ---------------- */
	function initCountdown(el) {
		var end = parseInt(el.dataset.spDrop, 10) * 1000;
		var units = { d: $('[data-u="d"]', el), h: $('[data-u="h"]', el), m: $('[data-u="m"]', el), s: $('[data-u="s"]', el) };
		function pad(n) { return (n < 10 ? '0' : '') + n; }
		(function tick() {
			var left = Math.max(0, end - Date.now());
			var s = Math.floor(left / 1000);
			units.d.textContent = pad(Math.floor(s / 86400));
			units.h.textContent = pad(Math.floor(s % 86400 / 3600));
			units.m.textContent = pad(Math.floor(s % 3600 / 60));
			units.s.textContent = pad(s % 60);
			if (left <= 0) { setTimeout(function () { location.reload(); }, 4000); return; }
			setTimeout(tick, 1000);
		})();
	}

	/* ---------------- Wishlist ---------------- */
	var WKEY = 'sp_wishlist';
	function wishGet() { try { return JSON.parse(localStorage.getItem(WKEY) || '[]').map(Number).filter(Boolean); } catch (e) { return []; } }
	function wishSet(a) { try { localStorage.setItem(WKEY, JSON.stringify(a)); } catch (e) {} wishPaint(); }
	function wishPaint() {
		var list = wishGet();
		$$('[data-sp-wish]').forEach(function (b) {
			var on = list.indexOf(Number(b.dataset.spWish)) > -1;
			b.classList.toggle('is-on', on);
			b.setAttribute('aria-pressed', on ? 'true' : 'false');
		});
		$$('[data-sp-wish-count]').forEach(function (c) { c.textContent = list.length; c.dataset.count = list.length; });
	}
	document.addEventListener('click', function (e) {
		var b = e.target.closest && e.target.closest('[data-sp-wish]');
		if (!b) { return; }
		e.preventDefault();
		var id = Number(b.dataset.spWish), list = wishGet(), i = list.indexOf(id);
		if (i > -1) { list.splice(i, 1); toast(S.i18n.removed); } else { list.unshift(id); toast(S.i18n.added); }
		wishSet(list);
		var page = $('[data-sp-wishlist]');
		if (page && i > -1) { var card = b.closest('li.product'); if (card) { card.remove(); } if (!wishGet().length) { renderWishlist(page); } }
	});
	function renderWishlist(root) {
		var ids = wishGet();
		var grid = $('[data-sp-wishlist-grid]', root), empty = $('[data-sp-wishlist-empty]', root);
		if (!ids.length) { grid.innerHTML = ''; empty.textContent = S.i18n.empty; empty.hidden = false; return; }
		fetch(S.rest + 'cards?ids=' + ids.join(','), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
			grid.innerHTML = d.html || '';
			if (!d.ids || !d.ids.length) { empty.textContent = S.i18n.empty; empty.hidden = false; }
			if (d.ids && d.ids.length !== ids.length) { wishSet(d.ids); }
			wishPaint();
		});
	}

	/* ---------------- Cart → WhatsApp ---------------- */
	function initWaForm(form) {
		var panel = form.closest('.sp-wa-panel');
		var err = $('.sp-form-error', form);
		var feeEl = $('[data-sp-fee]', form), totalEl = $('[data-sp-total]', form), subEl = $('[data-sp-subtotal]', form);
		var deliveryBox = $('[data-sp-delivery]', form);
		var gift = $('details.sp-gift', form);
		function method() { var r = $('input[name="method"]:checked', form); return r ? r.value : 'delivery'; }
		function recalc() {
			var sub = parseFloat(subEl.dataset.value) || 0;
			var m = method();
			deliveryBox.hidden = m !== 'delivery';
			if (m !== 'delivery') { feeEl.textContent = S.i18n.free; totalEl.textContent = money(sub); return; }
			var fee = S.fees ? S.fees[form.gov.value] : '';
			if (fee === '' || fee === undefined || fee === null) { feeEl.textContent = S.i18n.feeAsk; totalEl.textContent = money(sub) + ' + ' + 'التوصيل'; }
			else { feeEl.textContent = Number(fee) > 0 ? money(fee) : S.i18n.free; totalEl.textContent = money(sub + Number(fee)); }
		}
		form.addEventListener('change', recalc);
		recalc();
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			err.hidden = true;
			$$('.is-invalid', form).forEach(function (i) { i.classList.remove('is-invalid'); });
			if (!form.name.value.trim()) { form.name.classList.add('is-invalid'); form.name.focus(); return; }
			if (form.phone.value.replace(/\D/g, '').length < 8) { form.phone.classList.add('is-invalid'); form.phone.focus(); return; }
			var btn = $('button[type="submit"]', form), label = btn.innerHTML;
			btn.disabled = true; btn.querySelector('span').textContent = S.i18n.sending;
			var data = {
				name: form.name.value, phone: form.phone.value, method: method(),
				gov: form.gov ? form.gov.value : '', area: form.area ? form.area.value : '',
				gift: gift && gift.open ? '1' : '0', gift_note: form.gift_note ? form.gift_note.value : '', notes: form.notes.value
			};
			post('sp_wa_order', data).then(function (r) {
				btn.disabled = false; btn.innerHTML = label;
				if (!r || !r.success) {
					err.textContent = (r && r.data && r.data.message) || S.i18n.error; err.hidden = false;
					if (r && r.data && r.data.field && form[r.data.field]) { form[r.data.field].classList.add('is-invalid'); }
					if (r && r.data && r.data.reload) { setTimeout(function () { location.reload(); }, 2500); }
					return;
				}
				var done = $('[data-sp-wa-done]', panel);
				$('[data-sp-order-no]', done).textContent = r.data.order;
				$('[data-sp-wa-link]', done).href = r.data.url;
				form.hidden = true; done.hidden = false;
				$$('.woocommerce-cart-form, .cart_totals').forEach(function (el) { el.hidden = true; });
				$$('.sp-cart-count').forEach(function (c) { c.textContent = '0'; c.dataset.count = 0; });
				done.scrollIntoView({ behavior: 'smooth', block: 'center' });
				window.location.href = r.data.url;
			}).catch(function () {
				btn.disabled = false; btn.innerHTML = label;
				err.textContent = S.i18n.error; err.hidden = false;
			});
		});
	}

	/* ---------------- Subscribe ---------------- */
	function initSubscribe(form) {
		var msg = $('.sp-subscribe__msg', form);
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			post('sp_subscribe', { phone: form.phone.value }).then(function (r) {
				msg.textContent = (r && r.data && r.data.message) || S.i18n.error;
				msg.hidden = false;
				if (r && r.success) { form.phone.value = ''; }
			});
		});
	}

	/* ---------------- Share ---------------- */
	document.addEventListener('click', function (e) {
		var b = e.target.closest && e.target.closest('[data-sp-share]');
		if (!b) { return; }
		e.preventDefault();
		var url = b.dataset.url || location.href, title = b.dataset.title || document.title;
		if (navigator.share) { navigator.share({ title: title, url: url }).catch(function () {}); return; }
		window.open('https://wa.me/?text=' + encodeURIComponent(title + '\n' + url), '_blank', 'noopener');
	});

	/* ---------------- Smooth jump ---------------- */
	document.addEventListener('click', function (e) {
		var a = e.target.closest && e.target.closest('a.sp-jump');
		if (!a) { return; }
		var t = document.querySelector(a.getAttribute('href'));
		if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); var f = t.querySelector('input'); if (f) { setTimeout(function () { f.focus({ preventScroll: true }); }, 500); } }
	});

	/* ---------------- Sticky buy bar ---------------- */
	function initBuybar(bar) {
		var anchor = $('.summary .sp-actions');
		function check() { bar.classList.toggle('is-on', !anchor || anchor.getBoundingClientRect().bottom < 0); }
		window.addEventListener('scroll', check, { passive: true });
		window.addEventListener('resize', check);
		check();
	}

	document.addEventListener('DOMContentLoaded', function () {
		$$('[data-sp-hero]').forEach(initHero);
		$$('[data-sp-drop]').forEach(initCountdown);
		$$('[data-sp-wa-form]').forEach(function (f) { f._sp = 1; initWaForm(f); });
		$$('[data-sp-subscribe]').forEach(initSubscribe);
		$$('[data-sp-buybar]').forEach(initBuybar);
		var wl = $('[data-sp-wishlist]'); if (wl) { renderWishlist(wl); }
		wishPaint();
	});
	// WooCommerce re-renders the cart via AJAX.
	if (window.jQuery) {
		window.jQuery(document.body).on('updated_cart_totals updated_wc_div', function () {
			$$('[data-sp-wa-form]').forEach(function (f) { if (!f._sp) { f._sp = 1; initWaForm(f); } });
			wishPaint();
		});
		window.jQuery(document.body).on('applied_coupon removed_coupon', function () { setTimeout(function () { location.reload(); }, 600); });
	}
})();
