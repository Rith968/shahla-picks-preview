/* Shahla Core — admin media pickers. */
jQuery(function ($) {
	$(document).on('click', '.sp-media-pick', function (e) {
		e.preventDefault();
		var $btn = $(this), $wrap = $btn.closest('.sp-media-field, .sp-video-field');
		var type = $btn.data('type') || 'image';
		var frame = wp.media({ title: $btn.data('title') || 'اختيار', library: { type: type }, multiple: false, button: { text: 'اختيار' } });
		frame.on('select', function () {
			var a = frame.state().get('selection').first().toJSON();
			$wrap.find('.sp-media-id').val(a.id).trigger('change');
			$wrap.find('.sp-media-name').text(a.filename || a.title || '');
			$wrap.find('.sp-media-clear').prop('hidden', false);
			if (type === 'image') {
				var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
				$wrap.find('.sp-media-thumb').remove();
				$wrap.prepend($('<img class="sp-media-thumb" alt="">').attr('src', url));
			}
		});
		frame.open();
	});
	$(document).on('click', '.sp-media-clear', function (e) {
		e.preventDefault();
		var $wrap = $(this).closest('.sp-media-field, .sp-video-field');
		$wrap.find('.sp-media-id').val('').trigger('change');
		$wrap.find('.sp-media-name').text('');
		$wrap.find('.sp-media-thumb').remove();
		$(this).prop('hidden', true);
	});
});
