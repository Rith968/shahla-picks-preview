<?php
/**
 * One-off importer: builds the Shahla Picks store from the Instagram export
 * (/tmp/sp-data.json + /tmp/sp-media/*). Run inside WordPress (wp-load.php loaded).
 */
defined( 'ABSPATH' ) || exit;

require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';
require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';
require_once ABSPATH . 'wp-admin/includes/theme.php';

// Inside WordPress Playground a loopback request would deadlock the single PHP worker.
add_filter( 'action_scheduler_allow_async_request_runner', '__return_false' );

const SPI_DATA  = '/tmp/sp-data.json';
const SPI_MEDIA = '/tmp/sp-media/';

function spi_data() {
	static $d = null;
	if ( null === $d ) {
		$d = json_decode( file_get_contents( SPI_DATA ), true );
	}
	return $d;
}

function spi_clean( $s ) {
	$s = preg_replace( '/[\x{200E}\x{200F}\x{202A}-\x{202E}\x{2066}-\x{2069}\t]/u', '', (string) $s );
	$s = strtr( $s, array( '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9', '٫' => '.' ) );
	return trim( $s );
}

/** Parse a caption into specs. */
function spi_parse( $caption ) {
	$c   = spi_clean( $caption );
	$get = function ( $patterns ) use ( $c ) {
		foreach ( $patterns as $p ) {
			if ( preg_match( $p, $c, $m ) ) {
				return trim( $m[1] );
			}
		}
		return '';
	};
	$price  = $get( array( '/السعر\s*:\s*([\d.]+)/u', '/([\d.]+)\s*ريال/u', '/Price\s*:\s*([\d.]+)/i', '/([\d.]+)\s*OMR/i' ) );
	$length = $get( array( '/الطول\s*:\s*([\d.]+)/u', '/Length\s*:\s*([\d.]+)/i' ) );
	$width  = $get( array( '/العرض\s*:\s*([\d.]+)/u', '/Width\s*:\s*([\d.]+)/i' ) );
	$fab_ar = $get( array( '/القماش\s*:\s*([^\n]+)/u' ) );
	$fab_en = $get( array( '/Fabric\s*:\s*([^\n(]+)/i' ) );
	$fabric = $fab_ar ? $fab_ar : '';
	if ( ! $fabric && $fab_en ) {
		$e = strtolower( $fab_en );
		if ( false !== strpos( $e, 'cotton' ) ) {
			$fabric = 'قطن';
		} elseif ( false !== strpos( $e, 'crystal' ) ) {
			$fabric = 'حرير إيطالي مع فصوص';
		} elseif ( false !== strpos( $e, 'mix' ) || false !== strpos( $e, 'blend' ) ) {
			$fabric = 'حرير مخلوط';
		} elseif ( false !== strpos( $e, 'soft' ) ) {
			$fabric = 'حرير إيطالي ناعم';
		} else {
			$fabric = 'حرير إيطالي';
		}
	}
	if ( ! $fabric && preg_match( '/حرير/u', $c ) ) {
		$fabric = 'حرير إيطالي';
	}
	$fabric = preg_replace( '/^[\s.،]+|[\s.،]+$/u', '', str_replace( array( 'ايطالي', '  ' ), array( 'إيطالي', ' ' ), $fabric ) );
	// Extra lines worth keeping in the description.
	$extra = array();
	foreach ( preg_split( '/\n+/', $c ) as $line ) {
		$line = trim( $line, " .\t" );
		if ( '' === $line || preg_match( '/^(❌|#|@)|SOLD|السعر|الطول|العرض|القماش|Price|Length|Width|Fabric|ريال|OMR|متوفر|Only one|available|تسليم فوري|ready|جاهز/iu', $line ) ) {
			continue;
		}
		$line = trim( preg_replace( array( '/#\S+/u', '/@\S+/u' ), '', $line ) );
		if ( mb_strlen( $line ) > 2 ) {
			$extra[] = $line;
		}
	}
	return array(
		'price'  => $price,
		'length' => $length,
		'width'  => $width,
		'fabric' => $fabric ? $fabric : 'حرير إيطالي',
		'sold'   => (bool) preg_match( '/SOLD/i', $c ),
		'extra'  => $extra,
	);
}

/** Temp file on the same filesystem as uploads (Playground can't rename across devices). */
function spi_tmp( $name ) {
	$dir = wp_upload_dir()['basedir'] . '/sp-tmp';
	wp_mkdir_p( $dir );
	return $dir . '/' . uniqid( '', true ) . '-' . sanitize_file_name( $name );
}

function spi_sideload( $file, $post_id = 0, $title = '' ) {
	$src = SPI_MEDIA . $file;
	if ( ! file_exists( $src ) ) {
		return 0;
	}
	$tmp = spi_tmp( $file );
	copy( $src, $tmp );
	$id = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), $post_id, $title );
	if ( is_wp_error( $id ) ) {
		@unlink( $tmp ); // phpcs:ignore
		return 0;
	}
	return (int) $id;
}

function spi_term( $name, $slug, $tax = 'product_cat', $desc = '' ) {
	$t = get_term_by( 'slug', $slug, $tax );
	if ( $t ) {
		return (int) $t->term_id;
	}
	$r = wp_insert_term( $name, $tax, array( 'slug' => $slug, 'description' => $desc ) );
	return is_wp_error( $r ) ? 0 : (int) $r['term_id'];
}

function spi_page( $key, $title, $slug, $content ) {
	$pages = (array) get_option( 'sp_pages', array() );
	if ( ! empty( $pages[ $key ] ) && get_post( $pages[ $key ] ) ) {
		return (int) $pages[ $key ];
	}
	$existing = get_page_by_path( $slug );
	$id       = $existing ? $existing->ID : wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => $content ) );
	if ( $existing ) {
		wp_update_post( array( 'ID' => $id, 'post_title' => $title, 'post_content' => $content, 'post_status' => 'publish' ) );
	}
	$pages[ $key ] = (int) $id;
	update_option( 'sp_pages', $pages );
	return (int) $id;
}

/* ===================== 1. Site setup ===================== */
function spi_setup() {
	$log = array();
	if ( ! is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
		activate_plugin( 'woocommerce/woocommerce.php' );
	}
	$r = activate_plugin( 'shahla-core/shahla-core.php' );
	$log[] = 'core: ' . ( is_wp_error( $r ) ? $r->get_error_message() : 'active' );
	switch_theme( 'shahla' );
	$log[] = 'theme: ' . get_stylesheet();

	update_option( 'blogname', 'مختارات شهلاء' );
	update_option( 'blogdescription', 'مخورات حرير إيطالي — قطعة واحدة من كل تصميم' );
	update_option( 'timezone_string', 'Asia/Muscat' );
	update_option( 'date_format', 'j F Y' );
	update_option( 'permalink_structure', '/%postname%/' );
	update_option( 'default_comment_status', 'closed' );

	$wc = array(
		'woocommerce_currency'                   => 'OMR',
		'woocommerce_currency_pos'               => 'right_space',
		'woocommerce_price_num_decimals'         => '3',
		'woocommerce_price_decimal_sep'          => '.',
		'woocommerce_price_thousand_sep'         => ',',
		'woocommerce_default_country'            => 'OM',
		'woocommerce_allowed_countries'          => 'specific',
		'woocommerce_specific_allowed_countries' => array( 'OM' ),
		'woocommerce_ship_to_countries'          => 'disabled',
		'woocommerce_calc_taxes'                 => 'no',
		'woocommerce_enable_reviews'             => 'no',
		'woocommerce_manage_stock'               => 'yes',
		'woocommerce_hold_stock_minutes'         => '',
		'woocommerce_notify_low_stock'           => 'no',
		'woocommerce_notify_no_stock'            => 'no',
		'woocommerce_hide_out_of_stock_items'    => 'no',
		'woocommerce_enable_guest_checkout'      => 'yes',
		'woocommerce_enable_checkout_login_reminder' => 'no',
		'woocommerce_enable_signup_and_login_from_checkout' => 'no',
		'woocommerce_enable_myaccount_registration' => 'no',
		'woocommerce_coming_soon'                => 'no',
		'woocommerce_store_pages_only'           => 'no',
		'woocommerce_task_list_hidden'           => 'yes',
		'woocommerce_task_list_complete'         => 'yes',
		'woocommerce_show_marketplace_suggestions' => 'no',
		'woocommerce_allow_tracking'             => 'no',
		'woocommerce_thumbnail_cropping'         => 'custom',
		'woocommerce_thumbnail_cropping_custom_width'  => '4',
		'woocommerce_thumbnail_cropping_custom_height' => '5',
		'woocommerce_thumbnail_image_width'      => '450',
		'woocommerce_single_image_width'         => '900',
		'woocommerce_cart_redirect_after_add'    => 'no',
		'woocommerce_enable_ajax_add_to_cart'    => 'yes',
		'woocommerce_feature_order_attribution_enabled' => 'no',
	);
	foreach ( $wc as $k => $v ) {
		update_option( $k, $v );
	}
	update_option( 'woocommerce_onboarding_profile', array( 'skipped' => true, 'completed' => true ) );

	// Categories.
	$cats = array(
		'silk'    => array( 'مخورات حرير إيطالي', 'italian-silk', 'مخورات من الحرير الإيطالي بتطريز مختار.' ),
		'eid'     => array( 'تشكيلة العيد', 'eid-collection', 'قطع تشكيلة العيد.' ),
		'mixed'   => array( 'مخورات حرير مخلوط', 'mixed-silk', '' ),
		'crystal' => array( 'مخورات بالفصوص', 'crystals', '' ),
		'cotton'  => array( 'مخورات قطن', 'cotton', '' ),
	);
	$ids = array();
	foreach ( $cats as $k => $c ) {
		$ids[ $k ] = spi_term( $c[0], $c[1], 'product_cat', $c[2] );
	}
	update_option( 'spi_cats', $ids );

	// Pages.
	$shop = wc_get_page_id( 'shop' );
	if ( $shop > 0 ) {
		wp_update_post( array( 'ID' => $shop, 'post_title' => 'المتجر', 'post_name' => 'shop' ) );
	}
	$home = spi_page( 'home', 'الرئيسية', 'home', '' );
	$cart = spi_page( 'cart', 'السلة', 'cart', '[woocommerce_cart]' );
	$chk  = spi_page( 'checkout', 'إتمام الدفع', 'checkout', '[woocommerce_checkout]' );
	update_option( 'woocommerce_cart_page_id', $cart );
	update_option( 'woocommerce_checkout_page_id', $chk );
	spi_page( 'wishlist', 'المفضلة', 'wishlist', '[sp_wishlist]' );
	spi_page( 'sold', 'قطع انباعت', 'sold', '[sp_sold]' );
	spi_page( 'events', 'البازارات', 'bazaars', '[sp_events]' );
	spi_page( 'reviews', 'آراء العميلات', 'reviews', '[sp_reviews]' );
	spi_page( 'track', 'تتبع الطلب', 'track-order', "<p>اكتبي رقم طلبك (يوصلك في رسالة الواتساب) وآخر 4 أرقام من جوالك.</p>\n[sp_track_order]" );
	spi_page( 'size', 'دليل المقاسات', 'size-guide', spi_size_guide() );
	spi_page( 'about', 'من نحن', 'about', spi_about() );
	spi_page( 'policy', 'الاستبدال والتوصيل', 'policy', spi_policy() );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home );
	foreach ( array( 'hello-world' => 'post', 'sample-page' => 'page' ) as $slug => $type ) {
		$p = get_page_by_path( $slug, OBJECT, $type );
		if ( $p ) {
			wp_delete_post( $p->ID, true );
		}
	}
	$ma = wc_get_page_id( 'myaccount' );
	if ( $ma > 0 ) {
		wp_update_post( array( 'ID' => $ma, 'post_status' => 'draft' ) );
	}

	// Settings.
	update_option( 'sp_settings', wp_parse_args( array( 'announcement' => 'حرير إيطالي · قطعة واحدة من كل تصميم · تسليم فوري' ), sp_settings_defaults() ) );

	// Shop-manager account for the owner.
	if ( ! username_exists( 'shahla' ) ) {
		$pass = wp_generate_password( 14, false );
		$uid  = wp_insert_user( array( 'user_login' => 'shahla', 'user_pass' => $pass, 'display_name' => 'شهلاء', 'role' => 'shop_manager', 'locale' => 'ar', 'user_email' => 'owner@shahlapicks.local' ) );
		update_option( 'spi_owner_pass', $pass );
		$log[] = 'owner user: ' . ( is_wp_error( $uid ) ? $uid->get_error_message() : 'created' );
	}

	// Site icon.
	if ( ! get_option( 'site_icon' ) ) {
		$icon = get_template_directory() . '/assets/img/icon-512.png';
		if ( file_exists( $icon ) ) {
			$tmp = spi_tmp( 'icon.png' );
			copy( $icon, $tmp );
			$aid = media_handle_sideload( array( 'name' => 'shahla-icon.png', 'tmp_name' => $tmp ), 0, 'أيقونة الموقع' );
			if ( ! is_wp_error( $aid ) ) {
				update_option( 'site_icon', $aid );
			}
		}
	}
	flush_rewrite_rules();
	return $log;
}

function spi_menus() {
	$pages = (array) get_option( 'sp_pages', array() );
	$cats  = (array) get_option( 'spi_cats', array() );
	foreach ( array( 'primary' => 'القائمة الرئيسية', 'footer' => 'روابط الفوتر' ) as $loc => $name ) {
		$m = wp_get_nav_menu_object( $name );
		if ( $m ) {
			wp_delete_nav_menu( $m->term_id );
		}
	}
	$primary = wp_create_nav_menu( 'القائمة الرئيسية' );
	$add     = function ( $menu, $args, $parent = 0 ) {
		return wp_update_nav_menu_item( $menu, 0, array_merge( array( 'menu-item-status' => 'publish', 'menu-item-parent-id' => $parent ), $args ) );
	};
	$add( $primary, array( 'menu-item-title' => 'الرئيسية', 'menu-item-url' => home_url( '/' ), 'menu-item-type' => 'custom' ) );
	$shop = $add( $primary, array( 'menu-item-title' => 'المتجر', 'menu-item-object' => 'page', 'menu-item-object-id' => wc_get_page_id( 'shop' ), 'menu-item-type' => 'post_type' ) );
	$add( $primary, array( 'menu-item-title' => 'كل القطع المتوفرة', 'menu-item-object' => 'page', 'menu-item-object-id' => wc_get_page_id( 'shop' ), 'menu-item-type' => 'post_type' ), $shop );
	foreach ( $cats as $tid ) {
		$t = get_term( $tid, 'product_cat' );
		if ( $t && ! is_wp_error( $t ) && $t->count > 0 ) {
			$add( $primary, array( 'menu-item-title' => $t->name, 'menu-item-object' => 'product_cat', 'menu-item-object-id' => $tid, 'menu-item-type' => 'taxonomy' ), $shop );
		}
	}
	foreach ( array( 'sold' => 'قطع انباعت', 'events' => 'البازارات', 'reviews' => 'آراء العميلات' ) as $k => $label ) {
		if ( ! empty( $pages[ $k ] ) ) {
			$add( $primary, array( 'menu-item-title' => $label, 'menu-item-object' => 'page', 'menu-item-object-id' => $pages[ $k ], 'menu-item-type' => 'post_type' ) );
		}
	}
	$footer = wp_create_nav_menu( 'روابط الفوتر' );
	foreach ( array( 'about', 'size', 'policy', 'track', 'wishlist' ) as $k ) {
		if ( ! empty( $pages[ $k ] ) ) {
			$add( $footer, array( 'menu-item-object' => 'page', 'menu-item-object-id' => $pages[ $k ], 'menu-item-type' => 'post_type' ) );
		}
	}
	set_theme_mod( 'nav_menu_locations', array( 'primary' => $primary, 'footer' => $footer ) );
	return 'menus ok';
}

function spi_size_guide() {
	return '<p>كل قطعة عندنا مكتوب طولها وعرضها <strong>بالإنش</strong>. قيسي مخور أو جلابية تلبسينها ويناسبك مقاسها، وقارنيها بمقاسات القطعة.</p>
<h2>طريقة القياس</h2>
<ul>
<li><strong>الطول:</strong> من أعلى الكتف (جنب الرقبة) إلى آخر القطعة من تحت.</li>
<li><strong>العرض:</strong> مدّي القطعة على سطح مستوي، وقيسي من تحت الإبط إلى تحت الإبط الثاني.</li>
</ul>
<p>إذا عندك أي سؤال عن مقاس قطعة معينة، أرسلي لنا كودها بالواتساب ونقيسها لك.</p>
<h2>تحويل الإنش إلى سنتيمتر</h2>
[sp_size_table]';
}

function spi_about() {
	return '<p><strong>مختارات شهلاء</strong> مشروع عُماني من بوشر في مسقط، نختار لك مخورات من الحرير الإيطالي بتطريزات مميزة.</p>
<p>كل تصميم عندنا <strong>قطعة واحدة فقط</strong>، عشان تكون قطعتك مختلفة. ونشارك في البازارات والأسواق مثل أسواق عُمان الليلية، فتابعينا عشان تعرفين موعدنا الجاي.</p>';
}

function spi_policy() {
	return '<p class="sp-notice sp-notice--warn">مسودة: هذه الصفحة تحتاج تعبئة سياسة المتجر الفعلية قبل إطلاق الموقع.</p>
<h2>التوصيل</h2>
<p>[اكتبي هنا مناطق التوصيل، الرسوم، والمدة المتوقعة.]</p>
<h2>الاستلام</h2>
<p>الاستلام متاح من بوشر، مسقط. [أضيفي أوقات الاستلام.]</p>
<h2>الاستبدال والاسترجاع</h2>
<p>[اكتبي هنا سياسة الاستبدال أو الاسترجاع، والمدة المسموحة، وحالة القطعة المطلوبة.]</p>
<h2>الحجز</h2>
<p>عند إرسال طلب من السلة عبر الواتساب تُحجز القطع لك مؤقتاً لين نأكد الطلب معك.</p>';
}

/* ===================== 2. Products ===================== */
function spi_products( $offset = 0, $limit = 6 ) {
	$data  = spi_data();
	$cats  = (array) get_option( 'spi_cats', array() );
	$posts = array_values( array_filter( $data['posts'], function ( $p ) { return 'product' === $p['role']; } ) );
	usort( $posts, function ( $a, $b ) { return $a['ts'] <=> $b['ts']; } ); // oldest first → codes in order
	$dups = array();
	foreach ( $data['posts'] as $p ) {
		if ( 0 === strpos( $p['role'], 'dup:' ) ) {
			$dups[ substr( $p['role'], 4 ) ] = $p;
		}
	}
	$out = array();
	foreach ( array_slice( $posts, $offset, $limit ) as $p ) {
		$existing = get_posts( array( 'post_type' => 'product', 'post_status' => 'any', 'meta_key' => '_sp_ig_code', 'meta_value' => $p['code'], 'fields' => 'ids' ) );
		if ( $existing ) {
			$out[] = $p['code'] . ' exists';
			continue;
		}
		$s     = spi_parse( $p['caption'] );
		$title = 'مخور ' . $s['fabric'];
		$desc  = '<p>مخور من ' . esc_html( $s['fabric'] ) . ' بتطريز مختار، وهو قطعة واحدة فقط من هذا التصميم.</p>';
		if ( $s['extra'] ) {
			$desc .= '<p>' . implode( '<br>', array_map( 'esc_html', $s['extra'] ) ) . '</p>';
		}
		$date  = wp_date( 'Y-m-d H:i:s', (int) $p['ts'] );
		$prod  = new WC_Product_Simple();
		$prod->set_name( $title );
		$prod->set_status( 'publish' );
		$prod->set_description( $desc );
		$prod->set_regular_price( $s['price'] ? $s['price'] : '0' );
		$prod->set_manage_stock( true );
		$prod->set_stock_quantity( $s['sold'] ? 0 : 1 );
		$prod->set_sold_individually( true );
		$prod->set_date_created( $date );
		$sku = sp_next_sku();
		$prod->set_sku( $sku );
		$prod->set_slug( strtolower( $sku ) );
		$terms = array( $cats['silk'] ?? 0 );
		if ( false !== mb_strpos( $s['fabric'], 'مخلوط' ) ) {
			$terms = array( $cats['mixed'] ?? 0 );
		}
		if ( false !== mb_strpos( $s['fabric'], 'قطن' ) ) {
			$terms = array( $cats['cotton'] ?? 0 );
		}
		if ( false !== mb_strpos( $s['fabric'], 'فصوص' ) ) {
			$terms[] = $cats['crystal'] ?? 0;
		}
		if ( 0 === strpos( $p['date'], '2025-03' ) ) {
			$terms[] = $cats['eid'] ?? 0;
		}
		$prod->set_category_ids( array_values( array_filter( $terms ) ) );
		if ( $s['length'] ) {
			$prod->update_meta_data( '_sp_length', (float) $s['length'] );
		}
		if ( $s['width'] ) {
			$prod->update_meta_data( '_sp_width', (float) $s['width'] );
		}
		$prod->update_meta_data( '_sp_fabric', $s['fabric'] );
		$prod->update_meta_data( '_sp_ig_code', $p['code'] );
		$pid = $prod->save();
		wp_update_post( array( 'ID' => $pid, 'post_date' => $date, 'post_date_gmt' => get_gmt_from_date( $date ) ) );

		$imgs  = array();
		$video = 0;
		$media = $p['media'];
		if ( isset( $dups[ $p['code'] ] ) ) {
			$media = array_merge( $media, $dups[ $p['code'] ]['media'] );
		}
		foreach ( $media as $m ) {
			if ( 'image' === $m['kind'] ) {
				$id = spi_sideload( $m['file'], $pid, $title . ' ' . $sku );
				if ( $id ) {
					$imgs[] = $id;
					update_post_meta( $id, '_wp_attachment_image_alt', $title . ' — ' . $sku );
				}
			} elseif ( 'video' === $m['kind'] && ! $video ) {
				$video = spi_sideload( $m['file'], $pid, 'فيديو ' . $sku );
				if ( ! $imgs && ! empty( $m['cover'] ) ) {
					$c = spi_sideload( $m['cover'], $pid, $title . ' ' . $sku );
					if ( $c ) {
						$imgs[] = $c;
					}
				}
			}
		}
		$prod = wc_get_product( $pid );
		if ( $imgs ) {
			$prod->set_image_id( array_shift( $imgs ) );
			$prod->set_gallery_image_ids( $imgs );
		}
		if ( $video ) {
			$prod->update_meta_data( '_sp_video_id', $video );
		}
		$prod->save();
		$out[] = $sku . ' ' . $p['code'] . ' ' . $s['price'] . ' ' . ( $s['sold'] ? 'sold' : 'avail' ) . ' imgs:' . ( count( $imgs ) + 1 ) . ( $video ? ' +video' : '' );
	}
	return array( 'total' => count( $posts ), 'done' => $out );
}

/* ===================== 3. Banners, event, reviews ===================== */
function spi_extras() {
	$data = spi_data();
	$out  = array();
	$byc  = array();
	foreach ( $data['posts'] as $p ) {
		$byc[ $p['code'] ] = $p;
	}
	$banners = array(
		array( 'nightmarket', 'شكراً لكل من زارنا في أسواق عُمان الليلية', 'ذا جيت · نوفمبر 2026', 'لقطات من مشاركتنا في البازار. القطع المتوفرة تقدرين تطلبينها الآن من الموقع.', 'تسوّقي القطع المتوفرة' ),
		array( 'sizes', 'مخورات حرير بمختلف المقاسات', 'قطعة واحدة من كل تصميم', 'جاهزة للتسليم الفوري. اختاري الطول اللي يناسبك وتسوّقي حسب مقاسك.', 'تسوّقي حسب الطول' ),
		array( 'ready', 'مخورات حرير جاهزة للتسليم الفوري', 'مختارات شهلاء', 'تطريزات مختارة على حرير إيطالي.', 'تسوّقي الآن' ),
	);
	$order = 0;
	foreach ( $banners as $b ) {
		$p = null;
		foreach ( $data['posts'] as $pp ) {
			if ( 'banner:' . $b[0] === $pp['role'] ) {
				$p = $pp;
			}
		}
		if ( ! $p || get_posts( array( 'post_type' => 'sp_banner', 'meta_key' => '_sp_ig_code', 'meta_value' => $p['code'], 'fields' => 'ids' ) ) ) {
			continue;
		}
		$id = wp_insert_post( array( 'post_type' => 'sp_banner', 'post_status' => 'publish', 'post_title' => $b[1], 'menu_order' => $order++ ) );
		foreach ( $p['media'] as $m ) {
			if ( 'video' === $m['kind'] ) {
				update_post_meta( $id, '_sp_video_mobile', spi_sideload( $m['file'], 0, 'بانر ' . $b[1] ) );
				if ( ! empty( $m['cover'] ) ) {
					update_post_meta( $id, '_sp_image', spi_sideload( $m['cover'], 0, 'غلاف ' . $b[1] ) );
				}
				break;
			}
		}
		update_post_meta( $id, '_sp_eyebrow', $b[2] );
		update_post_meta( $id, '_sp_text', $b[3] );
		update_post_meta( $id, '_sp_btn_text', $b[4] );
		if ( 'sizes' === $b[0] ) {
			update_post_meta( $id, '_sp_btn_url', add_query_arg( 'sp_len', 'mid', wc_get_page_permalink( 'shop' ) ) );
		}
		update_post_meta( $id, '_sp_ig_code', $p['code'] );
		$out[] = 'banner ' . $b[0];
	}

	foreach ( $data['posts'] as $p ) {
		if ( 'event' !== $p['role'] || get_posts( array( 'post_type' => 'sp_event', 'meta_key' => '_sp_ig_code', 'meta_value' => $p['code'], 'fields' => 'ids' ) ) ) {
			continue;
		}
		$id = wp_insert_post( array(
			'post_type' => 'sp_event', 'post_status' => 'publish', 'post_title' => 'أسواق عُمان الليلية — ذا جيت',
			'post_content' => '<p>كنا موجودين في ذا جيت ومعانا تشكيلة من المخورات. شكراً لكل من زارنا ودعم مشروعنا!</p>',
		) );
		update_post_meta( $id, '_sp_date', '2026-10-30' );
		update_post_meta( $id, '_sp_time_from', '16:00' );
		update_post_meta( $id, '_sp_time_to', '23:00' );
		update_post_meta( $id, '_sp_place', 'ذا جيت، العذيبة — شارع 18 نوفمبر' );
		update_post_meta( $id, '_sp_ig_code', $p['code'] );
		foreach ( $p['media'] as $m ) {
			if ( 'image' === $m['kind'] ) {
				$img = spi_sideload( $m['file'], $id, 'أسواق عُمان الليلية' );
				if ( $img ) {
					set_post_thumbnail( $id, $img );
				}
				break;
			}
		}
		$out[] = 'event';
	}

	foreach ( (array) ( $data['reviews'] ?? array() ) as $i => $r ) {
		if ( get_posts( array( 'post_type' => 'sp_review', 'meta_key' => '_sp_ig_code', 'meta_value' => $r['code'], 'fields' => 'ids' ) ) ) {
			continue;
		}
		$id = wp_insert_post( array( 'post_type' => 'sp_review', 'post_status' => 'publish', 'post_title' => 'عميلة مختارات شهلاء', 'post_content' => '' ) );
		$img = spi_sideload( $r['file'], $id, 'رأي عميلة' );
		if ( $img ) {
			set_post_thumbnail( $id, $img );
		}
		update_post_meta( $id, '_sp_ig_code', $r['code'] );
		$out[] = 'review ' . $i;
	}
	return $out;
}

function spi_finalize() {
	spi_menus();
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'fields' => 'ids' ) );
	wp_update_term_count_now( $terms, 'product_cat' );
	foreach ( (array) get_option( 'spi_cats', array() ) as $tid ) {
		$first = get_posts( array( 'post_type' => 'product', 'posts_per_page' => 1, 'fields' => 'ids', 'tax_query' => array( array( 'taxonomy' => 'product_cat', 'terms' => $tid ) ), 'meta_query' => array( array( 'key' => '_stock_status', 'value' => 'instock' ) ) ) );
		if ( ! $first ) {
			$first = get_posts( array( 'post_type' => 'product', 'posts_per_page' => 1, 'fields' => 'ids', 'tax_query' => array( array( 'taxonomy' => 'product_cat', 'terms' => $tid ) ) ) );
		}
		if ( $first && get_post_thumbnail_id( $first[0] ) ) {
			update_term_meta( $tid, 'thumbnail_id', get_post_thumbnail_id( $first[0] ) );
		}
	}
	flush_rewrite_rules();
	wc_delete_product_transients();
	return 'final ok';
}
